const logger = require('../../../lib/logger');

exports.update_competitors = async (simulation_id, competitors) => {
  const postgres = require('../../../db/postgres');
  let update_result = {
    nb_deleted: 0,
    nb_inserted: 0,
  };
  try {
    const { SCHEMA_TABLE } = process.env;
    const delete_query = `DELETE FROM ${SCHEMA_TABLE}.ggo_simulation_concurrence WHERE id_simulation='${simulation_id}'`;
    const res_delete = await postgres.query(delete_query);
    update_result.nb_deleted = res_delete.rowCount;
    if (competitors && Array.isArray(competitors) && competitors.length > 0) {
      const fnac_competitors = competitors.filter((c) => c.fnac_id > 0);
      logger.info(`Competitors with fnac_id > 0. Total: ${fnac_competitors.length}`);
      if (fnac_competitors.length > 0) {
        const insert_query = `WITH ggo_competitors as (
          SELECT fnac_id, selected, dist_meter 
          FROM json_to_recordset('${JSON.stringify(fnac_competitors)}') 
          as x("fnac_id" int, "selected" boolean, "dist_meter" numeric))
          INSERT INTO ${SCHEMA_TABLE}.ggo_simulation_concurrence(
            id_simulation, fnac_id, fnac_category, fnac_lib_mag, fnac_idens, fnac_libens, fnac_adr, fnac_cp, fnac_ville, fnac_pays, fnac_code_geo, fnac_niveau, fnac_contrat, fnac_surfventec, fnac_datecrea, fnac_long, fnac_lat, fnac_niveauconc, fnac_visible, fnac_caht_conc, fnac_periode_ca, fnac_topconc, selected, dist_meter)
          SELECT '${simulation_id}' id_simulation, c.*, gc.selected, gc.dist_meter
          FROM ggo_competitors gc LEFT JOIN ${SCHEMA_TABLE}.fnac_concurrence c on c.fnac_id = gc.fnac_id
          `;
        logger.info(insert_query);
        try {
          const res_insert = await postgres.query(insert_query);
          update_result.nb_inserted = res_insert.rowCount;
        } catch (err_insert) {
          logger.error('Failed to insert FNAC competitors', err_insert);
          update_result.error = 'Failed to insert competitors';
          update_result.error_details = err_insert;
        }
      }
      const ggo_competitors = competitors.filter((c) => c.fnac_id < 0);
      logger.info(`Competitors with fnac_id < 0. Total: ${ggo_competitors.length}`);
      if (ggo_competitors.length > 0) {
        logger.warn('TODO: insert competitors created in the app');
        const c_fields = [
          'id_simulation',
          'fnac_id',
          'fnac_category',
          'fnac_lib_mag',
          'fnac_idens',
          'fnac_libens',
          'fnac_adr',
          'fnac_cp',
          'fnac_ville',
          'fnac_pays',
          'fnac_code_geo',
          'fnac_niveau',
          'fnac_contrat',
          'fnac_surfventec',
          'fnac_datecrea',
          'fnac_long',
          'fnac_lat',
          'fnac_niveauconc',
          'fnac_visible',
          'fnac_caht_conc',
          'fnac_periode_ca',
          'fnac_topconc',
          'selected',
          'dist_meter',
        ];
        const x_fields = [
          '"fnac_id" int',
          '"fnac_category" text',
          '"fnac_lib_mag" text',
          '"fnac_idens" numeric',
          '"fnac_libens" text',
          '"fnac_adr" text',
          '"fnac_cp" text',
          '"fnac_ville" text',
          '"fnac_pays" text',
          '"fnac_code_geo" text',
          '"fnac_niveau" text',
          '"fnac_contrat" text',
          '"fnac_surfventec" numeric',
          '"fnac_datecrea" text',
          '"fnac_long" numeric',
          '"fnac_lat" numeric',
          '"fnac_niveauconc" numeric',
          '"fnac_visible" text',
          '"fnac_caht_conc" numeric',
          '"fnac_periode_ca" numeric',
          '"fnac_topconc" numeric',
          '"selected" boolean',
          '"dist_meter" numeric',
        ];
        const insert_query = `WITH ggo_competitors as (
          SELECT ${c_fields.filter((c) => c !== 'id_simulation').join(', ')}
          FROM json_to_recordset('${JSON.stringify(ggo_competitors)}') 
          as x(${x_fields.join(',')}))
          INSERT INTO ${SCHEMA_TABLE}.ggo_simulation_concurrence(${c_fields.join(', ')})
          SELECT '${simulation_id}' id_simulation, c.* FROM ggo_competitors c`;
        try {
          const res_insert = await postgres.query(insert_query);
          update_result.nb_inserted += res_insert.rowCount;
        } catch (err_insert) {
          logger.error('Failed to insert FNAC competitors', err_insert);
          update_result.error = 'Failed to insert ggo competitors';
          update_result.error_details = err_insert;
        }
      }
    }
  } catch (err) {
    logger.error('Global error while updating competitors: ' + err);
  }
  return update_result;
};
