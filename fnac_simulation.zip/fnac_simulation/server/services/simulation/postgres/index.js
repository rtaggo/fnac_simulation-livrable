const { v5: uuidv5 } = require('uuid');
const postgres = require('../../../db/postgres');
const MY_NAMESPACE = '602cdbe5-7ecd-43e4-be56-27ad60d1f1fc';

const get_next_simulation_id = () => {
  return uuidv5(`${Date.now()}`, MY_NAMESPACE);
};

exports.get_user_simulations = async (req, res) => {
  console.log('[SIMULATION SERVICES] >> get_user_simulations');
  const { SCHEMA_TABLE } = process.env;

  const query = `SELECT id, name, description, location, created_by, created_date, last_modified_date, last_modified_by
	FROM ${SCHEMA_TABLE}.ggo_simulation`;
  try {
    postgres.query(query).then((query_res) => {
      res.send(query_res.rows);
    });
  } catch (err) {
    return res.status(500).json({
      error: true,
      message: 'Failed to get Simulation details',
      details: [err],
    });
  }
};

exports.get_simulation_details = async (req, res) => {
  try {
    const { SCHEMA_TABLE } = process.env;
    const { simulation_id } = req.params;
    const query = `SELECT id, name, description, location, statistics, zc, created_by, created_date, last_modified_date, last_modified_by
    FROM ${SCHEMA_TABLE}.ggo_simulation WHERE id='${simulation_id}'`;
    postgres.query(query).then(async (query_res) => {
      if (query_res.rows.length === 0) {
        return res.status(500).json({
          error: true,
          message: 'Failed to get Simulation details',
          details: [`Unknown simulation with id ${simulation_id}`],
        });
      }
      let simulation = query_res.rows[0];
      const estimation_query = `
      SELECT 'estimation_ca' estimation, SUM(estimation_ca) total
        FROM ${SCHEMA_TABLE}.ggo_simulation_zones
        WHERE id_simulation = '${simulation_id}' 
      UNION
      SELECT 'estimation_perte_ca' estimation, SUM(estimation_ca_perdu) total 
        FROM ${SCHEMA_TABLE}.ggo_simulation_cannibalisation 
        WHERE id_simulation = '${simulation_id}'`;
      const res_estimation = await postgres.query(estimation_query);
      if (res_estimation.rowCount === 2) {
        const estimation_ca_r = res_estimation.rows[0];
        const estimation_perte_ca_r = res_estimation.rows[1];
        const estimation_ca = estimation_ca_r.total;
        const estimation_perte_ca = estimation_perte_ca_r.total;
        if (estimation_ca !== null && estimation_perte_ca !== null) {
          simulation.estimations = { estimation_ca, estimation_perte_ca };
        }
      }
      const { get_simulation_concurrence } = require('../../concurrence');
      get_simulation_concurrence(simulation_id, (error, competitors) => {
        simulation.competitors = competitors;
        res.send(simulation);
      });
      //res.send(query_res.rows[0]);
    });
  } catch (error) {
    console.error('get-simulation-error', error);
    return res.status(500).json({
      error: true,
      message: 'Failed to get Simulation details',
      details: error,
    });
  }
};

exports.save_simulation = async (req, res) => {
  try {
    const { SCHEMA_TABLE } = process.env;
    const { name, description, location, statistics, zc, competitors, store_properties } = req.body;
    const new_simulation_id = get_next_simulation_id();
    const fields = ['id', 'name', 'created_by', 'last_modified_by', 'location', 'statistics', 'zc', 'description', 'store_properties'];
    let set_values = [`'${new_simulation_id}'`, `'${name}'`, `'${req.decodedUser.login}'`, `'${req.decodedUser.login}'`];

    set_values.push(location ? `'${JSON.stringify(location)}'` : 'null');
    set_values.push(statistics ? `'${JSON.stringify(statistics)}'` : 'null');
    set_values.push(zc ? `'${JSON.stringify(zc)}'` : 'null');
    set_values.push(description ? `'${description.replace(/'/g, "''")}'` : 'null');
    set_values.push(store_properties ? `'${JSON.stringify(store_properties)}'` : 'null');

    const insert_query = ` INSERT INTO ${SCHEMA_TABLE}.ggo_simulation(${fields.join(', ')}) VALUES (${set_values.join(', ')}) RETURNING id`;
    console.log(insert_query);

    postgres
      .query(insert_query)
      .then(async (res_insert) => {
        const { update_competitors } = require('../helpers/competitors');
        const res_update_competitors = await update_competitors(new_simulation_id, competitors);
        console.log(JSON.stringify(res_update_competitors));

        let update_results = {
          competitors: res_update_competitors,
        };

        const { update_simulation_zones_table } = require('../helpers/zones');
        const res_update_zones = await update_simulation_zones_table(new_simulation_id, zc.zones);
        console.log(JSON.stringify(res_update_zones));

        update_results.zones = res_update_zones;

        res.status(200).json({
          success: true,
          message: 'Simulation save Success',
          data: { id: res_insert.rows[0].id, update_results },
        });
      })
      .catch((err) => {
        return res.status(500).json({
          error: true,
          message: 'Cannot Save Simulation',
          details: err,
        });
      });
  } catch (error) {
    console.error('save-simulation-error', error);
    return res.status(500).json({
      error: true,
      message: 'Cannot Save Simulation',
      details: error,
    });
  }
};

exports.patch_simulation = async (req, res) => {
  try {
    const { SCHEMA_TABLE } = process.env;
    let { simulation_id } = req.params;
    const { name, description, location, statistics, zc, competitors, store_properties } = req.body;
    let set_values = [`name='${name}'`];
    set_values.push(`location=${location ? `'${JSON.stringify(location)}'` : 'null'}`);
    set_values.push(`statistics=${statistics ? `'${JSON.stringify(statistics)}'` : 'null'}`);
    set_values.push(`zc=${zc ? `'${JSON.stringify(zc)}'` : 'null'}`);
    set_values.push(`description=${description ? `'${description.replace(/'/g, "''")}'` : 'null'}`);
    set_values.push(`store_properties=${store_properties ? `'${JSON.stringify(store_properties)}'` : 'null'}`);

    const update_query = `UPDATE ${SCHEMA_TABLE}.ggo_simulation
    SET ${set_values.join(', ')}
    WHERE id='${simulation_id}'`;
    postgres
      .query(update_query)
      .then(async (res_update) => {
        const { clear_cannibalisation } = require('../helpers/cannibalisation');
        console.log('Let clear cannibalisation table');
        clear_cannibalisation(simulation_id);
        console.log('next ');

        const { update_competitors } = require('../helpers/competitors');
        const res_update_competitors = await update_competitors(simulation_id, competitors);
        console.log(JSON.stringify(res_update_competitors));

        let update_results = {
          competitors: res_update_competitors,
        };

        const { update_simulation_zones_table } = require('../helpers/zones');
        const res_update_zones = await update_simulation_zones_table(simulation_id, zc.zones);
        console.log(JSON.stringify(res_update_zones));

        update_results.zones = res_update_zones;
        res.status(200).json({
          success: true,
          message: 'Simulation patch Success',
          data: { id: simulation_id, updated: true, nb_updated: res_update.rowCount, update_results },
        });
      })
      .catch((err) => {
        return res.status(500).json({
          error: true,
          message: 'Cannot patch Simulation',
          details: err,
        });
      });
    /*
    debugger;
    res.status(200).json({
      success: true,
      message: 'TODO: Simulation update Success',
    });
    */
  } catch (error) {
    console.error('patch-simulation-error', error);
    return res.status(500).json({
      error: true,
      message: 'Cannot Patch Simulation',
      details: error,
    });
  }
};

exports.delete_similation = async (req, res) => {
  try {
    const { SCHEMA_TABLE } = process.env;
    const { simulation_id } = req.params;
    const query = `DELETE FROM ${SCHEMA_TABLE}.ggo_simulation WHERE id='${simulation_id}'`;
    postgres.query(query).then((res_delete) => {
      res.status(200).json({
        success: true,
        message: 'Simulation deleted',
        nb_deleted: res_delete.rowCount,
      });
    });
  } catch (error) {
    console.error('delete-simulation-error', error);
    return res.status(500).json({
      error: true,
      message: 'Failed to delete simulation',
      details: error,
    });
  }
};

/*
exports.run_simulation = async (req, res) => {
  require('../run/index').run_simulation(req, res);
};

exports.get_simulation_job = async (req, res) => {
  require('../run/index').get_job_status(req, res);
};
*/
