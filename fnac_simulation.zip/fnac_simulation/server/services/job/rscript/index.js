/*
  TODO : ajouter à la table job:
  exec_time: exécution (timestamp)
  error_messsage: message en cas d'erreur
*/

exports.call_run_simulation = async (simulation_id, job_id) => {
  const logger = require('../../../lib/logger');
  const postgres = require('../../../db/postgres');

  logger.warn(`TODO: call R Script for simulation ${simulation_id} and job_id ${job_id}`);
  const { SIMULATION_RSCRIPT_PATH } = process.env;

  const spawn = require('await-spawn');
  const r_script_to_run = `${SIMULATION_RSCRIPT_PATH}`;
  logger.info(`R Script to run: ${r_script_to_run}`);
  spawn('Rscript', [r_script_to_run, simulation_id, job_id])
    .then((rscript_call_res) => {
      const string_res = rscript_call_res.toString();
      logger.info(`R Script Response: ${string_res}`);
    })
    .catch(async (err_spawn) => {
      logger.error(`Failed to run R script ${SIMULATION_RSCRIPT_PATH}: ${err_spawn.message}`);
      console.error(`Failed to run R script ${SIMULATION_RSCRIPT_PATH}`);
      console.error(err_spawn.message);
      const query_error = `UPDATE sc_fnacdarty.ggo_simulation_job
      SET  status='error', error_message='${err_spawn.message}'
      WHERE id_simulation = '${simulation_id}'`;
      try {
        const res_update_job = await postgres.query(query_error);
        logger.info(`Set Job status to 'error' updated: ${res_update_job.rowCount}`);
      } catch (update_error) {
        logger.error(update_error);
      }
    });
};
