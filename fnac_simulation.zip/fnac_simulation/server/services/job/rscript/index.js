exports.call_run_simulation = async (simulation_id, job_id) => {
  const logger = require('../../../lib/logger');

  console.warn(`TODO: call R Script for simulation ${simulation_id} and job_id ${job_id}`);
  const postgres = require('../../../db/postgres');
  const { SCHEMA_TABLE, SIMULATION_RSCRIPT_PATH } = process.env;

  console.log('Nettoyage de la cannibalisation');
  const clear_cannibalisation_query = `DELETE FROM ${SCHEMA_TABLE}.ggo_simulation_cannibalisation WHERE id_simulation = '${simulation_id}'`;
  const clear_cannibalisation_result = await postgres.query(clear_cannibalisation_query);
  console.log(`CANNIBALISATION: ${clear_cannibalisation_result.rowCount} rows removed`);
  const spawn = require('await-spawn');
  try {
    const rscript_call_res = await spawn('Rscript', [`${SIMULATION_RSCRIPT_PATH}`, simulation_id, job_id]);
    const string_res = rscript_call_res.toString();
    console.log(`R Script Response: ${string_res}`);
  } catch (err_spawn) {
    logger.error(`Failed to run R script ${SIMULATION_RSCRIPT_PATH}: ${err_spawn.message}`);
    console.error(`Failed to run R script ${SIMULATION_RSCRIPT_PATH}: ${err_spawn.message}`);
  }
};
