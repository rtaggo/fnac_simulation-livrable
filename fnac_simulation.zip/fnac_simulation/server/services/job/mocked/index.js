exports.call_run_simulation = async (simulation_id, job_id) => {
  console.warn(`TODO: Mocked Script for simulation ${simulation_id} and job_id ${job_id}`);
  const postgres = require('../../../db/postgres');
  const { SCHEMA_TABLE } = process.env;

  console.log('Nettoyage de la cannibalisation');
  const clear_cannibalisation_query = `DELETE FROM ${SCHEMA_TABLE}.ggo_simulation_cannibalisation WHERE id_simulation = '${simulation_id}'`;
  const clear_cannibalisation_result = await postgres.query(clear_cannibalisation_query);
  console.log(`CANNIBALISATION: ${clear_cannibalisation_result.rowCount} rows removed`);
  console.log('Simulation des étapes');

  const { sleep } = require('../../../helpers/tools');
  const WAITING_TIME = 2000;
  let steps = [
    {
      status: 'Queued',
    },
    {
      status: 'Start',
    },
    {
      status: 'Building',
    },
    {
      status: 'Finishing',
    },
    {
      status: 'done',
    },
  ];
  const nb_steps = steps.length;
  for (let i = 0; i < nb_steps - 1; i++) {
    const c_step = steps[i];
    console.log(`Sleeping for ${WAITING_TIME} ms before starting step ${c_step.status}`);
    await sleep(WAITING_TIME);
    const query_update = `UPDATE ${SCHEMA_TABLE}.ggo_simulation_job
    SET status='${c_step.status}'
    WHERE id='${job_id}'`;
    await postgres.query(query_update);
  }

  const c_step = steps[steps.length - 1];
  console.log(`Sleeping for ${WAITING_TIME} ms before starting step ${c_step.status} (last step)`);
  await sleep(WAITING_TIME);
  const { get_random_int } = require('../../../helpers/numbers');
  console.log('Mise à jour estimation_ca des IRIS');
  const update_zones = `UPDATE ${SCHEMA_TABLE}.ggo_simulation_zones
	SET estimation_ca=floor(random() * (50000-20+1) + 20)
	WHERE id_simulation = '${simulation_id}'`;
  const update_zones_res = await postgres.query(update_zones);
  console.log(`Nb zones updated: ${update_zones_res.rowCount}`);
  console.log('Mise à jour de la cannibalisation');
  const max_cannibalisation = get_random_int(5, 50);
  const query_cannibalisation = `WITH sub_iris as (
    SELECT code_iris FROM sc_fnacdarty.ggo_simulation_zones WHERE id_simulation = '${simulation_id}'
    ), pdvs as (
      SELECT f.code_pdv, f.code_iris FROM ${SCHEMA_TABLE}.fnac_pdv f JOIN sub_iris s ON f.code_iris = s.code_iris LIMIT ${max_cannibalisation}
    )
    INSERT INTO ${SCHEMA_TABLE}.ggo_simulation_cannibalisation(id_simulation, id_pdv, code_iris, estimation_ca_perdu)
    SELECT '${simulation_id}' as id_simulation, p.*, floor(random() * (50000-20+1) + 20) as estimation_ca_perdu
    FROM pdvs p`;
  const insert_cannibalisation_res = await postgres.query(query_cannibalisation);
  console.log(`Nb cannibalisation inserted: ${insert_cannibalisation_res.rowCount}`);

  const query_update = `UPDATE ${SCHEMA_TABLE}.ggo_simulation_job
    SET status='${c_step.status}'
    WHERE id='${job_id}'`;
  await postgres.query(query_update);
  console.log('done');
};
