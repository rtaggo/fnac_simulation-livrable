'use strict';

const express = require('express');
const router = express.Router();
const checkAuth = require('../../middleware/check-auth');

const SimulationService = require(`../../services/simulation/${process.env.SIMULATION_MODE}`);

router.get('/', checkAuth, SimulationService.get_user_simulations);
router.get('/:simulation_id', checkAuth, SimulationService.get_simulation_details);
/*
router.get('/:simulation_id/run', checkAuth, SimulationService.run_simulation);
router.get('/:simulation_id/run/:job_id', checkAuth, SimulationService.get_simulation_job);
*/
router.post('/', checkAuth, SimulationService.save_simulation);
router.delete('/:simulation_id', checkAuth, SimulationService.delete_similation);
router.patch('/:simulation_id', checkAuth, SimulationService.patch_simulation);
router.get('/lock/:simulation_id', checkAuth, SimulationService.lock_simulation);
router.get('/export/:simulation_id', checkAuth, SimulationService.export_simulation);


/**
 * Errors on "/simulation/*" routes.
 */
router.use((err, req, res, next) => {
  // Format error and forward to generic error handler for logging and
  // responding to the request
  err.response = err.message;
  next(err);
});

module.exports = router;
