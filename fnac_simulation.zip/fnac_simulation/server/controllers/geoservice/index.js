'use strict';

const express = require('express');
const router = express.Router();
const logger = require('../../lib/logger');

router.get('/', (req, res) => {
  res.header('Content-Type', 'application/json');
  res.json({ message: '[GET] /rest/geoservice', api: 'alive!!!' });
});

router.get('/geocode/search', (req, res) => {
  res.header('Content-Type', 'application/json');
  //const { geocode_search } = require('../../services/geoservice/here');
  const { GEOCODER = 'galigeo' } = process.env;
  const { geocode_search } = require(`../../services/geoservice/${GEOCODER}`);
  const { q } = req.query;
  geocode_search(q)
    .then((result) => {
      res.json(result);
    })
    .catch((err) => {
      logger.error('Failed to geocode');
      logger.error(err);
      return res.status(500).json({
        error: true,
        message: 'Failed to geocode',
        details: err,
      });
    });
});

router.get('/geocode/reverse', (req, res) => {
  res.header('Content-Type', 'application/json');
  const { reverse_geocode } = require('../../services/geoservice');
  const lat = req.query.lat;
  const lng = req.query.lng;
  reverse_geocode({ lat, lng })
    .then((result) => {
      res.json(result);
    })
    .catch((err) => {
      logger.error('Failed to reverse geocode');
      logger.error(err);
      return res.status(500).json({
        error: true,
        message: 'Failed to reverse geocode',
        details: err,
      });
    });
});

router.get('/direction/isochrone', (req, res) => {
  res.header('Content-Type', 'application/json');
  const { compute_isochrone } = require('../../services/geoservice');
  const { lat, lng, time_limits, profile } = req.query;
  compute_isochrone(lat, lng, time_limits, profile)
    .then((result) => {
      res.json(result);
    })
    .catch((err) => {
      logger.error('Failed to compute isochrone');
      logger.error(err);
      return res.status(500).json({
        error: true,
        message: 'Failed to compute isochrone',
        details: err,
      });
    });
});

/**
 * Errors on "/geoservice/*" routes.
 */
router.use((err, req, res, next) => {
  // Format error and forward to generic error handler for logging and
  // responding to the request
  err.response = err.message;
  next(err);
});

module.exports = router;
