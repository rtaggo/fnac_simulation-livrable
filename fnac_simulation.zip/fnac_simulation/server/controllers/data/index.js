'use strict';

const express = require('express');
const router = express.Router();
const checkAuth = require('../../middleware/check-auth');

const DataService = require(`../../services/data`);

router.get('/', checkAuth, () => {
  return 'data';
});
router.post('/demography', (req, res) => {
  let zones = req.body;
  DataService.getDemography(zones, (errors, result) => {
    res.header('Content-Type', 'application/json');
    if (errors) {
      return res.status(500).json({
        error_code: 5002,
        message: 'Failed to query stats in area',
        details: errors,
      });
    }
    res.json(result);
  });
});
/**
 * List of store types to feed the combo
 * on the simu panel
 */
router.get('/type_mag', (req, res) => {
  res.header('Content-Type', 'application/json');
  res.json(DataService.getTypeMags());
  
});

/**
 * Errors on "/simulation/*" routes.
 */
router.use((err, req, res, next) => {
  // Format error and forward to generic error handler for logging and
  // responding to the request
  err.response = err.message;
  next(err);
});

module.exports = router;
