'use strict';

const express = require('express');
const router = express.Router();
const checkAuth = require('../../middleware/check-auth');

const UserService = require(`../../services/user/${process.env.USER_MODE}`);

router.get('/', checkAuth, (req, res) => {
  res.header('Content-Type', 'application/json');
  res.json({ message: '[GET] /rest/user', api: 'alive!!!' });
});

router.post('/signup', UserService.signup);
router.post('/login', UserService.login);
router.get('/logout', checkAuth, UserService.logout);
router.get('/current', checkAuth, UserService.current);

/**
 * Errors on "/user/*" routes.
 */
router.use((err, req, res, next) => {
  // Format error and forward to generic error handler for logging and
  // responding to the request
  err.response = err.message;
  next(err);
});

module.exports = router;
