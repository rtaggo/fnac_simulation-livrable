'use strict';

const express = require('express');
const router = express.Router();
const checkAuth = require('../../middleware/check-auth');

const JobService = require(`../../services/job`);

router.get('/', checkAuth, JobService.get_jobs);
router.get('/submit', checkAuth, JobService.submit_job);
router.get('/:job_id', checkAuth, JobService.get_job_details);

/**
 * Errors on "/simulation/*" routes.
 */
router.use((err, req, res, next) => {
  // Format error and forward to generic error handler for logging and
  // responding to the request
  err.response = err.message;
  next(err);
});

module.exports = router;
