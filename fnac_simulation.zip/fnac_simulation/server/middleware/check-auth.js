const jwt = require('jsonwebtoken');
const { generateJwt } = require('../helpers/jwt');
module.exports = (req, res, next) => {
  const { check_login } = require('../services/user/galigeo');
  //console.log(`check-auth. req: ${req.path}`);
  try {
    const token = req.cookies[process.env.JWT_TOKENNAME] || (req.headers['authorization'] ? req.headers['authorization'].split(' ')[1] : undefined);
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    req.decodedUser = decoded;
    next();
  } catch (error) {
    check_login(req.query.ggo_token)
      .then(async (result) => {
        const { error, token } = await generateJwt(result.data.user, result.data.profile);
        if (error) {
          return res.status(500).json({
            error: true,
            message: "Couldn't create access token. Please try again later",
          });
        }
        const expires_cookie = new Date(Date.now() + 31536000);
        const max_age_cookie = 30 * 24 * 60 * 60 * 1000; // 30 days;
        res.cookie(process.env.JWT_TOKENNAME, token, {
          httpOnly: true,
          secure: process.env.NODE_ENV === 'production' ? true : false,
          expires: expires_cookie,
          maxAge: max_age_cookie,
        });
        next();
      })
      .catch((err) => {
        const redirectToLoginSet = new Set(['/', '/simulation']);
        if (redirectToLoginSet.has(req.path)) {
          let query_params = '';
          const query_entries = Object.entries(req.query);
          if (query_entries.length > 0) {
            query_params = `?${query_entries.map((e) => `${e[0]}=${e[1]}`).join('&')}`;
          }

          const UserService = require(`../services/user/${process.env.USER_MODE}`);
          return res.redirect(UserService.get_login_url(req));
        }

        return res.status(401).json({
          error: true,
          message: 'Authentication failed',
        });
      });
  }
};
