import EventBus from '../helpers/eventbus.mjs';
import { alert } from '../helpers/messages.mjs';
import ZonesChalandises from '../model/zones_chalandises.mjs';
import LocationManager from './location_manager.mjs';
import { MAPISLOADED, PROJECTLOADED, ISOCHRONECOMPUTED, LOCATIONCHANGED, ISOCHRONEVALIDATED } from '../constants/events.mjs';
import { color_buckets } from '../constants/colors.mjs';
import { compute_isochrone } from '../services/geoservice.mjs';

//import Zone from '../model/zone.mjs';

class ZoneManager {
  constructor(zc, options = {}) {
    const nullFunc = () => {};

    this.options_ = {
      ...{
        container: 'body',
        isVisible: true,
        isEnabled: true,
        isochronesComputedCallback: nullFunc,
      },
      ...options,
    };
    this.zc = zc;
    /*
    this.configuration_ = {
      drivetime: {
        mode: 'foot-walking',
      },
    };
    this.zones_ = [];
    */
    this.current_location_ = {};
    this.init_();
    ZoneManager.instance_ = this;
    return this;
  }

  static getInstance(zc, options = {}) {
    if (ZoneManager.instance_) {
      return ZoneManager.instance_;
    }

    return new ZoneManager(zc, options);
  }

  init_() {
    this.setupListeners_();
  }

  setupListeners_() {
    /*
    EventBus.addEventListener(LOCATIONCHANGED, (e) => {
      this.handleLocationChangedEvent(e.target);
      $('#zone-transport-mode-container .slds-button').attr('disabled', false);
      $('#zones-actions-buttons .slds-button').attr('disabled', false);
      $('#zones-list-container input[type="number"]').attr('disabled', false);
    });
    */
    EventBus.addEventListener(
      MAPISLOADED,
      (e) => {
        this.map_ = e.target.map;
        this.findMapFirstSymbolId();
      },
      this
    );

    EventBus.addEventListener(PROJECTLOADED, (e) => {
      this.zc = e.target.getZc();
      this.current_location_ = e.target.location;
      this.refreshZonesList();
    });

    EventBus.addEventListener(LOCATIONCHANGED, (e) => {
      this.current_location_ = e.target;
      this.refreshZoneAreas();
    });

    $(`#zones-tab .slds-visual-picker input`).on('click', (e) => {
      let $tgt = $(e.currentTarget);
      const transport_mode = $tgt.val();
      this.zc.setProfile(transport_mode);
      this.refreshZoneAreasDelayed();
    });
  }

  findMapFirstSymbolId() {
    var layers = this.map_.getStyle().layers;
    // Find the index of the first symbol layer in the map style
    for (var i = 0; i < layers.length; i++) {
      if (layers[i].type === 'symbol' || layers[i].id === 'road-street') {
        this.firstSymbolId = layers[i].id;
        break;
      }
    }
  }

  render() {
    console.log('render zone manager');
    new LocationManager({ container: 'location-container' });

    let $content = $('#zones-tab');

    /*if(this.zc) {
      $content.find(`.transport-modes-grid .slds-icon_container[data-transportmode="${this.zc.getProfile()}"]`).addClass('is-selected');
    } else {
      console.error('Missing ZC in render');
    }*/
    /*$content.find('.transport-modes-grid .slds-icon_container').on('click', (e) => {
      let $tgt = $(e.currentTarget);
      $tgt.parent().siblings().find('.slds-icon_container').removeClass('is-selected');
      $tgt.addClass('is-selected');
      const transport_mode = $tgt.data('transportmode');
      this.zc.setProfile(transport_mode);
      this.refreshZoneAreasDelayed();
    });*/
    /*
    $content.find('#zone-transport-mode-container .slds-button').on('click', (e) => {
      let $tgt = $(e.currentTarget);
      $tgt.siblings().removeClass('slds-is-selected').attr('aria-pressed', false);
      $tgt.addClass('slds-is-selected').attr('aria-pressed', true).blur();
      this.zc.setProfile($tgt.data('transportmode'));
      //this.refreshZoneAreas();
    });
    */

    // by default the action buttons are not enabled
    $('#zones-validate-button').attr('disabled', 'true');

    $content.find('#zones-actions-buttons .slds-button').on('click', (e) => {
      const action = $(e.currentTarget).data('action');
      if (action === 'compute') {
        //this.options_.getParameterManager().closeParameterPanel();
        this.refreshZoneAreas();
        //EventBus.dispatch(ISOCHRONEVALIDATED, this.zc);
        return;
      }

      if (action === 'reset') {
        this.resetToDefaultZones();
        return;
      }

      if (action === 'validate') {
        //this.options_.getParameterManager().closeParameterPanel();
        //this.refreshZoneAreas();
        EventBus.dispatch(ISOCHRONEVALIDATED, this.zc);
        return;
      }
    });
    //$(`#${this.options_.container}`).append($content);
    //this.refreshZonesList();
  }

  resetToDefaultZones() {
    this.zc.getZones().forEach((z, i) => {
      z.setRange(i * 5 + 5);
      $(`#zones-list-container input[data-zoneid="${z.getId()}"]`).val(z.getRange());
    });
  }

  setLocation(coordinates, zones = {}) {
    this.current_location_.coordinates = coordinates;
    this.zones = zones;
    this.activate();
    const isOK = this.checkGivenZones();
    if (isOK) {
      EventBus.dispatch(ISOCHRONECOMPUTED, this.isochrone_geojson);
    } else {
      this.refreshZoneAreas();
    }
  }

  setZC(value) {
    this.zc = value;
  }

  activate() {
    const { coordinates } = this.current_location_;
    if (coordinates) {
      $('#zones-actions-buttons .slds-button').attr('disabled', false);
      $('#zones-list-container input[type="number"]').attr('disabled', false);
    }
  }

  refreshZonesList() {
    let $ctnr = $('#zones-list-container').empty();
    let $content = $(`
      <div class="slds-form">
      ${this.zc
        .getZones()
        .map((z) => {
          return z.getHTMLElement();
        })
        .join('')}
      </div>
    `);

    // select the profile radio
    $('#zones-tab').find(`input[value="${this.zc.getProfile()}"]`).attr('checked', 'true');

    $content.find('.slds-button.slds-input__button_decrement').on('click', (e) => {
      let $input = $(e.currentTarget).siblings('input[type="number"]');
      let t_val = $input.val();
      const i_min = +$input.attr('min');
      t_val = Math.max(+t_val - 1, i_min);
      $input.val(t_val).trigger('change');
      this.setModificationsNotCalculated();
    });

    $content.find('.slds-button.slds-input__button_increment').on('click', (e) => {
      let $input = $(e.currentTarget).siblings('input[type="number"]');
      let t_val = $input.val();
      const i_max = +$input.attr('max');
      t_val = Math.min(+t_val + 1, i_max);
      $input.val(t_val).trigger('change');
      this.setModificationsNotCalculated();
    });

    $content.find('input[type="number"]').on('change', (e) => {
      let $tgt = $(e.currentTarget);
      this.validateRangeValues($tgt);
      $('#zones-validate-button').attr('disabled', 'true');
    });
    $ctnr.append($content);
    $('#zones-container').removeClass('slds-hide');
  }

  validateRangeValues($tgt) {
    const zoneid = +$tgt.data('zoneid');
    let range = +$tgt.val();
    const i_min = +$tgt.attr('min');
    const i_max = +$tgt.attr('max');
    if (range < i_min) {
      range = i_min;
      $tgt.val(range);
    }
    if (range > i_max) {
      range = i_max;
      $tgt.val(range);
    }
    let zone = this.zc.getZones().find((z) => z.getId() === zoneid);
    if (!zone) {
      return;
    }
    zone.setRange(range);
    let zones = this.zc.getZones();
    let z1 = zones[0];
    let z2 = zones[1];
    let z3 = zones[2];
    let n_range = null;
    if (zoneid === 0) {
      if (z1.getRange() >= z2.getRange()) {
        n_range = z1.getRange() + 1;
        z2.setRange(n_range);
        $(`#zones-list-container input[data-zoneid="${z2.getId()}"]`).val(n_range);
      }
      if (z2.getRange() >= z3.getRange()) {
        n_range = z2.getRange() + 1;
        z3.setRange(n_range);
        $(`#zones-list-container input[data-zoneid="${z3.getId()}"]`).val(n_range);
      }
    } else if (zoneid === 1) {
      if (z2.getRange() <= z1.getRange()) {
        n_range = z2.getRange() - 1;
        z1.setRange(n_range);
        $(`#zones-list-container input[data-zoneid="${z1.getId()}"]`).val(n_range);
      }
      if (z2.getRange() >= z3.getRange()) {
        n_range = z2.getRange() + 1;
        z3.setRange(n_range);
        $(`#zones-list-container input[data-zoneid="${z3.getId()}"]`).val(n_range);
      }
    } else {
      if (z3.getRange() <= z2.getRange()) {
        n_range = z3.getRange() - 1;
        z2.setRange(n_range);
        $(`#zones-list-container input[data-zoneid="${z2.getId()}"]`).val(n_range);
      }
      if (z2.getRange() <= z1.getRange()) {
        n_range = z2.getRange() - 1;
        z1.setRange(n_range);
        $(`#zones-list-container input[data-zoneid="${z1.getId()}"]`).val(n_range);
      }
    }
  }

  getNeighboringZones(zoneId) {
    let previous = null;
    let next = null;
    let all_zones = this.zc.getZones();
    if (zoneId === 0) {
      next = all_zones.find((z) => z.getId() === zoneId + 1);
      return { next };
    }
    if (zoneId === all_zones.length - 1) {
      previous = all_zones.find((z) => z.getId() === zoneId - 1);
      return { previous };
    }
    next = all_zones.find((z) => z.getId() === zoneId + 1);
    previous = all_zones.find((z) => z.getId() === zoneId - 1);

    return { previous, next };
  }

  setModificationsNotCalculated() {
    $('#zones-msg-container').removeClass('slds-hide');
  }

  refreshZoneAreasDelayed() {
    const now = new Date().getTime();
    this.pendingRequest = false;
    if (!this.lastRefresh || now - this.lastRefresh > 1000) {
      this.lastRefresh = now;
      this.refreshZoneAreas();
    } else {
      this.pendingRequest = true;
      setTimeout(() => {
        this.refreshZoneAreasDelayed();
      }, 1000);
    }
  }

  refreshZoneAreas() {
    if (!this.current_location_) {
      //alert('#compute_isochrone_notify', "Veuillez choisir une adresse pour définir les zones");
      return;
    }

    $('#notification_container').append(
      $(`
    <div id="compute_isochrone_notify" class="slds-notify slds-notify_toast slds-theme_info" role="status">
      <div class="slds-m-right_small">
        <div role="status" class="slds-spinner slds-spinner_x-small slds-is-relative">
          <span class="slds-assistive-text">Loading</span>
          <div class="slds-spinner__dot-a"></div>
          <div class="slds-spinner__dot-b"></div>
        </div>
      </div>
      <div class="slds-notify__content">
        <h2 class="slds-text-heading_small">Calcul des isochrones</h2>
      </div>
    </div>`)
    );

    this.zc.center = this.current_location_.coordinates;

    $('#zones-msg-container').addClass('slds-hide');

    compute_isochrone(
      this.current_location_.coordinates,
      this.zc.getZones().map((z) => z.getRange()),
      this.zc.getProfile(),
      (response) => {
        this.handleIsochroneComputed(response);
        $('#compute_isochrone_notify').remove();
      },
      (error) => {
        console.error('Failed to compute isochrones', error);
        $('#compute_isochrone_notify')
          .removeClass('slds-theme_info')
          .addClass('slds-theme_warning')
          .empty()
          .append(
            $(`
        <span class="slds-assistive-text">warning</span>
        <span class="slds-icon_container slds-icon-utility-warning slds-m-right_small slds-no-flex slds-align-top" title="Description of icon when needed">
          <svg class="slds-icon slds-icon_small" aria-hidden="true">
            <use xlink:href="/styles/slds/assets/icons/utility-sprite/svg/symbols.svg#warning"></use>
          </svg>
        </span>
        <div class="slds-notify__content">
          <h2 class="slds-text-heading_small ">Une erreur est survenue lors du calcul des isochrones</h2>
        </div>`)
          );
        setTimeout(() => {
          $('#compute_isochrone_notify').remove();
        }, 2000);
      }
    );
  }

  handleIsochroneComputed(response) {
    // enable the action buttons
    $('#zones-validate-button').attr('disabled', false);

    this.options_.isochronesComputedCallback();
    const biggest_zone = response.features.splice(3);
    response.features.forEach((f) => {
      f.properties.color = color_buckets[f.properties.bucket];
    });
    this.isochrone_geojson = response;
    //let combined = turf.combine(this.isochrone_geojson);
    this.zc.getZones(0).setGeometry(this.isochrone_geojson.features[2].geometry);
    this.zc.getZones(1).setGeometry(this.isochrone_geojson.features[1].geometry);
    this.zc.getZones(2).setGeometry(this.isochrone_geojson.features[0].geometry);
    //this.zc.globalGeometry = biggest_zone[0].geometry;
    /*this.zones = {
      zone_global: biggest_zone[0].geometry,
      zone_primaire: this.isochrone_geojson.features[2].geometry,
      zone_secondaire: this.isochrone_geojson.features[1].geometry,
      zone_tertiaire: this.isochrone_geojson.features[0].geometry,
    };*/
    /*
    if (typeof this.map_.getSource('drivetime') === 'undefined') {
      this.map_.addSource('drivetime', { type: 'geojson', data: response });
      this.addIsochroneToMap();
    } else {
      this.map_.getSource('drivetime').setData(response);
    }
    let bbox = turf.bbox(this.isochrone_geojson);
    this.map_.fitBounds(bbox, { padding: 20 });
    */
    //this.addIsochroneSourceAndLayer(this.isochrone_geojson);
    EventBus.dispatch(ISOCHRONECOMPUTED, this.zc);
  }

  /*addIsochroneSourceAndLayer(geojson) {
    if (typeof this.map_.getSource('drivetime') === 'undefined') {
      this.map_.addSource('drivetime', { type: 'geojson', data: geojson });
      this.addIsochroneToMap();
    } else {
      this.map_.getSource('drivetime').setData(geojson);
    }
    let bbox = turf.bbox(geojson);
    this.map_.fitBounds(bbox, { padding: 20 });
  }*/

  addIsochroneToMap() {
    /*
    this.map_.addLayer(
      {
        id: 'drivetime_layer',
        type: 'fill',
        source: 'drivetime',
        paint: {
          'fill-color': ['get', 'color'],
          'fill-opacity': 0.7,
          'fill-outline-color': '#ABABAB',
        },
      },
      this.firstSymbolId
    );
    */
    this.map_.addLayer({
      id: 'drivetime_layer',
      type: 'fill-extrusion',
      source: 'drivetime',
      paint: {
        'fill-extrusion-color': ['get', 'color'],
        'fill-extrusion-opacity': 0.7,
        'fill-extrusion-base': 0,
        'fill-extrusion-height': ['*', 20, ['-', 3, ['get', 'bucket']]],
      },
    });
  }

  cleanAll() {
    if (typeof this.map_.getLayer('drivetime_layer') !== 'undefined') {
      this.map_.removeLayer('drivetime_layer');
    }
    if (typeof this.map_.getSource('drivetime') !== 'undefined') {
      this.map_.removeSource('drivetime');
    }
  }

  checkGivenZones() {
    if (!this.zones.zone_global || !this.zones.zone_primaire || !this.zones.zone_secondaire || !this.zones.zone_tertiaire) {
      return false;
    }
    this.isochrone_geojson = {
      type: 'FeatureCollection',
      features: [
        {
          type: 'Feature',
          geometry: this.zones.zone_tertiaire,
          properties: {
            bucket: 2,
            color: color_buckets[2],
          },
        },
        {
          type: 'Feature',
          geometry: this.zones.zone_secondaire,
          properties: {
            bucket: 1,
            color: color_buckets[1],
          },
        },
        {
          type: 'Feature',
          geometry: this.zones.zone_primaire,
          properties: {
            bucket: 0,
            color: color_buckets[0],
          },
        },
      ],
    };
    this.addIsochroneSourceAndLayer(this.isochrone_geojson);
    return true;
  }

  getZonesGeometries() {
    return this.zones;
  }
}

export default ZoneManager;
