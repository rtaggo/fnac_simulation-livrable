import { get_type_mag } from '../services/dataservice.mjs';
import EventBus from '../helpers/eventbus.mjs';
import { SIMULATIONLAUCHED, SIMULATIONDONE, PROJECTLOADED, SIMULATIONLOCK, SIMULATIONLOCKED, SIMULATIONEXPORT } from '../constants/events.mjs';

import { combo_box } from '../helpers/combobox.mjs';
import { numberFormat } from '../helpers/numbers.mjs';

export default class ReportManager {
  constructor(options = {}) {
    this.options_ = {
      ...{
        container: 'simulation-container',
      },
      ...options,
    };
    ReportManager.instance_ = this;
    this._currentProgress = 0;
    this._intervalId;

    this.setupListeners();
  }

  static getInstance(options = {}) {
    if (ReportManager.instance_) {
      return ReportManager.instance_;
    }
    return new ReportManager(options);
  }

  setupListeners() {
    EventBus.addEventListener(SIMULATIONDONE, (e) => {
      $('#simulation-progress').addClass('slds-hide');
      clearInterval(this._intervalId);
      if(!e.target) {
        $('#simulation-error').removeClass('slds-hide');
      } else {
        this.displayEstimations(e.target.estimations);
      }
      
      
    });

    EventBus.addEventListener(SIMULATIONLOCKED, () => {
      $('#lock-simulation-btn').addClass('slds-hide');
      $('#lock-simulation-info').removeClass('slds-hide');
      $('#save-simulation-btn').attr('disabled', 'true');
    });

    EventBus.addEventListener(PROJECTLOADED, (e) => {
        if(e.target.locked) EventBus.dispatch(SIMULATIONLOCKED);
        this.store_properties = e.target.store_properties || {};
        this.store_properties.surface = this.store_properties.surface || 1500;
        this.store_properties.type = this.store_properties.type || 'Non renseigné';
        $('#surface-input').val(this.store_properties.surface);
        if(e.target.estimations) {
          this.displayEstimations(e.target.estimations);
          $('#lock-btn').removeClass('slds-hide')
        }
        get_type_mag().then((typeMags)=>{
          combo_box('store-type-combobox', typeMags, this.store_properties.type, (selectedValue)=>{
            this.store_properties.type = selectedValue;
          });
        });
    });
  }

  render() {
    const $content = `
        <div id="report-chevron-right" class="slds-hide">
          <button id="report-chevron-right-btn" class="slds-button slds-button_icon" title="Settings">
            <svg class="slds-button__icon" aria-hidden="true">
            <use xlink:href="/styles/slds/assets/icons/utility-sprite/svg/symbols.svg#chevronright"></use>
            </svg>
            <span class="slds-assistive-text">chevronright</span>
          </button>    
          <span id="store-resume-badge" class="slds-badge slds-badge_lightest" style="font-weight: normal">Surface : -, Type : -</span>
        </div>
        <div id="report-chevron-down">
          <button id="report-chevron-down-btn" class="slds-button slds-button_icon" title="Settings">
            <svg class="slds-button__icon" aria-hidden="true">
             <use xlink:href="/styles/slds/assets/icons/utility-sprite/svg/symbols.svg#chevrondown"></use>
            </svg>
            <span class="slds-assistive-text">chevrondown</span>
          </button>    
          <span>Renseignements sur le magasin</span>
        </div>
        <div id="store-form" class="slds-box">  
          <div class="slds-form">
            <div class="slds-form-element slds-form-element_horizontal">
              <label class="slds-form-element__label" for="surface-input">Surface</label>
                <div class="slds-form-element__control">
                  <input type="number" id="surface-input" placeholder="Surface" class="slds-input" min="0" max="50000" />
                </div>
            </div>
            <div class="slds-form-element slds-form-element_horizontal">
              <label class="slds-form-element__label" for="horizontal-input-id-01">Type de magasin</label>
                <div id="store-type-combobox" class="slds-form-element__control">                  
                </div>
            </div>
          </div>
        </div>
        <div class="slds-p-top_medium slds-align_absolute-center">
          <button id="save-simulation-btn" class="slds-button slds-button_neutral" style="width: 100%">
            <svg class="slds-button__icon slds-button__icon_left" aria-hidden="true">
              <use xlink:href="/styles/slds/assets/icons/utility-sprite/svg/symbols.svg#light_bulb"></use>
            </svg>Lancer la simulation
          </button>
          <button id="lock-simulation-btn" class="slds-button slds-button_icon slds-icon-utility-announcement slds-hide" title="Vérouiller la simulation">
            <svg class="slds-button__icon slds-button__icon_large" aria-hidden="true">
            <use xlink:href="/styles/slds/assets/icons/utility-sprite/svg/symbols.svg#unlock"></use>
            </svg>
            <span class="slds-assistive-text">unlock</span>
          </button> 
          <span id="lock-simulation-info" class="slds-icon_container slds-icon-utility-announcement slds-hide" title="Le projet est vérouillé">
            <svg class="slds-icon slds-icon-text-default" aria-hidden="true">
              <use xlink:href="/styles/slds/assets/icons/utility-sprite/svg/symbols.svg#lock"></use>
            </svg>
            <span class="slds-assistive-text">Le projet est vérouillé</span>
          </span>
        </div>
        <div id="simulation-progress" class="slds-p-top_medium slds-align_absolute-center slds-hide">
          <div class="slds-progress-bar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="25" aria-label="{{Placeholder for description of progress bar}}" role="progressbar">
            <span class="slds-progress-bar__value" style="width:0%">
            <span class="slds-assistive-text">Progress: 25%</span>
          </span>
          </div>
        </div>
        <div id="simulation-error" class="slds-p-top_small slds-hide"><span class="slds-badge slds-theme_error">Le traitement a échoué, le résultat de la simulation n'est pas disponible.</span></div>
        <div id="report-result-container" class="slds-align_absolute-center slds-p-top_medium slds-hide">
          <div class="slds-grid slds-gutters" style="width:100%">
            <div class="stat_tile slds-col slds-size_1-of-2 slds-p-vertical_small" style="">
              <div class="slds-box slds-box_small" style="text-align: center;background-color: #cfd1ef">
                <div id="estimation_ca" style="font-size: 24px;line-height: 24px;color: grey;">60 %</div>
                <div>Chiffre d'affaire</div>
              </div>
            </div>
            <div class="stat_tile slds-col slds-size_1-of-2 slds-p-vertical_small" style="">
              <div class="slds-box slds-box_small" style="text-align: center;background-color: #c7bf85">
                <div id="estimation_perte_ca" style="font-size: 24px;line-height: 24px;color: grey;">6 000 000</div>
                  <div>Canibalisation</div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div id="report-export-container" class="slds-align_absolute-center slds-p-top_medium slds-hide">
          <a id="report-export-btn" class="slds-text-title_caps">Exporter le détail par Iris (CSV)</a>
        </div>
        `;

    $('#' + this.options_.container).html($content);
    
    
    $('#surface-input').on('change', (e) => {
        try {
          const surface = parseInt($(e.target).val());
          if(surface > 0) this.store_properties.surface = surface;
          else $(e.target).val(this.store_properties.surface);
        } catch(e) {
          $(e.target).val(this.store_properties.surface);
        }
    });

    $('#save-simulation-btn').on('click', (e) => {
      EventBus.dispatch(SIMULATIONLAUCHED, this.store_properties);
      $('#simulation-error').addClass('slds-hide');
      $('#simulation-progress').removeClass('slds-hide');
      $('#report-result-container').addClass('slds-hide');

      const incrementProgress = () => {
        if (this._currentProgress > 95) this._currentProgress += 0;
        else if (this._currentProgress > 90) this._currentProgress += 1;
        else if (this._currentProgress > 80) this._currentProgress += 2;
        else this._currentProgress += 10;
        $('#simulation-progress')
          .find('.slds-progress-bar__value')
          .css('width', this._currentProgress + '%');
      };

      this._currentProgress = 0;
      this._intervalId = setInterval(incrementProgress, 1500);
    });

    $('#report-chevron-right').on('click', (e) => {
      this.setStoreFormVisible(true);
    });
    $('#report-chevron-down-btn').on('click', (e) => {
      this.setStoreFormVisible(false);
    });
    $('#lock-simulation-btn').on('click', (e) => {
      EventBus.dispatch(SIMULATIONLOCK, this.store_properties);
    });
    $('#report-export-btn').on('click', (e) => {
      EventBus.dispatch(SIMULATIONEXPORT, this.store_properties);
    });
  }

  setStoreFormVisible(visible) {
    if(visible) {
      $('#report-chevron-right').addClass('slds-hide');
      $('#report-chevron-down').removeClass('slds-hide');
      $('#store-form').removeClass('slds-hide');
    } else {
      $('#report-chevron-right').removeClass('slds-hide');
      $('#report-chevron-down').addClass('slds-hide');
      $('#store-form').addClass('slds-hide');
      $('#store-resume-badge').html(`Surface : ${this.store_properties.surface}, type : ${this.store_properties.type} `);
    }
  }

  displayEstimations(estimations) {
    this.setStoreFormVisible(false);
    
    if(estimations) {
      $('#report-result-container').removeClass('slds-hide');
      $('#estimation_ca').html(numberFormat(estimations.estimation_ca) + ' €');
      $('#estimation_perte_ca').html(numberFormat(estimations.estimation_perte_ca) +' €');
      $('#report-export-container').removeClass('slds-hide');
      if($('#lock-simulation-info').hasClass('slds-hide')) $('#lock-simulation-btn').removeClass('slds-hide');
    } else alert('Les estimations prévisionnelles n\'ont pas pu être calculées');
  }
}
