import EventBus from '../helpers/eventbus.mjs';
import { AREASTATSCOMPUTED, AUTHENTICATEDUSER, STATSDETAILSVISIBILITY, PROJECTLOADED } from '../constants/events.mjs';
import { display_stats_details } from '../helpers/stats_renderer.mjs';
import { numberFormatCompact } from '../helpers/numbers.mjs';

/**
 * Display the stat panel when AREASTATSCOMPUTED is dispatched
 */
export default class StatisticManager {
  constructor(options = {}) {
    this.options_ = {
      ...{
        container: 'appContainer',
      },
      ...options,
    };
    this.current_user_ = options?.current_user ?? null;
    this.stats_fields_ = [
      {
        id: 'potentiel',
        label: 'Potentiel',
        icon: '/styles/slds/assets/icons/standard-sprite/svg/symbols.svg#work_forecast',
        color: '#cfd1ef',
        icon_size: 'slds-icon_large',
        custom_style: 'cursor: pointer',
      },
      {
        id: 'population',
        label: 'Population',
        icon: '/styles/slds/assets/icons/standard-sprite/svg/symbols.svg#swarm_request',
        icon_size: 'slds-icon_medium',
        color: '#ffd5d5' /*'#52B7D8',*/,
        custom_style: 'cursor: pointer',
      },
      {
        id: 'logement',
        label: 'Logements',
        icon: '/styles/slds/assets/icons/standard-sprite/svg/symbols.svg#buyer_account',
        color: '#ffd5d5' /*'#E16032',*/,
        icon_size: 'slds-icon_medium',
        isBottom: true,
        custom_style: 'cursor: pointer',
      },
      {
        id: 'menage',
        label: 'Ménages',
        icon: '/styles/slds/assets/icons/standard-sprite/svg/symbols.svg#household',
        color: '#ffd5d5' /*#54A77B',*/,
        icon_size: 'slds-icon_large',
        isBottom: true,
        custom_style: 'cursor: pointer',
      },
    ];
    this.init_();
    StatisticManager.instance_ = this;
    this.layers_ = [];
    this.stats = {};
    return this;
  }

  static getInstance(options = {}) {
    if (StatisticManager.instance_) {
      return StatisticManager.instance_;
    }
    return new StatisticManager(options);
  }

  init_() {
    const intlNumberFormat2Digits = new Intl.NumberFormat('fr', { minimumFractionDigits: 0, maximumFractionDigits: 0 });
    this.numberFormatter0Digits = (num) => {
      return intlNumberFormat2Digits.format(num);
    };
    this.setupListeners_();
  }

  setupListeners_() {
    EventBus.addEventListener(PROJECTLOADED, (e) => {
      if (e.target.statistics) {
        this.handleAreaStatsComputed(e.target.statistics);
      }
    });

    EventBus.addEventListener(AREASTATSCOMPUTED, (e) => {
      this.handleAreaStatsComputed(e.target);
    });
    EventBus.addEventListener(AUTHENTICATEDUSER, (e) => {
      this.setCurrentUser(e.target);
    });
  }

  setCurrentUser(user) {
    this.current_user_ = user;
  }

  render() {
    let $content = $(`
    <div class="slds-p-around_xx-small">
      <div id="stats-potential-content" class="slds-p-vertical_x-small" style="position:relative;">
        <article class="slds-card slds-card_boundary" style="background: #f3f2f2;">
          <div class="slds-card__body slds-card__body_inner slds-m-vertical_xxx-small">
            <div class="" style="height:3.5rem;"></div>
          </div>
        </article>
      </div>
    </div>
    <div class="slds-p-around_xx-small">
      <div class="slds-text-title_caps">Répartition des CSP et inactifs</div>
      <div id="stats-repartition-content" class="slds-p-vertical_x-small" style="position:relative;">
        <article class="slds-card slds-card_boundary" style="background: #f3f2f2;">
          <div class="slds-card__body slds-card__body_inner slds-m-vertical_xxx-small">
            <div class="" style="height:3.5rem;"></div>
          </div>
        </article>
      </div>
    </div>`);

    $(`#${this.options_.container}`).empty().append($content);
  }

  handleAreaStatsComputed(response) {
    this.stats_responses_ = response;
    $('#stats-container').removeClass('slds-hide');
    this.renderTilesStats(response);
    this.renderResumeStats(response);
  }

  renderTilesStats(response) {
    let $ctnr = $('#stats-potential-content').empty();

    $ctnr.append(
      $(`
      <div class="slds-text-title_caps">Synthèse de la zone</div>
      <div class="slds-grid slds-gutters slds-wrap" style="width: 100%;">
      ${this.renderTileStats(this.stats_fields_[0], response[this.stats_fields_[0].id], numberFormatCompact)}
      ${this.renderTileStats(this.stats_fields_[1], response[this.stats_fields_[1].id])}
      ${this.renderTileStats(this.stats_fields_[2], response[this.stats_fields_[2].id])}
      ${this.renderTileStats(this.stats_fields_[3], response[this.stats_fields_[3].id])}      
    </div>
      `)
    );

    $ctnr.find('.stat_tile').on('click', (e) => {
      const field_id = $(e.currentTarget).data('fieldid');
      const field = this.stats_fields_.find((f) => f.id === field_id);
      if (field) {
        display_stats_details(field, this.stats_responses_, {
          user_is_connected: typeof this.current_user_ !== 'undefined' && this.current_user_ !== null,
        });
        EventBus.dispatch(STATSDETAILSVISIBILITY, { is_visible: true });
      }
    });
  }

  renderTileStats(field, value, numberFormatter) {
    return `
    <div data-fieldid="${field.id}" class="stat_tile slds-col slds-size_1-of-2 slds-p-vertical_small" style="${field.custom_style}">
      <div class="slds-box slds-box_small" style="
        text-align: center;
        background-color: ${field.color}
        ">
        <div style="
            font-size: 24px;
            line-height: 24px;
            color: grey;
            ">${numberFormatter ? numberFormatter(value) : Math.round(value).toLocaleString()}</div>
        <div>${field.label}</div>
      </div>
    </div>`;
  }

  renderResumeStats(response) {
    let p_cspm = ((response.csp_m / response.menage) * 100).toFixed(0);
    let p_cspp = ((response.csp_p / response.menage) * 100).toFixed(0);
    let p_retraites = ((response.men_cs7 / response.menage) * 100).toFixed(0);

    let $ctnr = $('#stats-repartition-content').empty();

    $ctnr.append(
      $(`
      <article class="slds-card slds-card_boundary slds-p-around_xx-small">
        <table class="slds-table slds-table_cell-buffer slds-table_fixed-layout slds-no-row-hover stats-table" aria-labelledby="element-with-table-label other-element-with-table-label">
          <thead>
            <tr class="slds-line-height_reset">
              <th class="" scope="col">
                <div class="slds-truncate slds-text-align_center" title="CSP+">CSP+</div>
              </th>
              <th class="" scope="col">
                <div class="slds-truncate slds-text-align_center" title="CSP-">CSP-</div>
              </th>
              <th class="" scope="col">
                <div class="slds-truncate slds-text-align_center" title="Inactifs">Inactifs</div>
              </th>
            </tr>
          </thead>
          <tbody>
            <tr class="slds-hint-parent">
              <td data-label="CSP+">
                <div class="slds-truncate slds-text-align_center">${p_cspp} %</div>
              </td>
              <td data-label="CSP-">
                <div class="slds-truncate slds-text-align_center">${p_cspm} %</div>
              </td>
              <td data-label="Inactifs">
                <div class="slds-truncate slds-text-align_center">${p_retraites} %</div>
              </td>
            </tr>
          </tbody>
        </table>
      </article>`)
    );
  }

  /*getSampleIrisAnalytics() {
    let $sample = $(`
    <div class="slds-box slds-box_xx-small slds-m-top_small" style="position:relative;">
      <div class="premium-ribbon"><span>PREMIUM</span></div>
      <div class="slds-text-title_caps">Analyses à l'IRIS</div>
      <fieldset class="slds-form-element">
        <div class="slds-form-element__control">
          <span class="slds-radio">
            <input type="radio" id="ind-field_p_pop" value="p_pop" name="ind-field-radio" checked="checked" disabled="">
            <label class="slds-radio__label" for="ind-field_p_pop">
              <span class="slds-radio_faux"></span>
              <span class="slds-form-element__label">Population</span>
            </label>
          </span>
          <span class="slds-radio">
            <input type="radio" id="ind-field_p_pop0014" value="p_pop0014" name="ind-field-radio" disabled="">
            <label class="slds-radio__label" for="ind-field_p_pop0014">
              <span class="slds-radio_faux"></span>
              <span class="slds-form-element__label">Population de 0 à 14 ans</span>
            </label>
          </span>
          <span class="slds-radio">
            <input type="radio" id="ind-field_p_pop1529" value="p_pop1529" name="ind-field-radio" disabled="">
            <label class="slds-radio__label" for="ind-field_p_pop1529">
              <span class="slds-radio_faux"></span>
              <span class="slds-form-element__label">Population de 15 à 29 ans</span>
            </label>
          </span>
          <span class="slds-radio">
            <input type="radio" id="ind-field_p_pop3044" value="p_pop3044" name="ind-field-radio" disabled="">
            <label class="slds-radio__label" for="ind-field_p_pop3044">
              <span class="slds-radio_faux"></span>
              <span class="slds-form-element__label">Population de 30 à 44 ans</span>
            </label>
          </span>
          <span class="slds-radio">
            <input type="radio" id="ind-field_p_pop4559" value="p_pop4559" name="ind-field-radio" disabled="">
            <label class="slds-radio__label" for="ind-field_p_pop4559">
              <span class="slds-radio_faux"></span>
              <span class="slds-form-element__label">Population de 45 à 59 ans</span>
            </label>
          </span>
          <span class="slds-radio">
            <input type="radio" id="ind-field_p_pop6074" value="p_pop6074" name="ind-field-radio" disabled="">
            <label class="slds-radio__label" for="ind-field_p_pop6074">
              <span class="slds-radio_faux"></span>
              <span class="slds-form-element__label">Population de 60 à 74 ans</span>
            </label>
          </span>
          <span class="slds-radio">
            <input type="radio" id="ind-field_p_pop75p" value="p_pop75p" name="ind-field-radio" disabled="">
            <label class="slds-radio__label" for="ind-field_p_pop75p">
              <span class="slds-radio_faux"></span>
              <span class="slds-form-element__label">Population de 75 ans ou plus</span>
            </label>
          </span>
          <span class="slds-radio">
            <input type="radio" id="ind-field_autres" value="autres" name="ind-field-radio" disabled="">
            <label class="slds-radio__label" for="ind-field_autres">
              <span class="slds-radio_faux"></span>
              <span class="slds-form-element__label">Autres ... </span>
            </label>
          </span>
        </div>
      </fieldset>
    </div>`);
    return $sample;
  }*/
  getSamplePremiumStats() {
    return `
    <div class="slds-col slds-size_1-of-2 slds-p-around_xx-small">
        <article class="slds-card">
          <div class="premium-ribbon"><span>PREMIUM</span></div>
          <div class="slds-card__body slds-card__body_inner slds-m-vertical_xxx-small">
            <div class="slds-align_absolute-center">
              <span class="slds-icon_container" style="display: inline-block;vertical-align: middle;">
                <svg class="slds-icon slds-icon_medium" aria-hidden="true" style="fill:#E287B2;">
                  <use xlink:href="/images/svg/symbols.svg#euro"></use>
                </svg>
              </span>
            </div>
            <div class="slds-align_absolute-center slds-text-heading_medium" style="color:#E287B2"> ${this.numberFormatter0Digits(107026)}</div>
            <div class="slds-border_top hr-small"></div>
            <div class="slds-align_absolute-center slds-text-heading_small slds-p-bottom_x-small">Revenu médian</div>
          </div>
        </article>
      </div>
      <div class="slds-col slds-size_1-of-2 slds-p-around_xx-small">
        <article class="slds-card">
          <div class="premium-ribbon"><span>PREMIUM</span></div>
          <div class="slds-card__body slds-card__body_inner slds-m-vertical_xxx-small">
            <div class="slds-align_absolute-center">
              <span class="slds-icon_container" style="display: inline-block;vertical-align: middle;">
                <svg class="slds-icon slds-icon_medium" aria-hidden="true" style="fill:#54A77B;">
                  <use xlink:href="/images/svg/symbols.svg#people"></use>
                </svg>
              </span>
            </div>
            <div class="slds-align_absolute-center slds-text-heading_medium" style="color:#54A77B">${this.numberFormatter0Digits(20127)}</div>
            <div class="slds-border_top hr-small"></div>
            <div class="slds-align_absolute-center slds-text-heading_small slds-p-bottom_x-small">Autres</div>
          </div>
        </article>
      </div>`;
  }
}
