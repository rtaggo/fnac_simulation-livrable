import EventBus from '../helpers/eventbus.mjs';
import { MAPISLOADED } from '../constants/events.mjs';

import MapManager from '../managers/map_manager.mjs';
import SimulationManager from '../managers/simulation_manager.mjs';
import ZonesManager from '../managers/zones_manager.mjs';
import StatisticManager from '../managers/statistic_manager.mjs';
import CompetitorsManager from '../managers/competitors_manager.mjs';
import ReportManager from '../managers/report_manager.mjs';
import { get_app_configuration } from '../services/configuration.mjs';

let app_configuration = null;
let simulation_locked = false;
let managers = {};
let current_user;

const get_manager = (what) => {
  return managers[what];
};

const get_map_manager = () => {
  return get_manager('mapMgr');
};

const init_configuration = async () => {
  const app_conf = await get_app_configuration();
  if (!app_conf.error) {
    app_configuration = app_conf;
    return true;
  }
  return false;
};

const init_managers = async () => {
  // TODO implement get current user
  const current_user = null;

  managers.mapMgr = MapManager.getInstance({ mapboxAccessToken: app_configuration.mapbox_api_key });
  managers.simulationMgr = SimulationManager.getInstance({ mapManager: managers.mapMgr });
  managers.zonesMgr = ZonesManager.getInstance();
  managers.statMgr = StatisticManager.getInstance({ container: 'statistics-container', current_user });
  managers.competitorsMgr = CompetitorsManager.getInstance();
  managers.reportMgr = ReportManager.getInstance();
};

const render_managers = () => {
  //managers.parameterMgr.render();

  managers.simulationMgr.loadSimulation();
  managers.simulationMgr.render();
  managers.zonesMgr.render();
  managers.statMgr.render();
  managers.competitorsMgr.render();
  managers.reportMgr.render();

  //managers.locationMgr.render();
  //managers.statsMgr.render();
};

const init_listeners = () => {
  EventBus.addEventListener(MAPISLOADED, () => {
    render_managers();
  });
};

const run = async () => {
  const config_ok = await init_configuration();
  if (!config_ok) {
    // to do: use nice alert
    alert('Error de configuration');
    return;
  }
  init_managers();
  init_listeners();
};

window.addEventListener('load', async () => {
  run();
});
