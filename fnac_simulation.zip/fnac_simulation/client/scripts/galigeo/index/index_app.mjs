import EventBus from '../helpers/eventbus.mjs';
import { MAPISLOADED, MAPISMOVEND } from '../constants/events.mjs';

import MapManager from '../managers/map_manager.mjs';
import { modal_confirm } from '../helpers/modal.mjs';
import { toast } from '../helpers/messages.mjs';

import { get_user_simulations, delete_simulation } from '../services/simulations.mjs';
import { get_app_configuration } from '../services/configuration.mjs';

console.log('>> Starting Index app');

let app_configuration = null;
let user_simulations = [];
let filtred_simulations = [];
let managers = {};

const render_simulations_data_table = (simulations) => {
  let $ctnr = $('#simulation-container').empty();
  let $tbl = $(`
  <table class="slds-table slds-table_cell-buffer slds-table_bordered" aria-labelledby="element-with-table-label other-element-with-table-label">
    <thead>
      <tr class="slds-line-height_reset">
        <th class="" scope="col">
          <div class="slds-truncate">Nom</div>
        </th>
        <th class="" scope="col" style="width: 10rem;">
          <div class="slds-truncate">Créée par</div>
        </th>
        <th class="" scope="col" style="width: 10rem;">
          <div class="slds-truncate" >Créée le</div>
        </th>
        <th class="" scope="col" style="width: 10rem;">
        <div class="slds-truncate">Modifiée par</div>
      </th>
      <th class="" scope="col" style="width: 10rem;">
        <div class="slds-truncate" >Modifiée le</div>
      </th>
      <th class="" scope="col" style="width: 5rem;">
      </th>
      </tr>
    </thead>
    <tbody id="simulations-table-body">    
    </tbody>
  </table>`);
  $ctnr.append($tbl);
  filterSimulation();
};

const render_simulations_data_table_body = (simulations, container_id = 'simulations-table-body') => {
  let $ctnr = $(`#${container_id}`).empty();
  let $content = $(`
  ${simulations
    .map((s) => {
      const createdDate = new Date(s.created_date);
      const lastModifiedDate = new Date(s.last_modified_date);
      return `
    <tr class="slds-hint-parent" data-simulationid="${s.id}">
      <th data-label="Nom" scope="row"><a href="/simulation?id=${s.id}" >${s.name}</a>
      </th>
      <td data-label="Créée par">
        <div class="slds-truncate">${s.created_by}</div>
      </td>
      <td data-label="Créée le">
        <div class="slds-truncate" style="text-align: right;">${createdDate.toLocaleDateString()} ${createdDate.toLocaleTimeString()}</div>
      </td>
      <td data-label="Modifiée par">
        <div class="slds-truncate">${s.last_modified_by}</div>
      </td>
      <td data-label="Modifiée le">
        <div class="slds-truncate"  style="text-align: right;">${lastModifiedDate.toLocaleDateString()} ${lastModifiedDate.toLocaleTimeString()}</div>
      </td>
      <td data-label="Vérouille">
        <span class="slds-icon_container slds-icon-utility-announcement ${s.locked?'':'slds-hide'}" title="Cette simulation a été vérouillée">
          <svg class="slds-icon slds-icon-text-default slds-icon_xx-small" aria-hidden="true">
            <use xlink:href="/styles/slds/assets/icons/utility-sprite/svg/symbols.svg#lock"></use>
          </svg>
          <span class="slds-assistive-text">Vérouillé</span>
        </span>
      </td>
      <td>
        <div>
          <button  id="${s.id}" class="btn-zoom-simulation slds-button slds-button_icon slds-button_icon_outline-brand" title="Zoom">
            <svg class="slds-button__icon" aria-hidden="true">
              <use xlink:href="/styles/slds/assets/icons/utility-sprite/svg/symbols.svg#zoomin"></use>
            </svg>
            <span class="slds-assistive-text">Zoom</span>
          </button>
          <button id="${s.id}" class="btn-delete-simulation slds-button slds-button_icon slds-button_icon_destructive" title="Supprimer">
            <svg class="slds-button__icon" aria-hidden="true">
              <use xlink:href="/styles/slds/assets/icons/utility-sprite/svg/symbols.svg#delete"></use>
            </svg>
            <span class="slds-assistive-text">Supprimer</span>
          </button>        
        </div>
      </td>
    </tr>
    `;
    })
    .join('')}`);
  $ctnr.append($content);
};

const refresh_simulations_layer = (simulations) => {
  let geojson = {
    type: 'FeatureCollection',
    features: simulations.map((s) => {
      return {
        type: 'Feature',
        properties: { ...{ _label: s.name }, ...s },
        geometry: {
          type: 'Point',
          coordinates: [s.location.coordinates.longitude, s.location.coordinates.latitude],
        },
      };
    }),
  };

  managers.mapMgr.addPointLayer(geojson, 'simulations', 'logo', '/images/fnac_icon.png', { addTooltip: true, tooltipFields: 'name,description' });
};

const fetch_user_simulations = async (callback) => {
  try {
    user_simulations = await get_user_simulations();
    render_simulations_data_table(user_simulations);
    if (callback) {
      callback();
    }
  } catch (err) {
    console.error(err);
  }
};

const setup_listeners = () => {
  EventBus.addEventListener(MAPISLOADED, () => {
    fetch_user_simulations();
  });
  EventBus.addEventListener(MAPISMOVEND, () => {
    filterSimulation();
  });

  $(document).on('click', '.btn-zoom-simulation', (e) => {
    const ele = $(e.target);
    const s = getSimulationById(ele.attr('id'));
    if (s) {
      managers.mapMgr.flyTo(s.location.coordinates);
    }
  });
  $(document).on('click', '.btn-delete-simulation', (e) => {
    const ele = $(e.target);
    const s = getSimulationById(ele.attr('id'));
    if (s) {
      modal_confirm(
        'Voulez vous supprimer la simulation ' + s.name,
        () => {
          console.log('delete simulation ' + s.name);
          deleteSimulation(s);
        },
        true
      );
    }
  });
  $('#simulation-search-input').on('keyup', () => {
    filterSimulation();
  });
};
const deleteSimulation = (simulation) => {
  delete_simulation(simulation).then((result) => {
    console.log('Simulation deleted', result);
    toast('La simulation "' + simulation.name + '" est supprimer avec succée', 'success', 4000);
    fetch_user_simulations(() => {
      filterSimulation();
    });
  });
};
const filterSimulation = () => {
  filtred_simulations = user_simulations.filter((simulation) => simulation.location && managers.mapMgr.isInExtend(simulation.location.coordinates));
  if ($('#simulation-search-input').val().length >= 3) {
    setTimeout(() => {
      const val = $('#simulation-search-input').val();
      filtred_simulations = filtred_simulations.filter(
        (simulation) => simulation.name.toLowerCase().indexOf(val.toLowerCase()) !== -1 || simulation.created_by.toLowerCase().indexOf(val.toLowerCase()) > -1
      );
      render_simulations_data_table_body(filtred_simulations);
      refresh_simulations_layer(filtred_simulations);
    }, 300);
  } else {
    render_simulations_data_table_body(filtred_simulations);
    refresh_simulations_layer(filtred_simulations);
  }
};
const getSimulationById = (id) => {
  return user_simulations.find((s) => s.id === id);
};

const init_configuration = async () => {
  const app_conf = await get_app_configuration();
  if (!app_conf.error) {
    app_configuration = app_conf;
    return true;
  }
  return false;
};

const run = async () => {
  const config_ok = await init_configuration();
  if (!config_ok) {
    // to do: use nice alert
    alert('Error de configuration');
    return;
  }
  setup_listeners();
  managers.mapMgr = MapManager.getInstance({ mapboxAccessToken: app_configuration.mapbox_api_key });
};

run();
