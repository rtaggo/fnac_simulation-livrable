export const get_app_configuration = async () => {
  try {
    const res_config = await fetch(`/rest/config`, {
      method: 'GET',
      credentials: 'include',
    });

    const res_config_json = await res_config.json();
    return res_config_json;
  } catch (err_config) {
    console.error('Failed to fetch app configuration', err_config);
    return { error: true, message: err_config };
  }
};
