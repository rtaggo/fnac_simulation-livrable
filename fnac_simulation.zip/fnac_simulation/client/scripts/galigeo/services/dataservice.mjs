export const get_demography = async (zones) => {
    try {
      const res = await fetch('/rest/data/demography', {
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(zones),
        method: 'POST',
        mode: 'cors',
        credentials: 'include',
      });
  
      const res_json = await res.json();
      return res_json;
    } catch (err) {
      console.error('Failed to save competitor', err);
      return { error: true, message: err };
    }
  };


  export const get_competitors = async (zones) => {
    try {
      const res = await fetch('/rest/concurrence', {
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(zones),
        method: 'POST',
        mode: 'cors',
        credentials: 'include',
      });
  
      const res_json = await res.json();
      return res_json;
    } catch (err) {
      console.error('Failed to get competitor', err);
      return { error: true, message: err };
    }
  };

  export const get_type_mag = async () => {
    try {
      const res = await fetch('/rest/data/type_mag', {
        headers: {
          'Content-Type': 'application/json',
        },
        method: 'GET',
        mode: 'cors',
        credentials: 'include',
      });
  
      const res_json = await res.json();
      return res_json;
    } catch (err) {
      console.error('Failed to get type mags', err);
      return { error: true, message: err };
    }
  };