const geocode_successFunc = (position) => {
    const latitude = position.coords.latitude;
    const longitude = position.coords.longitude;
    console.log(`Located at : ${latitude}, ${longitude}`);
  };
  const geocode_errorFunc = (err) => {
    console.error('Failed to get location', err);
  };
  
  const geoservice_successFunc = (response) => {
    console.log('Default geoservice success func', response);
  };
  const geoservice_errorFunc = (err) => {
    console.error('Default geoservice error func', err);
  };
  
  export const is_geolocation_api_available = () => {
    if (!navigator.geolocation) {
      return false;
    }
    return true;
  };
  
  export const locate_user = (success = geocode_successFunc, error = geocode_errorFunc) => {
    navigator.geolocation.getCurrentPosition((position) => {
      success({ latitude: position.coords.latitude, longitude: position.coords.longitude });
    }, error);
  };
  
  export const do_search_address = async (searchText) => {
    const search_geocode_url = `/rest/geoservice/geocode/search?q=${searchText}`;
    const resp = await fetch(search_geocode_url);
    const resp_json = await resp.json();
    return {
      ok: resp.ok,
      data: resp_json,
    };
  };
  
  export const do_reverse_geocode = async (lat, lng, successCB, errorCB) => {
    const search_geocode_url = `/rest/geoservice/geocode/reverse?lat=${lat}&lng=${lng}`;
    const resp = await fetch(search_geocode_url);
    const resp_json = await resp.json();
    if (resp.ok) {
      if (successCB) {
        successCB(resp_json);
        return;
      }
      return resp_json;
    } else {
      console.warn('Fetch response is not ok', resp_json);
      if (errorCB) {
        errorCB(resp_json);
        return;
      }
      return resp_json;
    }
  };
  
  export const compute_isochrone = async ({ latitude, longitude }, limits, profile, success = geoservice_successFunc, error = geoservice_errorFunc) => {
    const iso_url = `/rest/geoservice/direction/isochrone?lat=${latitude}&lng=${longitude}&time_limits=${limits.join(',')}&profile=${profile}`;
    const resp = await fetch(iso_url);
    const resp_json = await resp.json();
    if (resp.ok) {
      const biggest_iso_url = `/rest/geoservice/direction/isochrone?lat=${latitude}&lng=${longitude}&time_limits=${limits[2]}&profile=${profile}`;
      const biggest_resp = await fetch(biggest_iso_url);
      const biggest_resp_json = await biggest_resp.json();
      resp_json.features.push(biggest_resp_json.features[0]);
      success(resp_json);
      return;
    } else {
      console.warn('Fetch response is not ok', resp_json);
      error(resp_json);
    }
  };
  
  export const get_formatted_adress = (props) => {
    let street_fields = [];
    if (props.housenumber) {
      street_fields.push(props.housenumber);
    }
    street_fields.push(props.street);
    let addr_fields = [];
    addr_fields.push(street_fields.join(' '));
    if (props.postalcode) {
      addr_fields.push(props.postalcode);
    }
    if (props.locality) {
      addr_fields.push(props.locality);
    }
    if (props.country) {
      addr_fields.push(props.country);
    }
    return addr_fields.join(', ');
  };
  