import Simulation from '../model/simulation.mjs';

export const get_user_simulations = async () => {
  try {
    const res_simulations = await fetch('/rest/simulation', {
      method: 'GET',
      credentials: 'include',
    });

    const res_simulations_json = await res_simulations.json();
    return res_simulations_json;
  } catch (err_simulation) {
    console.error('Failed to fetch user simulations', err_simulation);
    return { error: true, message: err_simulation };
  }
};

export const get_simulation = async (id) => {
  try {
    const res_simulations = await fetch(`/rest/simulation/${id}`, {
      method: 'GET',
      credentials: 'include',
    });

    const res_simulations_json = await res_simulations.json();
    return new Simulation(res_simulations_json);
  } catch (err_simulation) {
    console.error('Failed to fetch user simulations', err_simulation);
    return { error: true, message: err_simulation };
  }
};

export const save_simulation = async (simulation) => {
  try {
    const save_url = `/rest/simulation${simulation.id ? `/${simulation.id}` : ''}`;
    const res = await fetch(save_url, {
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(simulation),
      method: simulation.id ? 'PATCH' : 'POST',
      mode: 'cors',
      credentials: 'include',
    });

    const res_json = await res.json();
    return res_json;
  } catch (err) {
    console.error('Failed to save competitor', err);
    return { error: true, message: err };
  }
};
export const delete_simulation = async (simulation) => {
  try {
    const res = await fetch('/rest/simulation/' + simulation.id, {
      headers: {
        'Content-Type': 'application/json',
      },
      method: 'DELETE',
      mode: 'cors',
      credentials: 'include',
    });

    const res_json = await res.json();
    return res_json;
  } catch (err) {
    console.error('Failed to delete competitor', err);
    return { error: true, message: err };
  }
};

export const lock_simulation = async (simulationId) => {
  try {
    const res = await fetch('/rest/simulation/lock/' + simulationId, {
      headers: {
        'Content-Type': 'application/json',
      },
      method: 'GET',
      mode: 'cors',
      credentials: 'include',
    });

    const res_json = await res.json();
    return res_json;
  } catch (err) {
    console.error('Failed to lock simulation', err);
    return { error: true, message: err };
  }
};

export const export_simulation = async (simulationId) => {
  window.open('/rest/simulation/export/' + simulationId, '_blank');
  /*try {
    const res = await fetch('/rest/simulation/export/' + simulationId, {
      headers: {
        'Content-Type': 'application/text',
      },
      method: 'GET',
      mode: 'cors',
      credentials: 'include',
    });

    const res_json = await res.json();
    return res_json;
  } catch (err) {
    console.error('Failed to lock simulation', err);
    return { error: true, message: err };
  }*/
};

export const run_simulation = async (simulation, callback, errorCallback) => {
  try {
    const res = await fetch('/rest/job/submit?simulation=' + simulation.id, {
      headers: {
        'Content-Type': 'application/json',
      },
      method: 'GET',
      mode: 'cors',
      credentials: 'include',
    });

    const res_json = await res.json();
    console.log('JOB ID = ', res_json);
    const jobId = res_json.job_id;

    let intervalId = -1;

    const checkInterval = async () => {
      const status = await _get_job(jobId);
      if (status && (status.status === 'done')) {
        clearInterval(intervalId);
        callback();
      }
      if (status && (status.status === 'error')) {
        clearInterval(intervalId);
        if(errorCallback) errorCallback(status);
        else throw new Error('Erreur de simulation');
      }
    };

    intervalId = setInterval(checkInterval, 1000);

    return jobId;
  } catch (err) {
    console.error('Failed to delete competitor', err);
    return { error: true, message: err };
  }
};

export const _get_job = async (jobId) => {
  try {
    const res = await fetch('/rest/job/' + jobId, {
      headers: {
        'Content-Type': 'application/json',
      },
      method: 'GET',
      mode: 'cors',
      credentials: 'include',
    });

    const res_json = await res.json();
    return res_json;
  } catch (err) {
    console.error('Failed to delete competitor', err);
    return { error: true, message: err };
  }
};
