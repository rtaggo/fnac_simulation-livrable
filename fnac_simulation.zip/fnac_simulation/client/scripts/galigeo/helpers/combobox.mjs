/**
 * Boiler plate for combo box
 *
 * Usage :
 * <div id="my-combobox" class="slds-form-element__control"></div>
 *
 * combo_box('my-combobox', ['v1', 'v2', 'v3'], 'v2', callback);
 *
 * @param element
 * @param elementsArray
 * @param defaultValue
 * @param callback
 */
export const combo_box = (element, elementsArray, defaultValue, callback) => {
  const optionsHtml = elementsArray
    .map((value) => {
      let opt_icon = '';
      let selected_class = '';
      if (value === defaultValue) {
        opt_icon = `
        <span class="slds-icon_container slds-icon-utility-check slds-current-color">
          <svg class="slds-icon slds-icon_x-small" aria-hidden="true">
            <use xlink:href="/styles/slds/assets/icons/utility-sprite/svg/symbols.svg#check"></use>
          </svg>
        </span>`;
        selected_class = 'slds-is-selected';
      }
      return `<li role="presentation" class="slds-listbox__item">
        <div class="slds-media slds-listbox__option slds-listbox__option_plain slds-media_small ${selected_class}" role="option" data-value="${value}">
          <span class="slds-media__figure slds-listbox__option-icon">
          ${opt_icon}
          </span>
          <span class="slds-media__body">
            <span class="slds-truncate" title="${value}">${value}</span>
          </span>
        </div>
      </li>`;
    })
    .join('');

  $('#' + element).empty().append(`    
    <div class="slds-combobox_container">
      <div id='${element}-main' class="slds-combobox slds-dropdown-trigger slds-dropdown-trigger_click" aria-expanded="false" aria-haspopup="listbox" role="combobox">
        <div class="slds-combobox__form-element slds-input-has-icon slds-input-has-icon_right" role="none">
          <input type="text" class="slds-input slds-combobox__input slds-combobox__input-value" id="${element}-value" aria-controls="${element}-listbox" autocomplete="off" role="textbox" placeholder="Select an Option…" readonly="" value="${defaultValue}">
          <span class="slds-icon_container slds-icon-utility-down slds-input__icon slds-input__icon_right">
            <svg class="slds-icon slds-icon slds-icon_x-small slds-icon-text-default" aria-hidden="true">
              <use xlink:href="/styles/slds/assets/icons/utility-sprite/svg/symbols.svg#down"></use>
            </svg>
          </span>
        </div>        
        <div id="${element}-listbox" class="slds-dropdown slds-dropdown_length-5 slds-dropdown_fluid" role="listbox">
          <ul class="slds-listbox slds-listbox_vertical" role="presentation">
            ${optionsHtml}
          </ul>
        </div>
      </div>
    </div>`);

  $('#' + element + '-main').on('click', (e) => {
    $(e.currentTarget).toggleClass('slds-is-open');
    /* replace by toggle class slds-is-open
    let $elt = $(e.currentTarget);
    if ($elt.hasClass('slds-is-open')) {
      $elt.removeClass('slds-is-open');
    } else {
      $elt.addClass('slds-is-open');
    }
    */
  });

  $('#' + element + '-main .slds-listbox__option').on('click', (e) => {
    let $tgt = $(e.currentTarget);
    $tgt.parent().siblings().find('.slds-listbox__option').removeClass('slds-is-selected');
    $tgt.parent().siblings().find('.slds-listbox__option-icon').empty();
    $tgt.find('.slds-listbox__option-icon').append(
      $(`
    <span class="slds-icon_container slds-icon-utility-check slds-current-color">
      <svg class="slds-icon slds-icon_x-small" aria-hidden="true">
        <use xlink:href="/styles/slds/assets/icons/utility-sprite/svg/symbols.svg#check"></use>
      </svg>
    </span>`)
    );
    $tgt.addClass('slds-is-selected');
    const selectedValue = $tgt.data('value');
    $('#' + element + '-value').val(selectedValue);
    if (callback) {
      callback(selectedValue);
    }
  });
};
