import EventBus from './eventbus.mjs';
import { STATSDETAILSVISIBILITY } from '../constants/events.mjs';
import { color_buckets } from '../constants/colors.mjs';

export const display_stats_details = (field, stats, options) => {
  const container_id = 'main-container';

  let $panel = $(`
  <div id="stats-details-panel" class="slds-panel slds-size_medium slds-is-open" aria-hidden="false">
    <div class="slds-panel__header">
      <button class="slds-button slds-button_icon slds-button_icon-small slds-panel__back" title="Retour">
        <svg class="slds-button__icon" aria-hidden="true">
          <use xlink:href="/styles/slds/assets/icons/utility-sprite/svg/symbols.svg#chevronleft"></use>
        </svg>
        <span class="slds-assistive-text">Retour</span>
      </button>
      <h2 class="slds-panel__header-title slds-text-heading_small slds-truncate" title="${field.label}">${field.label}</h2>
      <div class="slds-panel__header-actions slds-hide">
        <button class="slds-button slds-button_icon slds-button_icon-small slds-panel__close" title="Fermer">
          <svg class="slds-button__icon" aria-hidden="true">
            <use xlink:href="/styles/slds/assets/icons/utility-sprite/svg/symbols.svg#close"></use>
          </svg>
          <span class="slds-assistive-text">Fermer</span>
        </button>
      </div>
    </div>
    <div id="stats-field-content" class="slds-panel__body slds-p-around_small slds-scrollable_y"></div>
  </div>`);
  $panel.find('button.slds-panel__back').on('click', () => {
    $('#stats-details-panel').remove();
    EventBus.dispatch(STATSDETAILSVISIBILITY, { is_visible: false });
  });
  $(`#${container_id}`).append($panel);
  get_stats_content(field, stats, $('#stats-field-content'), options);
};

const get_stats_content = (field, stats, container, options) => {
  if (field.id === 'population') {
    build_population_stats_content(field, stats, container, options);
    return;
  }
  if (field.id === 'logement') {
    build_logement_stats_content(field, stats, container, options);
  }
  if (field.id === 'menage') {
    build_menage_stats_content(field, stats, container, options);
  }
  if (field.id === 'potentiel') {
    build_potentiel_stats_content(field, stats, container, options);
  }
};

const intlNumberFormat2Digits = new Intl.NumberFormat('fr', { minimumFractionDigits: 0, maximumFractionDigits: 0 });
const numberFormatter0Digits = (num) => {
  return intlNumberFormat2Digits.format(num);
};

const build_population_stats_content = (field, stats, container, options) => {
  const male_color = '#0000FF';
  const female_color = '#FF00FF';
  const pophf_fields = [
    {
      id: 'p_poph',
      label: 'Homme',
      color: male_color,
    },
    {
      id: 'p_popf',
      label: 'Femme',
      color: female_color,
    },
  ];
  container.append(
    $(`
  <div>
    <div class="slds-text-title_caps">Répartition Homme/Femme</div>
    <div id="chart_pop_repartition_hf" style="position: relative; height:200px; width:100%;"></div>
  </div>`)
  );
  render_doughnutchart(pophf_fields, stats, 'chart_pop_repartition_hf', {
    title: 'Répartition Homme/Femme',
    datalabels: {
      plugins: {
        formatter: (value) => {
          return numberFormatter0Digits((value / (stats.p_popf + stats.p_poph)) * 100) + '%';
        },
        font: {
          weight: 'bold',
        },
      },
    },
  });

  container.append(
    $(`
  <div class="slds-m-top_small" style="position:relative;">
    <div class="slds-text-title_caps">Proportion par classes d'âges</div>
    <div id="chart_pop_classes_ages_hf" style="position: relative; height:200px; width:100%;"></div>
  </div>`)
  );
  const poph_fields = [
    {
      id: 'p_h0014',
      label: 'H < 14 ans',
      color: male_color,
    },
    {
      id: 'p_h1529',
      label: 'H 15-29',
      color: male_color,
    },
    {
      id: 'p_h3044',
      label: 'H 30-44',
      color: male_color,
    },
    {
      id: 'p_h4559',
      label: 'H 45-59',
      color: male_color,
    },
    {
      id: 'p_h6074',
      label: 'H 60-74',
      color: male_color,
    },
    {
      id: 'p_h75p',
      label: 'H > 75 ans',
      color: male_color,
    },
  ];
  const popf_fields = [
    {
      id: 'p_f0014',
      label: 'F < 14 ans',
      color: female_color,
    },
    {
      id: 'p_f1529',
      label: 'F 15-29',
      color: female_color,
    },
    {
      id: 'p_f3044',
      label: 'F 30-44',
      color: female_color,
    },
    {
      id: 'p_f4559',
      label: 'F 45-59',
      color: female_color,
    },
    {
      id: 'p_f6074',
      label: 'F 60-74',
      color: female_color,
    },
    {
      id: 'p_f75p',
      label: 'F > 75 ans',
      color: female_color,
    },
  ];
  let labels = ['< 14 ans', '14 - 29 ans', '30 - 44 ans', '45 - 59 ans', '60 - 74 ans', '75 ans et + '].reverse();
  let data = {
    labels,
    datasets: [
      {
        label: 'Homme',
        stack: 'Stack 0',
        data: poph_fields.reverse().map((f) => stats[f.id] / stats.population),
        borderColor: male_color,
        backgroundColor: male_color,
      },
      {
        label: 'Femme',
        stack: 'Stack 0',
        data: popf_fields.reverse().map((f) => -stats[f.id] / stats.population),
        borderColor: female_color,
        backgroundColor: female_color,
      },
    ],
  };
  const config = {
    type: 'bar',
    data: data,
    options: {
      indexAxis: 'y',
      // Elements options apply to all of the options unless overridden in a dataset
      // In this case, we are setting the border of each horizontal bar to be 2px wide
      elements: {
        bar: {
          borderWidth: 2,
        },
      },
      responsive: true,
      plugins: {
        legend: {
          display: false,
        },
        title: {
          display: false,
        },
        tooltip: {
          callbacks: {
            label: (context) => {
              let label = context.dataset.label || '';
              if (label) {
                label += ': ';
              }

              if (context.parsed.x !== null) {
                label += Math.abs(context.parsed.x).toLocaleString('fr-FR', { style: 'percent' });
              }

              return label;
            },
          },
        },
      },
      scales: {
        x: {
          ticks: {
            beginAtZero: true,
            callback: (v) => {
              return Math.abs(v).toLocaleString('fr-FR', { style: 'percent' });
            },
          },
          color: 'red',
        },
        /*
          yAxes: [
            {
              stacked: true,
              position: 'left',
              ticks: {
                min: 0,
                maxTicksLimit: 10,
                callback: function (label, index, labels) {
                  return label.toLocaleString('fr-FR', { style: 'percent' }); // numberFormatter.compact.format(label);
                },
              },
              gridLines: {
                display: false,
              },
            },
          ],
          */
      },
    },
  };
  let $pop_chart = $(`#chart_pop_classes_ages_hf`);
  const c_width = parseInt($pop_chart.width());
  const c_height = parseInt($pop_chart.height());
  let $chart_canvas = $(`<canvas id="chart_pop_classes_ages_hf_canvas" width="${c_width}" height="${c_height}"></canvas>`);
  $pop_chart.append($chart_canvas);
  new Chart($chart_canvas, config);
};

const build_logement_stats_content = (field, stats, container, options) => {
  const principales_color = 'rgba(255, 99, 132, 0.9)';
  const secondaires_color = 'rgba(255, 159, 64, 0.9)';
  const vacants_color = 'rgba(75, 192, 192, 0.9)';

  const log_type_res_fields = [
    {
      id: 'p_rp',
      label: 'Rés. Principales',
      color: principales_color,
    },
    {
      id: 'p_rsecocc',
      label: 'Rés. Secondaires',
      color: secondaires_color,
    },
    {
      id: 'p_logvac',
      label: 'Log. Vacants',
      color: vacants_color,
    },
  ];
  let chart_data = {
    p_rp: (stats.p_rp / stats.logement) * 100,
    p_rsecocc: (stats.p_rsecocc / stats.logement) * 100,
    p_logvac: (stats.p_logvac / stats.logement) * 100,
  };
  container.append(
    $(`
    <div style="position: relative;">
      <div class="slds-text-title_caps">Répartition de logements par type d'occupation (en %)</div>
      <div id="chart_log_repartition_type_res" class="slds-p-around_small" style="position: relative; height:200px; width:100%;"></div>
    </div>`)
  );
  render_barchart(log_type_res_fields, chart_data, 'chart_log_repartition_type_res', {
    legend: { display: false },
    title: { text: 'Type de logement' },
    is_percent: true,
  });

  const log_type = [
    {
      id: 'p_maison',
      label: 'Maison',
      color: principales_color,
    },
    {
      id: 'p_appart',
      label: 'Appartements',
      color: secondaires_color,
    },
  ];
  let chart_type_data = {
    p_maison: (stats.p_maison / stats.logement) * 100,
    p_appart: (stats.p_appart / stats.logement) * 100,
  };
  container.append(
    $(`
    <div style="position:relative;">
      <div class="slds-text-title_caps">Répartition Maisons et Appartements (en %)</div>
      <div id="chart_log_type" class="slds-p-around_small" style="position: relative; height:200px; width:100%;"></div>
    </div>`)
  );
  render_doughnutchart(log_type, chart_type_data, 'chart_log_type', {
    legend: { display: false },
    title: { text: 'Type de logement' },
    is_percent: true,
    datalabels: {
      plugins: {
        display: function (context) {
          const dataset = context.dataset;
          const value = dataset.data[context.dataIndex];
          return value > 10;
        },
        formatter: (value) => {
          return numberFormatter0Digits(value) + '%';
        },
        font: {
          weight: 'bold',
        },
      },
    },
  });

  const log_type_rp = [
    {
      id: 'p_rp_prop',
      label: 'Propriétaires',
      color: principales_color,
    },
    {
      id: 'p_rp_loc',
      label: 'Locataires',
      color: secondaires_color,
    },
    {
      id: 'p_rp_grat',
      label: 'Gratuits',
      color: vacants_color,
    },
  ];
  let chart_rp_data = {
    p_rp_prop: (stats.p_rp_prop / stats.menage) * 100,
    p_rp_loc: (stats.p_rp_loc / stats.menage) * 100,
    p_rp_grat: (stats.p_rp_grat / stats.menage) * 100,
  };
  container.append(
    $(`
    <div style="position:relative;">
      <div class="slds-text-title_caps">Répartition Propriétaires, Locataires et Gratuits (en %)</div>
      <div id="chart_log_type_rp" class="slds-p-around_small" style="position: relative; height:200px; width:100%;"></div>
    </div>`)
  );
  render_doughnutchart(log_type_rp, chart_rp_data, 'chart_log_type_rp', {
    legend: { display: false },
    title: { text: 'Type de logement' },
    is_percent: true,
    datalabels: {
      plugins: {
        display: function (context) {
          const dataset = context.dataset;
          const value = dataset.data[context.dataIndex];
          return value > 10;
        },
        formatter: (value) => {
          return numberFormatter0Digits(value) + '%';
        },
        font: {
          weight: 'bold',
        },
      },
    },
  });
};
const build_menage_stats_content = (field, stats, container, options) => {
  const fields = [
    {
      id: 'men_cs1',
      label: 'Agriculteurs exploitants',
    },
    {
      id: 'men_cs2',
      label: 'Artisants, commerçants et chefs entreprises',
    },
    {
      id: 'men_cs3',
      label: 'Cadres et professions intellectuelles supérieures',
    },
    {
      id: 'men_cs4',
      label: 'Professions intermédiaires',
    },
    {
      id: 'men_cs5',
      label: 'Employés',
    },
    {
      id: 'men_cs6',
      label: 'Ouvriers',
    },
    {
      id: 'men_cs7',
      label: 'Retraités',
    },
    {
      id: 'men_cs8',
      label: 'Autres personnes sans activité professionnelle',
    },
  ];

  container.append(
    $(`
    <div class="slds-p-around_xx-small">
      <div class="slds-text-title_caps">Ménages selon la catégorie socioprofessionnelle</div>
      <div class="slds-p-around_x-small">
        <table class="slds-table stats-table slds-table_cell-buffer slds-no-row-hover slds-table_bordered slds-table_fixed-layout slds-table_striped" aria-labelledby="element-with-table-label other-element-with-table-label">
          <thead>
            <tr class="slds-line-height_reset">
              <th class="" scope="col" style="padding-left: 0.25rem;">
                <div class="slds-truncate slds-text-align_left" title="Catégories">Catégories</div>
              </th>
              <th class="" scope="col" style="width:80px;">
                <div class="slds-truncate slds-text-align_right" title="En Nb">En Nb</div>
              </th>
              <th class="" scope="col" style="width:50px;padding-right: 0.25rem;">
                <div class="slds-truncate slds-text-align_right" title="En %">En %</div>
              </th>
            </tr>
          </thead>
          <tbody>
          ${fields
            .map((f) => {
              return `
            <tr class="slds-hint-parent">
              <td data-label="Catégories" style="padding-left: 0.25rem;">
                <div class="slds-truncate slds-text-align_left">${f.label}</div>
              </td>
              <td data-label="En Nb">
                <div class="slds-truncate slds-text-align_right" >${numberFormatter0Digits(stats[f.id])}</div>
              </td>
              <td data-label="En %" style="padding-right: 0.25rem;">
                <div class="slds-truncate slds-text-align_right" >${numberFormatter0Digits((stats[f.id] / stats.menage) * 100)} %</div>
              </td>
            </tr>`;
            })
            .join('')}
            <tr class="slds-hint-parent" style="font-weight:bold;">
              <td data-label="Catégories" style="padding-left: 0px;">
                <div class="slds-truncate slds-text-align_right">TOTAL</div>
              </td>
              <td data-label="En Nb">
                <div class="slds-truncate slds-text-align_right">${numberFormatter0Digits(stats.menage)}</div>
              </td>
              <td data-label="En %" style="padding-right: 0.25rem;">
                <div class="slds-truncate slds-text-align_right">100 %</div>
              </td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
  `)
  );
};

const build_potentiel_stats_content = (field, stats, container, options) => {
  const pot_fields = [
    {
      id: 'zone1',
      label: 'Zone Primaire',
      color: color_buckets[0],
    },
    {
      id: 'zone2',
      label: 'Zone Secondaire',
      color: color_buckets[1],
    },
    {
      id: 'zone3',
      label: 'Zone Tertiaire',
      color: color_buckets[2],
    },
  ];
  container.append(
    $(`
  <div>
    <div class="slds-text-title_caps">Répartition par zone</div>
    <div id="chart_repartition_potentiel" style="position: relative; height:200px; width:100%;"></div>
  </div>`)
  );

  const data_pot_zone = {
    zone1: stats.potentiels.zones[0].potentiel,
    zone2: stats.potentiels.zones[1].potentiel,
    zone3: stats.potentiels.zones[2].potentiel
  }

  render_doughnutchart(pot_fields, data_pot_zone, 'chart_repartition_potentiel', {
    title: 'Répartition par zone',
    datalabels: {
      plugins: {
        formatter: (value) => {
          const sum = data_pot_zone.zone1 + data_pot_zone.zone2 + data_pot_zone.zone3;
          return numberFormatter0Digits((value / sum) * 100) + '%';
        },
        font: {
          weight: 'bold',
        },
      },
    },
  });

  const data_nb_zone = {
    zone1: stats.potentiels.zones[0].nb,
    zone2: stats.potentiels.zones[1].nb,
    zone3: stats.potentiels.zones[2].nb
  }
  
  container.append(
    $(`
    <div style="position: relative;">
      <div class="slds-text-title_caps">Nombre d'iris par zone</div>
      <div id="chart_potentiel_nb_iris" class="slds-p-around_small" style="position: relative; height:200px; width:100%;"></div>
    </div>`)
  );
  render_barchart(pot_fields, data_nb_zone, 'chart_potentiel_nb_iris', {
    legend: { display: false },
    title: { text: 'Nombre d\'iris' },
    is_percent: false,
  });

}

const render_barchart = (fields, data, containerId, options) => {
  const labels = fields.map((f) => f.label);
  const datasets = [
    {
      /*label: options?.title?.text ?? 'A data set',*/
      data: fields.map((f) => data[f.id]),
      backgroundColor: fields.map((f) => f.color),
    },
  ];
  const chart_data = {
    labels,
    datasets,
  };
  const is_percent_val = options?.is_percent ?? false;
  let post_fixe_label = is_percent_val ? ' %' : '';
  let $pop_chart = $(`#${containerId}`);
  const c_width = parseInt($pop_chart.width());
  const c_height = parseInt($pop_chart.height());
  let $chart_canvas = $(`<canvas id="${containerId}_canvas" width="${c_width}" height="${c_height}"></canvas>`);
  $pop_chart.append($chart_canvas);
  let chart_options = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: {
        display: options?.legend?.display ?? true,
      },
      title: {
        display: false,
      },
      tooltip: {
        callbacks: {
          label: (context) => {
            let label = context.label || '';
            if (label) {
              label += ': ';
            }

            if (context.raw !== null) {
              label += numberFormatter0Digits(context.raw) + post_fixe_label;
            }

            return label;
          },
        },
      },
      scales: {
        y: {
          beginAtZero: true,
        },
      },
    },
  };
  new Chart($chart_canvas, {
    type: 'bar',
    data: chart_data,
    options: chart_options,
  });
};
const render_doughnutchart = (fields, data, containerId, options) => {
  const labels = fields.map((f) => f.label);
  const datasets = [
    {
      label: options.title,
      data: fields.map((f) => data[f.id]),
      backgroundColor: fields.map((f) => f.color),
    },
  ];
  const chart_data = {
    labels,
    datasets,
  };
  const is_percent_val = options?.is_percent ?? false;
  let post_fixe_label = is_percent_val ? ' %' : '';

  let $pop_chart = $(`#${containerId}`);
  const c_width = parseInt($pop_chart.width());
  const c_height = parseInt($pop_chart.height());
  let $chart_canvas = $(`<canvas id="${containerId}_canvas" width="${c_width}" height="${c_height}"></canvas>`);
  $pop_chart.append($chart_canvas);
  let chart_options = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      title: {
        display: false,
      },
      tooltip: {
        callbacks: {
          label: (context) => {
            let label = context.label || '';
            if (label) {
              label += ': ';
            }

            if (context.raw !== null) {
              label += numberFormatter0Digits(context.raw) + post_fixe_label;
            }

            return label;
          },
        },
      },
    },
  };
  let final_chart_options = {
    type: 'doughnut',
    data: chart_data,
    options: chart_options,
  };
  if (options.datalabels) {
    datasets.forEach((ds) => {
      ds.datalabels = {
        anchor: 'center',
        backgroundColor: null,
        borderWidth: 0,
        color: 'white',
      };
    });
    chart_options.plugins.datalabels = options.datalabels.plugins;
    final_chart_options.plugins = [ChartDataLabels];
  }
  new Chart($chart_canvas, final_chart_options);
};
