import { color_buckets } from '../constants/colors.mjs';
import Zone from './zone.mjs';

export default class ZonesChalandises {
  constructor(data, options = {}) {
    this.options_ = options;
    this.zones_ = [];
    this.profile = 'driving-car';
    this.setData(data);
  }

  setProfile(value) {
    this.profile = value;
  }

  getProfile() {
    return this.profile;
  }

  getZones(index = undefined) {
    if(index !== undefined) return this.zones_[index];
    return this.zones_;
  }

  setZones(values) {
    this.zones_ = values;
  }

  setData(data) {
    if (!data) {
      this.setDefaultData_();
      return;
    }
    this.center = data?.center ?? null;
    this.profile = data?.profile ?? 'foot-walking';
    data.zones.forEach((dz) => {
      this.zones_.push(new Zone(dz, {}));
    });
  }

  setDefaultData_() {
    const defaultzones_config = [
      {
        id: 0,
        range: 10,
        label: 'Zone primaire',
        color: color_buckets[0],
        active: true,
      },
      {
        id: 1,
        range: 20,
        label: 'Zone secondaire',
        color: color_buckets[1],
        active: true,
      },
      {
        id: 2,
        range: 30,
        label: 'Zone tertiaire',
        color: color_buckets[2],
        active: true,
      },
    ];
    defaultzones_config.forEach((dz) => {
      this.zones_.push(new Zone(dz, {}));
    });
  }

  toJSON() {
    return {
      profile: this.profile,
      center: this.center,
      zones: this.zones_.map((z) => z.toJSON()),
    };
  }

  toGeoJSON() {
    return {
      type: "FeatureCollection",
      features: [
        {type: 'features', geometry: this.getZones(2).getGeometry(), properties: {value: this.getZones(2).getRange(), bucket: 2, label: this.getZones(2).getLabel(), color: this.getZones(2).getColor()}},
        {type: 'features', geometry: this.getZones(1).getGeometry(), properties: {value: this.getZones(1).getRange(), bucket: 1, label: this.getZones(1).getLabel(), color: this.getZones(1).getColor()}},
        {type: 'features', geometry: this.getZones(0).getGeometry(), properties: {value: this.getZones(0).getRange(), bucket: 0, label: this.getZones(0).getLabel(), color: this.getZones(0).getColor()}}
      ]
    };
  }

  getTiledInformation() {
    const transport_modes = {
      'foot-walking': 'direction_walk',
      'cycling-regular': 'direction_bike',
      'driving-car': 'direction_car',
    };
    let ranges = `
    <div class="slds-m-horizontal_x-small" style="font-size:smaller; display:inline-block;">${this.zones_.map((z) => z.getRange()).join(',')} min</div>`;
    let profile_icon = `
    <span class="slds-icon_container" title="Paramètres">
      <svg class="slds-icon slds-icon_x-small slds-icon-text-light" aria-hidden="true">
        <use xlink:href="/images/svg/symbols.svg#${transport_modes[this.getProfile()]}"></use>
      </svg>
      <span class="slds-assistive-text">Paramètres</span>
    </span>`;

    return `
      ${profile_icon}
      ${ranges}
      <button class="slds-button slds-button_icon" title="Settings" data-action="zc-settings-btn">
        <svg class="slds-button__icon" aria-hidden="true">
          <use xlink:href="/styles/slds/assets/icons/utility-sprite/svg/symbols.svg#settings"></use>
        </svg>
        <span class="slds-assistive-text">Settings</span>
      </button>`;
  }
}
