const path = require('path');
const fs = require('fs');
const postgres = require('../server/db/postgres');

const { check_config } = require('../server/helpers/config');
check_config();

let errors = {};

let { SCHEMA_TABLE = 'public', SCHEMA_COMMON = 'public' } = process.env;

const create_tables = async () => {
  console.log(`DB Tables will be create in schema '${SCHEMA_TABLE}'`);

  let create_errors = [];
  const scripts_to_load = [
    {
      label: 'Create ggo_simulation TABLE                      ',
      error_message: 'Failed to create ggo_simulation TABLE',
      file_path: path.join(__dirname, './db/schemas/ggo_simulation_table.sql'),
    },
    {
      label: 'Create ggo_simulation TABLE INDEX                ',
      error_message: 'Failed to create ggo_simulation TABLE INDEX',
      file_path: path.join(__dirname, './db/schemas/ggo_simulation_table_idx.sql'),
    },
    {
      label: 'Create ggo_simulation_zones TABLE                ',
      error_message: 'Failed to create ggo_simulation_zones TABLE',
      file_path: path.join(__dirname, './db/schemas/ggo_simulation_zones.sql'),
    },
    {
      label: 'Create ggo_simulation_concurrence TABLE          ',
      error_message: 'Failed to create ggo_simulation_concurrence TABLE',
      file_path: path.join(__dirname, './db/schemas/ggo_simulation_concurrence.sql'),
    },
    {
      label: 'Create ggo_simulation_cannibalisation TABLE      ',
      error_message: 'Failed to create ggo_simulation_cannibalisation TABLE',
      file_path: path.join(__dirname, './db/schemas/ggo_simulation_cannibalisation.sql'),
    },
    {
      label: 'Create ggo_simulation_job TABLE                  ',
      error_message: 'Failed to create ggo_simulation_job TABLE',
      file_path: path.join(__dirname, './db/schemas/ggo_simulation_job.sql'),
    },
  ];
  const nb_scripts = scripts_to_load.length;
  for (let s = 0; s < nb_scripts; s++) {
    const script_to_load = scripts_to_load[s];
    process.stdout.write(` ${s + 1}. ${script_to_load.label}`);
    let buffer = fs.readFileSync(script_to_load.file_path);
    let create_query = buffer.toString();
    //console.log(`create_query : ${create_query}`);
    if (SCHEMA_TABLE !== '') {
      create_query = create_query.replace(/sc_fnacdarty./g, `${SCHEMA_TABLE}.`);
    }
    try {
      await postgres.query(create_query);
      process.stdout.write('\t\x1b[32mOK\x1b[89m\x1b[0m\n');
    } catch (err_create) {
      //console.error(scripts_to_load.error_message, err_create);
      create_errors.push(`${script_to_load.error_message} : ${err_create.message}`);
      process.stdout.write('\t\x1b[31mKO\x1b[89m\x1b[0m\n');
    }
  }
  return create_errors;
};

const check_tables_exists = async () => {
  process.stdout.write(`\nVérification de l'existance des différentes tables\n`);
  let check_errors = [];
  const exists_to_check = [
    {
      label: `Test exists table ${SCHEMA_TABLE}.fnac_concurrence  `,
      query: `SELECT to_regclass('${SCHEMA_TABLE}.fnac_concurrence') as tbl`,
      error_message: `Unable to find table ${SCHEMA_TABLE}.fnac_concurrence`,
    },
    {
      label: `Test exists table ${SCHEMA_COMMON}.iris_essentiel   `,
      query: `SELECT to_regclass('${SCHEMA_COMMON}.iris_essentiel') as tbl`,
      error_message: `Unable to find table ${SCHEMA_COMMON}.iris_essentiel`,
    },
    {
      label: `Test exists table ${SCHEMA_COMMON}.data_revenu     `,
      query: `SELECT to_regclass('${SCHEMA_COMMON}.data_revenu') as tbl`,
      error_message: `Unable to find table ${SCHEMA_COMMON}.data_revenu`,
    },
    {
      label: `Test exists table ${SCHEMA_COMMON}.data_population `,
      query: `SELECT to_regclass('${SCHEMA_COMMON}.data_population') as tbl`,
      error_message: `Unable to find table ${SCHEMA_COMMON}.data_population`,
    },
  ];
  const nb_tables = exists_to_check.length;
  for (let s = 0; s < nb_tables; s++) {
    const exist_to_check = exists_to_check[s];
    process.stdout.write(` ${s + 1}. ${exist_to_check.label}`);
    try {
      const res_exist = await postgres.query(exist_to_check.query);
      if (res_exist.rows[0].tbl === null) {
        check_errors.push(exist_to_check.error_message);
        process.stdout.write('\t\x1b[31mKO\x1b[89m\x1b[0m\n');
      } else {
        process.stdout.write('\t\x1b[32mOK\x1b[89m\x1b[0m\n');
      }
    } catch (err_exist) {
      check_errors.push(`Globl check table exits error ; ${err_exist.message}`);
    }
  }
  return check_errors;
};

const run = async () => {
  errors.create_tables = await create_tables();

  if (errors.create_tables.length > 0) {
    console.error('\nErreurs de création des tables');
    errors.create_tables.forEach((ec) => {
      console.error(`  - ${ec}`);
    });
  }

  errors.check_exists = await check_tables_exists();
  if (errors.check_exists.length > 0) {
    console.error(`\nErreurs de vérification d'existance des tables`);
    errors.check_exists.forEach((ec) => {
      console.error(`  - ${ec}`);
    });
  }

  process.exit();
};

run();
