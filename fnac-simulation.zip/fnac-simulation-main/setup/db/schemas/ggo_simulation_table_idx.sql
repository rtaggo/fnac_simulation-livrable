CREATE UNIQUE INDEX IF NOT EXISTS uniq_idx_id_simulation
ON sc_fnacdarty.ggo_simulation(id) WHERE id is not null;
