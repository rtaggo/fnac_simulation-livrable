exports.check_config = () => {
  const keys_to_check = [
    'MAPBOX_API_KEY',
    'GGO_REST_API_URL',
    'JWT_SECRET',
    'JWT_EXPIRESIN',
    'JWT_TOKENNAME',
    'POSTGRES_USER',
    'POSTGRES_PASSWORD',
    'POSTGRES_DATABASE_NAME',
    'POSTGRES_HOST',
    'POSTGRES_PORT',
    'SCHEMA_TABLE',
    'SCHEMA_COMMON',
  ];
  let missings = [];
  keys_to_check.forEach((k) => {
    if (!process.env[`${k}`]) {
      missings.push(`Add ${k} to .env file`);
    }
  });

  if (!process.env.USER_MODE) {
    missings.push(`Add USER_MODE to .env file`);
  }

  if (process.env.USER_MODE === 'galigeo') {
    if (!process.env.LOGIN_SERVER) {
      missings.push(`Add LOGIN_SERVER to .env file`);
    }
  }

  if (process.env.SIMULATION_RUN === 'rscript') {
    if (!process.env.SIMULATION_RSCRIPT_PATH) {
      missings.push(`Add SIMULATION_RSCRIPT_PATH to .env file`);
    } else {
      if (process.env.SIMULATION_RSCRIPT_PATH === 'PUT_ABSOLUTE_PATH_TO_R_SCRIPT') {
        missings.push(`Change SIMULATION_RSCRIPT_PATH value in the .env file`);
      }
    }
  }

  if (process.env.GEOCODER === 'here') {
    if (!process.env.HERE_API_KEY) {
      missings.push(`Add HERE_API_KEY to .env file (needed by geocoder ${process.env.GEOCODER})`);
    }
  }

  if (missings.length > 0) {
    console.log('');
    missings.forEach((m) => {
      console.warn(` - ${m}`);
    });
    process.exit();
  }
};
