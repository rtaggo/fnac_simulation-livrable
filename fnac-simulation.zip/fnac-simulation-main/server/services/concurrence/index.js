const postgres = require('../../db/postgres');

exports.get_concurrence_in_zones = async (zones, callback) => {
  const turf = require('@turf/turf');
  try {
    const geojson = {
      type: 'FeatureCollection',
      features: zones.zones.map((z) => {
        return { type: 'Feature', geometry: z.geometry };
      }),
    };
    if (geojson.features.length === 0) {
      callback({
        error: 'Geometry is empty',
      });
      return;
    }
    const combined = turf.combine(geojson);
    if (combined.features.length === 0) {
      callback({
        error: 'Combined Geometry is empty',
      });
      return;
    }
    const buffered = turf.buffer(combined, 2, { units: 'kilometers' });
    const { SCHEMA_TABLE } = process.env;

    let area_subquery = `WITH study_area AS (
      SELECT ST_SetSRID(ST_GeomFromGeoJSON('${JSON.stringify(buffered.features[0].geometry)}'), 4326) as area_geom)`;
    const query = `${area_subquery}
    SELECT c.*,
      st_distance(
        ST_Transform(ST_SetSRID(st_point(${zones.center.longitude}, ${zones.center.latitude}), 4326), 3857), 
        ST_Transform(ST_SetSRID(st_point(c.fnac_long, c.fnac_lat), 4326), 3857)
      ) as dist_meter 
    FROM ${SCHEMA_TABLE}.fnac_concurrence c, study_area sa
    WHERE ST_Within(ST_SetSRID( ST_Point(c.fnac_long, c.fnac_lat), 4326), area_geom)`;
    postgres
      .query(query)
      .then((query_res) => {
        const coord_fields = new Set(['fnac_lat', 'fnac_long']);
        const props_fields = query_res.fields.filter((f) => !coord_fields.has(f.name));
        let competitors_geojson = {
          type: 'FeatureCollection',
          features: query_res.rows.map((r) => {
            let feature = {
              type: 'Feature',
              geometry: {
                type: 'Point',
                coordinates: [+r.fnac_long, +r.fnac_lat],
              },
              properties: build_competitor_properties(r, props_fields),
            };
            return feature;
          }),
        };

        callback(null, competitors_geojson);
      })
      .catch((err_query) => {
        callback({ error: err_query });
      });
  } catch (err) {
    callback({ error: err });
  }
};

const build_competitor_properties = (row, fields) => {
  let props = {};
  fields.forEach((f) => {
    props[f.name] = row[f.name];
  });
  props.selected = true;
  return props;
};

exports.get_simulation_concurrence = (simulation_id, callback) => {
  if (!simulation_id) {
    callback({ error: 'Simulation id not set' });
  }
  try {
    const { SCHEMA_TABLE } = process.env;

    const query_concurrence = `SELECT id_simulation, fnac_id, fnac_category, fnac_lib_mag, fnac_idens, fnac_libens, fnac_adr, fnac_cp, fnac_ville, fnac_pays, fnac_code_geo, fnac_niveau, fnac_contrat, fnac_surfventec, fnac_datecrea, fnac_long, fnac_lat, fnac_niveauconc, fnac_visible, fnac_caht_conc, fnac_periode_ca, fnac_topconc, selected, dist_meter 
    FROM ${SCHEMA_TABLE}.ggo_simulation_concurrence WHERE id_simulation='${simulation_id}'`;
    postgres
      .query(query_concurrence)
      .then((query_res) => {
        const coord_fields = new Set(['fnac_lat', 'fnac_long']);
        const props_fields = query_res.fields.filter((f) => !coord_fields.has(f.name) && f.name !== 'id_simulation');
        let competitors_geojson = {
          type: 'FeatureCollection',
          features: query_res.rows.map((r) => {
            let feature = {
              type: 'Feature',
              geometry: {
                type: 'Point',
                coordinates: [+r.fnac_long, +r.fnac_lat],
              },
              properties: build_competitor_properties(r, props_fields),
            };
            return feature;
          }),
        };

        callback(null, competitors_geojson);
      })
      .catch((err_query) => {
        callback({ error: err_query });
      });
  } catch (err_catched) {
    callback({ error: 'Failed to query competitors' });
  }
  //callback(null, { data: 'TODO' });
};
