const postgres = require('../../../db/postgres');
exports.update_simulation_zones_table = async (simulation_id, zones) => {
  let update_result = {
    nb_deleted: 0,
    nb_inserted: 0,
    zones: [],
  };
  try {
    const { SCHEMA_TABLE, SCHEMA_COMMON } = process.env;
    const clear_zones_table_query = `DELETE FROM ${SCHEMA_TABLE}.ggo_simulation_zones WHERE id_simulation='${simulation_id}'`;
    const res_delete = await postgres.query(clear_zones_table_query);
    update_result.nb_deleted = res_delete.rowCount;
    if (zones && Array.isArray(zones) && zones.length > 0) {
      const w_zones = zones.map((z) => {
        return { id: z.id, geometry: z.geometry };
      });
      const nb_w_zones = w_zones.length;
      for (let zi = 0; zi < nb_w_zones; zi++) {
        //
        const a_zone = w_zones[zi];
        let a_zone_stats = {
          id: a_zone.id,
          nb_inserted: 0,
        };
        try {
          const area_query = `WITH zone AS (
            SELECT ST_SetSRID(ST_GeomFromGeoJSON('${JSON.stringify(a_zone.geometry)}'), 4326) as area_geom
          )`;
          const insert_query = `${area_query}
          INSERT INTO ${SCHEMA_TABLE}.ggo_simulation_zones(id_simulation, id_zone, code_iris, estimation_ca)
          SELECT '${simulation_id}' id_simulation, ${a_zone.id} id_zone, i.iris, null
          FROM  ${SCHEMA_COMMON}.iris_essentiel i, zone z
          WHERE ST_Within(ST_SetSRID( ST_Point(i.long_wgs84, i.lat_wgs84), 4326), area_geom)`;
          console.log(insert_query);
          const res_insert = await postgres.query(insert_query);
          a_zone_stats.nb_inserted = res_insert.rowCount;
          update_result.nb_inserted += res_insert.rowCount;
        } catch (err_zone) {
          a_zone_stats.error = `Failed to insert data for zone ${a_zone.id}`;
        }
        update_result.zones.push(a_zone_stats);
      }
    }
  } catch (err) {
    const logger = require('../../../lib/logger');
    logger.error('Global error while inserting zones: ' + err);
    console.error('Global error while inserting zones', err);
    update_result.error = 'Global error while inserting zones';
    update_result.error_details = err;
  }
  return update_result;
};
