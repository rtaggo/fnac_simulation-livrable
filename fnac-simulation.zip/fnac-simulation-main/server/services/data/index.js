const postgres = require('../../db/postgres');

exports.getDemography = async (zones, callback) => {
  const turf = require('@turf/turf');
  try {
    const { SCHEMA_COMMON } = process.env;
    const geojson = {
      type: 'FeatureCollection',
      features: zones.zones.map((z) => {
        return { type: 'Feature', geometry: z.geometry };
      }),
    };
    if (geojson.features.length === 0) {
      callback({
        error: 'Geometry is empty',
      });
      return;
    }
    let combined = turf.combine(geojson);
    if (combined.features.length === 0) {
      callback({
        error: 'Combined Geometry is empty',
      });
      return;
    }

    let area_subquery = `WITH study_area AS (
      SELECT ST_SetSRID(ST_GeomFromGeoJSON('${JSON.stringify(combined.features[0].geometry)}'), 4326) as area_geom)`;
    let output_fields = [
      'COUNT(*) nb',
      'SUM(i.p_pop) as population',
      'SUM(i.p_log) as logement',
      'SUM(i.c_men) as menage',
      'SUM(c.potentiel) potentiel',
      /*'SUM(r.rftot) as revenu' */
      'SUM(c_men_cs1) as men_cs1',
      'SUM(c_men_cs2) as men_cs2',
      'SUM(c_men_cs3) as men_cs3',
      'SUM(c_men_cs4) as men_cs4',
      'SUM(c_men_cs5) as men_cs5',
      'SUM(c_men_cs6) as men_cs6',
      'SUM(c_men_cs7) as men_cs7',
      'SUM(c_men_cs8) as men_cs8',
      'SUM(c_men_cs2) + SUM(c_men_cs3)+ SUM(c_men_cs4) as csp_p',
      'SUM(c_men_cs5) + SUM(c_men_cs6) as csp_m',
      'SUM(r.rftot) / SUM(i.c_men) as revenu_moyen',
      'SUM(p.p_poph) as p_poph',
      'SUM(p.p_popf) as p_popf',
      'SUM(p.p_h0014) as p_h0014',
      'SUM(p.p_h1529) as p_h1529',
      'SUM(p.p_h3044) as p_h3044',
      'SUM(p.p_h4559) as p_h4559',
      'SUM(p.p_h6074) as p_h6074',
      'SUM(p.p_h75p) as p_h75p',
      'SUM(p.p_f0014) as p_f0014',
      'SUM(p.p_f1529) as p_f1529',
      'SUM(p.p_f3044) as p_f3044',
      'SUM(p.p_f4559) as p_f4559',
      'SUM(p.p_f6074) as p_f6074',
      'SUM(p.p_f75p) as p_f75p',
      'SUM(i.p_rp) as p_rp',
      'SUM(i.p_rsecocc) as p_rsecocc',
      'SUM(i.p_logvac) as p_logvac',
      'SUM(i.p_rp_prop) as p_rp_prop',
      'SUM(i.p_rp_loc) as p_rp_loc',
      'SUM(i.p_rp_grat) as p_rp_grat',
      'SUM(i.p_maison) as p_maison',
      'SUM(i.p_appart) as p_appart',
    ];
    let data_query = `${area_subquery} 
    SELECT ${output_fields.join(', ')}
    FROM ${SCHEMA_COMMON}.iris_essentiel i
    JOIN ${SCHEMA_COMMON}.data_revenu r on i.iris = r.iris
    JOIN ${SCHEMA_COMMON}.data_population p on i.iris = p.iris
    left join ca_potentiel_fnac c on i.iris = c.iris
    , study_area sa WHERE ST_Within(ST_SetSRID( ST_Point(i.long_wgs84, i.lat_wgs84), 4326), area_geom)`;
    console.log(data_query);

    postgres.query(data_query).then((query_res) => {
      if (query_res.rows && query_res.rows.length > 0) {
        let row = query_res.rows[0];
        row.nb = +row.nb;
        callback(null, row);
      } else {
        callback({ error: 'something went wrong' });
      }
    });
  } catch (err) {
    callback({ error: err });
  }
};
