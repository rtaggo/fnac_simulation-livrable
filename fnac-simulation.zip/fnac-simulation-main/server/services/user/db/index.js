exports.signup = async (req, res) => {
  try {
    return res.status(200).json({
      success: true,
      message: 'Registration Success',
      todo: 'Faire enregistrement utilisateur',
    });
  } catch (error) {
    console.error('signup-error', error);
    return res.status(500).json({
      error: true,
      message: 'Cannot Register',
    });
  }
};

exports.login = async (req, res) => {
  try {
    const { login, password } = req.body;

    if (!login || !password) {
      return res.status(400).json({
        error: true,
        message: 'Cannot authorize user.',
      });
    }
    return res.send({
      success: true,
      message: 'User logged in successfully',
      /*accessToken: token,*/
    });
  } catch (err) {
    console.error('Login error', err);
    return res.status(500).json({
      error: true,
      message: "Couldn't login. Please try again later.",
      message_fr: 'Impossible de vous connecter. Veuillez réessayer plus tard.',
    });
  }
};

exports.logout = async (req, res) => {
  try {
    res.clearCookie(process.env.JWT_TOKENNAME);
    return res.send({ success: true, message: 'User Logged out' });
  } catch (error) {
    console.error('user-logout-error', error);
    return res.stat(500).json({
      error: true,
      message: error.message,
    });
  }
};

exports.current = async (req, res) => {
  try {
    return res.send({ message: 'Current User', todo: 'Fetch user info' });
  } catch (error) {
    console.error('user-current-error', error);
    return res.stat(500).json({
      error: true,
      message: error.message,
    });
  }
};
