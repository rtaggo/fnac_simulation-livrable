const { Pool } = require('pg');
let pgTypes = require('pg').types;

pgTypes.setTypeParser(701, 'text', parseFloat);
pgTypes.setTypeParser(23, 'text', parseInt);
pgTypes.setTypeParser(1700, parseFloat);

const pgConfig = {
  user: process.env.POSTGRES_USER,
  password: process.env.POSTGRES_PASSWORD,
  database: process.env.POSTGRES_DATABASE_NAME,
  host: process.env.POSTGRES_HOST,
  port: process.env.POSTGRES_PORT,
};

const pgPool = new Pool(pgConfig);

module.exports = {
  query: (text, params) => pgPool.query(text, params),
};
