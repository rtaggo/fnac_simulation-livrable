'use strict';

const express = require('express');
const router = express.Router();

const VERSION = 'V1';

router.get('/', (req, res) => {
  res.header('Content-Type', 'application/json');
  res.json({ message: '[GET] /rest/ is alive!!! ', version: VERSION });
});

router.use('/config', require('../controllers/config'));
router.use('/geoservice', require('../controllers/geoservice'));
router.use('/user', require('../controllers/user'));
router.use('/simulation', require('../controllers/simulation'));
router.use('/data', require('../controllers/data'));
router.use('/concurrence', require('../controllers/concurrence'));
router.use('/job', require('../controllers/job'));
/*
router.use('/competitor', require('../controllers/competitor'));
*/
module.exports = router;
