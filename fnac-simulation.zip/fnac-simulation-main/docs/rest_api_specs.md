# REST API Specs

L'url de base de l'ensemble des services, cités ci-après, est:

`/rest`

- [/geoservice](geoservice.md)
- [/user](user.md)
- [/simulation](simulation.md)
- [/data](data.md)
- [/concurrence](concurrence.md)
- [/job](job.md)
