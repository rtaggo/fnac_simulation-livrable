import EventBus from '../helpers/eventbus.mjs';
import { MAPISLOADED, MAPISMOVEND } from '../constants/events.mjs';

export default class MapManager {
  constructor(options = {}) {
    this.options_ = options;
    this.options_.mapDivId = this.options_?.mapDivId ?? 'map';
    mapboxgl.accessToken = this.options_.mapboxAccessToken;
    this.current_location_ = {};

    this.onMapLoadedCallback = options.onMapLoadedCallback;
    const nullFunc = () => { };
    if (typeof this.onMapLoadedCallback === 'undefined') {
      this.onMapLoadedCallback = nullFunc;
    }
    /*
    this.map_padding_ = {
      left: 400,
    };
    */

    this.init_();
    MapManager.instance_ = this;
    return this;
  }

  static getInstance(options = {}) {
    if (MapManager.instance_) {
      return MapManager.instance_;
    }
    return new MapManager(options);
  }

  init_() {
    if ($(document).width() < 768) {
      this.map_padding_.left = 0;
    }
    this.setupListeners_();
    this.setupMap_();
  }

  setupListeners_() {
    /*
    EventBus.addEventListener(
      LOCATIONCHANGED,
      (e) => {
        this.setCurrentLocation(e.target.coordinates, { flyTo: true });
      },
      this
    );
    */
  }

  setupMap_() {
    let mapStyle = 'mapbox://styles/mapbox/streets-v11';
    mapStyle = 'mapbox://styles/mapbox/light-v10';
    //mapStyle = 'https://maputnik.github.io/osm-liberty/style.json';
    this.map_ = new mapboxgl.Map({
      container: this.options_.mapDivId,
      style: mapStyle,
      attributionControl: false,
      preserveDrawingBuffer: true,
      center: [1.7191036, 46.71109], // starting position [lng, lat]
      zoom: 5, // starting zoom
    });

    if ($(document).width() <= 700) {
      const mb_padding = $(document).height() * 0.34;
      this.map_padding_ = {
        left: 0,
        bottom: mb_padding,
      };
    }

    this.map_.addControl(new mapboxgl.NavigationControl(), 'bottom-right');

    this.map_.on('load', () => {
      EventBus.dispatch(MAPISLOADED, { map: this.map_ });
      this.onMapLoadedCallback();
    });
    this.map_.on('moveend', () => {
      EventBus.dispatch(MAPISMOVEND, { map: this.map_ });
    });
    // Create a popup, but don't add it to the map yet.
    this.popupTooltip = new mapboxgl.Popup({
      closeButton: false,
      closeOnClick: false,
    });
  }

  addLayer(layer_id, geojson, properties, options = {}) {
    if (typeof this.map_.getSource(`${layer_id}`) === 'undefined') {
      //
      this.map_.addSource(`${layer_id}`, { type: 'geojson', data: geojson });
      this.map_.addLayer(properties);
      if (options.addTooltip) {
        this.addLayerTooltipEvent(layer_id, options.generateHtml);
      }
    } else {
      this.map_.getSource(`${layer_id}`).setData(geojson);
    }
  }
  addLayerTooltipEvent(layerName, generateHtml, fields) {
    this.map_
      .on('mouseenter', layerName, (e) => {
        // Change the cursor style as a UI indicator.
        this.map_.getCanvas().style.cursor = 'pointer';

        // Copy coordinates array.
        let htmlTooltip = '';
        if (generateHtml) {
          htmlTooltip = generateHtml(e.features[0]);
        } else {
          htmlTooltip = '<table class="slds-table slds-table_cell-buffer slds-table_bordered slds-table_header-hidden">';
          const fields_set = fields ? new Set(fields.split(',')) : new Set();
          for (const [key, value] of Object.entries(e.features[0].properties)) {
            if (fields_set.size > 0) {
              if (fields_set.has(key)) {
                htmlTooltip += `<tr><td style="font-weight: bold;">${key}</td><td>${value}</td></tr>`;
              }
            } else {
              htmlTooltip += `<tr><td style="font-weight: bold;">${key}</td><td>${value}</td></tr>`;
            }
          }
          htmlTooltip += '</table>';
        }

        const coordinates = e.features[0].geometry.coordinates.slice();
        while (Math.abs(e.lngLat.lng - coordinates[0]) > 180) {
          coordinates[0] += e.lngLat.lng > coordinates[0] ? 360 : -360;
        }
        this.popupTooltip.setLngLat(coordinates).setHTML(htmlTooltip).addTo(this.map_);
      })
      .on('mouseleave', layerName, () => {
        this.map_.getCanvas().style.cursor = '';
        this.popupTooltip.remove();
      });
  }

  setCurrentLocation(coordinates, options) {
    this.current_location_.coordinates = coordinates;
    if (!this.current_location_.marker) {
      this.createLocationMarker(coordinates);
    } else {
      this.current_location_.marker.setLngLat([coordinates.longitude, coordinates.latitude]);
    }
    if (options.panTo) {
      this.map_.panTo([coordinates.longitude, coordinates.latitude]);
      return;
    }

    if (options.flyTo) {
      this.map_.flyTo({ center: [coordinates.longitude, coordinates.latitude], zoom: 13 });
      return;
    }
  }

  createLocationMarker(coordinates) {
    const geojson = {
      type: 'FeatureCollection',
      features: [
        {
          type: 'Feature',
          geometry: {
            type: 'Point',
            coordinates: [coordinates.longitude, coordinates.latitude],
          },
          properties: {
            title: 'Store Location',
          },
        },
      ],
    };
    if (typeof this.map_.getSource('store_location') === 'undefined') {
      if (this.map_.hasImage('store-marker')) {
        this.addStoreMarker(geojson);
      } else {
        this.map_.loadImage('/images/target-marker-ggo.png', (error, image) => {
          if (error) throw error;
          this.map_.addImage('store-marker', image);
          this.addStoreMarker(geojson);
        });
      }
    } else {
      this.map_.getSource('store_location').setData(geojson);
    }
  }

  addStoreMarker(geojson) {
    this.map_.addSource('store_location', {
      type: 'geojson',
      data: geojson,
    });
    this.map_.addLayer({
      id: 'store_location_layer',
      type: 'symbol',
      source: 'store_location',
      layout: {
        'icon-image': 'store-marker',
        'icon-anchor': 'bottom',
      },
    });
  }

  addPoint(coordinates, sourceId, imageId, imageUrl, label) {
    const geojson = {
      type: 'FeatureCollection',
      features: [
        {
          type: 'Feature',
          geometry: {
            type: 'Point',
            coordinates: [coordinates.longitude, coordinates.latitude],
          },
          properties: {
            //title: 'Store Location',
          },
        },
      ],
    };
    if (label) geojson.features[0].properties._label = label;
    this.addPointLayer(geojson, sourceId, imageId, imageUrl);
  }
  /**
   * Create a point layer from a geojson
   * If a property _label exists, then show it as a label
   *
   * @param geojson
   * @param sourceId
   * @param imageId
   * @param imageUrl
   */
  addPointLayer(geojson, sourceId, imageId, imageUrl, options = {}) {
    const addPointLayer_ = (options) => {
      this.map_.addSource(sourceId, {
        type: 'geojson',
        data: geojson,
      });
      const layerOptions = {
        id: sourceId + '_layer',
        type: 'symbol',
        source: sourceId,
        layout: {
          'text-field': ['get', '_label'],
          'text-variable-anchor': ['top', 'bottom', 'left', 'right'],
          'text-size': 10,
          'text-radial-offset': 0.5,
          'text-justify': 'auto',
          'icon-image': imageId,
          'icon-anchor': 'bottom',
        },
      };
      if (options && options.filter) {
        layerOptions.filter = options.filter;
      }
      this.map_.addLayer(layerOptions);
      if (options && options.addTooltip) {
        this.addLayerTooltipEvent(sourceId + '_layer', options.generateHtml, options.tooltipFields);
      }
    };

    if (typeof this.map_.getSource(sourceId) === 'undefined') {
      if (this.map_.hasImage(imageId)) {
        addPointLayer_(options);
      } else {
        this.map_.loadImage(imageUrl, (error, image) => {
          if (error) throw error;
          this.map_.addImage(imageId, image);
          addPointLayer_(options);
        });
      }
    } else {
      this.map_.getSource(sourceId).setData(geojson);
    }
  }

  isInExtend(coordinates) {
    const bounds = this.map_.getBounds();
    const ll = new mapboxgl.LngLat(coordinates.longitude, coordinates.latitude);
    return bounds.contains(ll);
  }
  flyTo(coordinates, zoom) {
    this.map_.flyTo({
      center: [coordinates.longitude, coordinates.latitude],
      zoom: zoom ? zoom : 9,
      essential: true, // this animation is considered essential with respect to prefers-reduced-motion
    });
  }

  startListenClickOnMap(callback) {
    this._mapClickCallback = callback;
    this.map_.getCanvas().style.cursor = 'pointer';
    this.map_.on('click', this._mapClickCallback);
  }

  stopListenClickOnMap() {
    if (this._mapClickCallback) {
      this.map_.off('click', this._mapClickCallback);
      this._mapClickCallback = undefined;
    }
    this.map_.getCanvas().style.cursor = 'default';
  }
  stopListenClickOnMapMomentary(time) {
    if (this._mapClickCallback) {
      this.map_.off('click', this._mapClickCallback);
      this.map_.getCanvas().style.cursor = 'default';
      setTimeout(() => {
        this.map_.getCanvas().style.cursor = 'pointer';
        this.map_.on('click', this._mapClickCallback);
      }, time);
    }
  }
}
