export const modal_confirm = (text, callback, condition = true) => {
  if (!condition) {
    callback();
    return;
  }

  const $content = $(`
    <section role="dialog" tabindex="-1" aria-labelledby="modal-heading-01" aria-modal="true" aria-describedby="modal-content-id-1" class="slds-modal slds-fade-in-open">
      <div class="slds-modal__container">
      <div class="slds-modal__content slds-p-around_medium" id="modal-content-id-1">
        <p>${text}</p>
      </div>
      <footer class="slds-modal__footer">
        <button id="model_cancel" class="slds-button slds-button_neutral">Annuler</button>
        <button id="modal_confirm" class="slds-button slds-button_brand">Confirmer</button>
      </footer>
      </div>
    </section>
    <div class="slds-backdrop slds-backdrop_open"></div>
    `);

  $('body').append($content);

  $('#model_cancel').on('click', () => {
    $content.remove();
  });
  $('#modal_confirm').on('click', () => {
    $content.remove();
    callback();
  });
};

export const modal_input = (msg, text, callback) => {
  const $content = $(`
    <section role="dialog" tabindex="-1" aria-labelledby="modal-heading-01" aria-modal="true" aria-describedby="modal-content-id-1" class="slds-modal slds-fade-in-open">
      <div class="slds-modal__container">
      <header class="slds-modal__header">
        ${msg}
      </header>
      <div class="slds-modal__content slds-p-around_medium" id="modal-content-id-1">
        <div class="slds-form-element">
          <div class="slds-form-element__control">
            <input type="text" id="modal_input" placeholder="${msg}" value="${text ? text : ''}" required="" class="slds-input" />
          </div>
        </div>
      </div>
      <footer class="slds-modal__footer">
        <button id="model_cancel" class="slds-button slds-button_neutral">Annuler</button>
        <button id="modal_confirm" class="slds-button slds-button_brand">Valider</button>
      </footer>
      </div>
    </section>
    <div class="slds-backdrop slds-backdrop_open"></div>
    `);

  $('body').append($content);

  $('#model_cancel').on('click', () => {
    $content.remove();
  });
  $('#modal_confirm').on('click', () => {
    var newText = $('#modal_input').val();
    if (newText.length > 0) {
      $content.remove();
      callback(newText);
    }
  });
};
