/**
 * Boiler plate for combo box
 *
 * Usage :
 * <div id="my-combobox" class="slds-form-element__control"></div>
 *
 * combo_box('my-combobox', ['v1', 'v2', 'v3'], 'v2', callback);
 *
 * @param element
 * @param elementsArray
 * @param defaultValue
 * @param callback
 */
export const combo_box = (element, elementsArray, defaultValue, callback) => {
  const optionsHtml = elementsArray
    .map((value) => {
      return `<li role="presentation" class="slds-listbox__item">
        <div class="slds-media slds-listbox__option slds-listbox__option_plain slds-media_small" role="option">
            <span class="slds-media__figure slds-listbox__option-icon"></span>
            <span class="slds-media__body">
              <span class="slds-truncate" title="${value}">${value}</span>
            </span>
        </div>
      </li>`;
    })
    .join('');

  $('#' + element).empty().append(`    
    <div class="slds-combobox_container">
      <div id='${element}-main' class="slds-combobox slds-dropdown-trigger slds-dropdown-trigger_click">
        <div class="slds-combobox__form-element slds-input-has-icon slds-input-has-icon_right" role="none">
          <button type="button" class="slds-input_faux slds-combobox__input slds-has-focus" aria-labelledby="combobox-label-id-131 combobox-id-3-selected-value" aria-controls="${element}" aria-expanded="true" aria-haspopup="listbox">
            <span id='${element}-value' class="slds-truncate">${defaultValue}</span>
          </button>
          <span class="slds-icon_container slds-icon-utility-down slds-input__icon slds-input__icon_right">
            <svg class="slds-icon slds-icon slds-icon_x-small slds-icon-text-default" aria-hidden="true">
              <use xlink:href="/styles/slds/assets/icons/utility-sprite/svg/symbols.svg#down"></use>
            </svg>
          </span>
        </div>
        <div class="slds-dropdown slds-dropdown_length-5 slds-dropdown_fluid" role="listbox">
          <ul class="slds-listbox slds-listbox_vertical" role="presentation">
            ${optionsHtml}
          </ul>
        </div>
      </div>
    </div>`);

  $('#' + element + '-main').on('click', (e) => {
    /*
    création d'une closure sur element
    Suggestion:
    let $tgt = $(e.currentTarget);
    if ($tgt.hasClass('slds-is-open')) {
      $tgt.removeClass('slds-is-open');
    } else {
      $tgt.addClass('slds-is-open');
    }
    */
    if ($('#' + element + '-main').hasClass('slds-is-open')) {
      $('#' + element + '-main').removeClass('slds-is-open');
    } else {
      $('#' + element + '-main').addClass('slds-is-open');
    }
  });

  $('#' + element + '-main')
    .find('.slds-listbox__option')
    .on('click', (e) => {
      const selectedValue = $(e.target).html();
      $('#' + element + '-value').html(selectedValue);
      if (callback) {
        callback(selectedValue);
      }
    });
};
