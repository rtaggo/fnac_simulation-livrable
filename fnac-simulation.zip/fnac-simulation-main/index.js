'use strict';

const path = require('path');
const express = require('express');
const cookieParser = require('cookie-parser');
const compression = require('compression');
const morgan = require('morgan');

const { PORT = 3000 } = require('./config');
const { check_config } = require('./server/helpers/config');
check_config();

const logger = require('./server/lib/logger');
const app = express();

//const port = 3000;
app.use(morgan('tiny'));

app.use(express.json({ extended: true, limit: '50mb' }));
app.use(cookieParser());
app.use(compression());
/*
const static_options = {
  dotfiles: 'ignore',
  etag: false,
  extensions: ['htm', 'html'],
  index: false,
  maxAge: '1d',
  redirect: false,
};
*/
app.use(express.static(path.join(__dirname, 'client'), { index: false }));

app.use('/rest', require('./server/api'));

const checkAuth = require('./server/middleware/check-auth');
app.get('/', checkAuth, (req, res) => {
  res.sendFile(path.join(__dirname, `client/index.html`));
});

app.get('/simulation', checkAuth, (req, res) => {
  res.sendFile(path.join(__dirname, `client/simulation.html`));
});

app.get('/login', (req, res) => {
  res.sendFile(path.join(__dirname, `client/login.html`));
});

app.get('/alive', (req, res) => {
  logger.info('/alive');
  res.header('Content-Type', 'application/json');
  res.json({ message: '[GET] / is alive!!! ' });
});

// Basic 404 handler
app.use((req, res) => {
  res.status(404).send('Not Found');
});

// Basic error handler
app.use((err, req, res) => {
  /* jshint unused:false */
  console.error(err);
  // If our routes specified a specific response, then send that. Otherwise,
  // send a generic message so as not to leak anything.
  res.status(500).send(err.response || 'Something broke!');
});

app.listen(PORT, () => {
  logger.info(`Server listening on port ${PORT}...`);
});
