# /job

Un job permet d'identifier l'état d'avancer du calcul de simulation en cours.
Les différents statuts sont:

- queue
- start
- éventuellement d'autres
- done

Le client devra vérifier à interval régulier le statut jusqu'à ce que celui-ci soit "done" qui indiquera tout est terminé.

## Liste des jobs

`/rest/job`

**Réponse**
Renvoie un json contenant la liste des tous les jobs

```json
[
  {
    "id": "2f8b2b03-c724-5481-81e3-7f11991c9aae",
    "id_simulation": "4c806813-6d07-58cc-8cd3-a5354b2c45ac",
    "status": "done"
  },
  {
    "id": "0301a7ad-78c8-5ff5-877f-f9e69324f922",
    "id_simulation": "4c806813-6d07-58cc-8cd3-a5354b2c45ac",
    "status": "Queued"
  }
]
```

## Détails d'un job

`/rest/job/JOB_ID`

**Réponse**
Renvoie un json contenant les détails du job ayant l'identifiant JOB_ID

```json
{
  "id": "2f8b2b03-c724-5481-81e3-7f11991c9aae",
  "id_simulation": "4c806813-6d07-58cc-8cd3-a5354b2c45ac",
  "status": "done"
}
```

## Lancer le calcul d'un simulation

`/rest/job/submit?simulation=ID_SIMULATION`

**Réponse**
Renvoie un json contenant l'identifiant du job en cours

```json
{
  "job_id": "2f8b2b03-c724-5481-81e3-7f11991c9aae"
}
```
