export default class Zone {
  constructor(data, options) {
    this.data_ = data;
    this.options_ = options;
  }

  getId() {
    return this.data_.id;
  }

  getRange() {
    return this.data_.range;
  }

  setRange(range) {
    this.data_.range = range;
  }

  getLabel() {
    return this.data_.label;
  }

  getColor() {
    return this.data_.color;
  }

  getGeometry() {
    return this.data_.geometry;
  }

  setGeometry(geometry) {
    this.data_.geometry = geometry;
  }

  setActive(value) {
    this.data_.active = value;
    $(`#zone-time-${this.data_.id}`).attr('disabled', !this.data_.active).parent().parent().toggleClass('zone-item-inactive');
  }

  getActive() {
    return this.data_.active;
  }

  toJSON() {
    return {
      id: this.data_.id,
      label: this.data_.label,
      range: this.data_.range,
      color: this.data_.color,
      active: this.data_.active,
      geometry: this.data_.geometry,
    };
  }

  getHTMLElement_bk() {
    let content = `
    <div class="slds-grid slds-grid_align-spread slds-m-around_xxx-small" style="width:100%;margin-left: 0;">
      <div class="slds-col">
        <span class="slds-swatch" style="background: ${this.data_.color};"><span class="slds-assistive-text">#9df0c0</span></span> ${this.data_.label}</span>        
      </div>
      <div class="slds-col slds-grow-none">
        <input type="number" id="zone-time-${this.data_.id}" class="slds-input number-input-value" value="${this.data_.range}" data-zoneid="${this.data_.id}" min="${
      this.data_.id + 1
    }" max="60" style="width:70px" >
        min 
      </div>
    </div>`;
    return content;
  }

  getHTMLElement() {
    const z_id = this.data_.id;
    const r_range = this.data_.range;
    const i_min = z_id + 1;
    const i_max = 60 - 2 - z_id;
    const input_elt = `<input type="number" id="zone-time-${z_id}" placeholder="1" class="slds-input slds-input_counter" value="${r_range}"  data-zoneid="${z_id}" min="${i_min}" max="${i_max}" step="1"/>`;
    let content = `
    <div class="slds-grid slds-grid_align-spread slds-m-around_xxx-small" style="width:100%;margin-left: 0;">
      <div class="slds-col">
        <span class="slds-swatch" style="background: ${this.data_.color};"><span class="slds-assistive-text">#9df0c0</span></span> ${this.data_.label}</span>        
      </div>
      <div class="slds-col slds-grow-none">
        <div class="slds-form-element">
          <div class="slds-form-element__control">
            <button class="slds-button slds-button_icon slds-button_icon-small slds-input__button_decrement" title="Décrémenter">
              <svg class="slds-button__icon" aria-hidden="true">
                <use xlink:href="/styles/slds/assets/icons/utility-sprite/svg/symbols.svg#ban"></use>
              </svg>
              <span class="slds-assistive-text">Decrement counter</span>
            </button>
            ${input_elt}
            <button class="slds-button slds-button_icon slds-button_icon-small slds-input__button_increment" title="Incrémenter">
              <svg class="slds-button__icon" aria-hidden="true">
                <use xlink:href="/styles/slds/assets/icons/utility-sprite/svg/symbols.svg#new"></use>
              </svg>
              <span class="slds-assistive-text">Increment counter</span>
            </button>
          </div>
        </div>
      </div>
    </div>`;
    return content;
  }
}
