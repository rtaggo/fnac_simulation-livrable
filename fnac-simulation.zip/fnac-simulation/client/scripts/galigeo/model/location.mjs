export default class Location {
    constructor(json) {
        this.address;
        this.coordinates;

        if(json) {
            this.address = json.address;
            this.coordinates = json.coordinates;
        }
    }
}