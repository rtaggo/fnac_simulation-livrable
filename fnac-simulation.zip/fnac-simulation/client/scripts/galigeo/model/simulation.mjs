import Location from './location.mjs';
import ZonesChalandises from './zones_chalandises.mjs';

export default class Simulation {
  constructor(json) {
    this.id;
    this.name;
    this.location;
    this.zc;
    this.statistics;
    this.competitors;
    this.store_properties;
    this.estimations;

    if (json) {
      this.id = json.id;
      this.name = json.name;
      this.location = new Location(json.location);
      this.zc = new ZonesChalandises(json.zc);
      this.statistics = json.statistics;
      this.competitors = json.competitors;
      this.store_properties = json.store_properties;
      this.estimations = json.estimations;
    }
  }

  getId() {
    return this.id;
  }

  setId(id) {
    this.id = id;
  }

  getName() {
    return this.name;
  }

  setName(name) {
    this.name = name;
  }

  getLocation() {
    return this.location;
  }

  setLocation(location) {
    this.location = location;
  }

  getZc() {
    return this.zc;
  }

  setZc(zc) {
    this.zc = zc;
  }

  getStatistics() {
    return this.statistics;
  }

  setStatistics(stats) {
    this.statistics = stats;
  }

  getCompetitors() {
    return this.competitors;
  }

  setCompetitors(competitors) {
    this.competitors = competitors;
  }

  getStoreProperties() {
    return this.store_properties;
  }

  setStoreProperties(storeProperties) {
    this.store_properties = storeProperties;
  }
}
