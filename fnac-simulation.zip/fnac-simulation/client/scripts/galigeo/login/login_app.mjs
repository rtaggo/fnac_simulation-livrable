'use strict';
import { authenticate_user } from '../services/user.mjs';

let redirect_to_url = null;

const setup_listeners = () => {
  $('#login-btn').on('click', () => {
    check_inputs();
  });

  $('#input_user-login').on('input', (e) => {
    let $tgt = $(e.currentTarget);
    const val = $tgt.val().trim();
    hide_errors_help($tgt, val);
  });

  $('#input_user-password').on('input', (e) => {
    let $tgt = $(e.currentTarget);
    const val = $tgt.val().trim();
    hide_errors_help($tgt, val);
  });

  $(document).on('keyup', handle_keyboard_key_pressed);
};

const handle_keyboard_key_pressed = (e) => {
  if (e.key === 'Enter') {
    check_inputs();
    return;
  }
};

const hide_errors_help = ($tgt, val) => {
  if (val !== '') {
    $tgt.parent().parent().removeClass('slds-has-error');
    $tgt.parent().siblings('.slds-form-element__help').addClass('slds-hide');
  }
};

const check_inputs = () => {
  $('#error-notify-content');
  $('#error-notify').addClass('slds-hide');
  $('#login-form .slds-form-element').removeClass('slds-has-error');
  $('#login-form .slds-form-element__help').addClass('slds-slds-hide');
  const user_login = $('#input_user-login').val().trim();
  const user_pwd = $('#input_user-password').val().trim();
  let user_login_ok = true;
  let user_pwd_ok = true;

  if (user_login === '') {
    user_login_ok = false;
    let $elt = $('#error-message-email').text('Merci de renseigner votre login').removeClass('slds-hide');
    $elt.parent().addClass('slds-has-error');
  }

  if (user_pwd === '') {
    user_pwd_ok = false;
    let $elt = $('#error-message-password').text('Merci de renseigner votre mot de passe').removeClass('slds-hide');
    $elt.parent().addClass('slds-has-error');
  }

  if (user_login_ok && user_pwd_ok) {
    do_user_login(user_login, user_pwd);
  }
};

const do_user_login = async (login, password) => {
  //
  try {
    const resp_login = await authenticate_user(login, password);
    if (resp_login.error) {
      let err_details = '';
      let err_messsage = `Erreur de connexion: l'email et le mot de passe ne correspondent pas.`;

      $('#error-notify-content')
        .empty()
        .append($(`<h2>${err_messsage}</h2>${err_details}`))
        .removeClass('slds-hide');
      $('#error-notify').removeClass('slds-hide');
      return;
    }
    if (resp_login.success) {
      const return_to = redirect_to_url || '/';
      window.location.assign(return_to);
    }
  } catch (err_login) {
    $('#error-notify-content').text(`Une erreur de connexion est survenue. Merci de réessayer plus tard.`).removeClass('slds-hide');
    $('#error-notify').removeClass('slds-hide');
  }
};

const run = async () => {
  const redirect_pattern = /(redirect_to=)(.*$)/g;
  const redirect_exec = redirect_pattern.exec(window.location.search);
  if (redirect_exec) {
    redirect_to_url = redirect_exec[2];
  }
  setup_listeners();
};
run();
