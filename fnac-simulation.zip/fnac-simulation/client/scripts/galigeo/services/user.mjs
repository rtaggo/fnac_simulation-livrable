export const authenticate_user = async (login, password) => {
  const req_body = {
    login,
    password,
  };

  try {
    const res_login = await fetch('/rest/user/login', {
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(req_body),
      method: 'POST',
      mode: 'cors',
      credentials: 'include',
    });

    const res_login_json = await res_login.json();
    return res_login_json;
  } catch (err_login) {
    console.error('Failed to login', err_login);
    return { error: true, message: err_login };
  }
};
