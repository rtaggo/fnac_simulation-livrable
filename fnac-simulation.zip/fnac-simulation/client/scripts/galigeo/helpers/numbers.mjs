let numberFormatter = (num) => {
  return num;
};
let intlNumberFormat = null;
if (typeof Intl === 'object' && typeof Intl.NumberFormat === 'function') {
  intlNumberFormat = new Intl.NumberFormat('fr');
  numberFormatter = function (num) {
    return intlNumberFormat.format(num);
  };
}

export const numberFormat = (num) => {
  return numberFormatter(num);
};
