export const alert = (element, msg) => {
  $(element)
    .removeClass('slds-theme_info')
    .addClass('slds-theme_warning')
    .empty()
    .append(
      $(`
    <span class="slds-assistive-text">warning</span>
    <span class="slds-icon_container slds-icon-utility-warning slds-m-right_small slds-no-flex slds-align-top" title="Description of icon when needed">
      <svg class="slds-icon slds-icon_small" aria-hidden="true">
        <use xlink:href="/styles/slds/assets/icons/utility-sprite/svg/symbols.svg#warning"></use>
      </svg>
    </span>
    <div class="slds-notify__content">
      <h2 class="slds-text-heading_small ">${msg}</h2>
    </div>`)
    );
  setTimeout(() => {
    $(element).remove();
  }, 2000);
};
export const toast = (msg, type, duration) => {
  let classTheme = 'slds-theme_info';
  let classIcon = 'slds-icon-utility-info';
  let icon = '/styles/slds//assets/icons/utility-sprite/svg/symbols.svg#info';
  switch (type) {
    case 'success':
      classTheme = 'slds-theme_success';
      classIcon = 'slds-icon-utility-success';
      icon = '/styles/slds//assets/icons/utility-sprite/svg/symbols.svg#success';
      break;
    case 'warning':
      classTheme = 'slds-theme_warning';
      classIcon = 'slds-icon-utility-warning';
      icon = '/styles/slds//assets/icons/utility-sprite/svg/symbols.svg#warning';
      break;
    case 'error':
      classTheme = 'slds-theme_error';
      classIcon = 'slds-icon-utility-error';
      icon = '/styles/slds//assets/icons/utility-sprite/svg/symbols.svg#error';
      break;
  }
  const toast = $(`<div style="position: fixed;" class="slds-notify_container slds-is-relative">
    <div class="slds-notify slds-notify_toast ${classTheme}" role="status">
      <span class="slds-assistive-text"></span>
      <span class="slds-icon_container ${classIcon} slds-m-right_small slds-no-flex slds-align-top" title="Description of icon when needed">
        <svg class="slds-icon slds-icon_small" aria-hidden="true">
          <use xlink:href=" ${icon}"></use>
        </svg>
      </span>
      <div class="slds-notify__content">
        <h2 class="slds-text-heading_small">${msg}</h2>
      </div>
      <div class="slds-notify__close">
      </div>
    </div>
  </div>`);
  const btClose = $(`<button id="toastClose" class="slds-button slds-button_icon slds-button_icon-inverse" title="Fermer">
  <svg class="slds-button__icon slds-button__icon_large" aria-hidden="true">
    <use xlink:href="/styles/slds/assets/icons/utility-sprite/svg/symbols.svg#close"></use>
  </svg>
  <span class="slds-assistive-text">Fermer</span>
</button>`);

  btClose.on('click', () => {
    $('.slds-notify_container').remove();
  });
  toast.find('.slds-notify__close').append(btClose);
  $('#appContainer').append(toast);
  setTimeout(
    () => {
      toast.remove();
    },
    duration ? duration : 2000
  );
};
