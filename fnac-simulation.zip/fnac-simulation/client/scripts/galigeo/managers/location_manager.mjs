import EventBus from '../helpers/eventbus.mjs';
import { LOCATIONCHANGED, LOCATIONUPDATECENTER } from '../constants/events.mjs';

import { is_geolocation_api_available, locate_user, do_search_address, do_reverse_geocode } from '../services/geoservice.mjs';

export default class LocationManager {
  constructor(options = {}) {
    this.options_ = {
      ...{
        addressSelectedCallback: null,
        container: 'location-container',
        addressSearchComboboxId: 'addr-search-combobox',
        addressSearchInputId: 'addr-search-input',
        addressAutoCompleId: 'addr-auto-complete-res',
        locationUserButtonId: 'locate_user_btn',
        checkLocationOnStart: false,
      },
      ...options,
    };

    this.current_location_ = null;
    this.lookupAddressInput_ = null;
    this.lookupAddressInputTimeId_ = null;
    this.lookupAddresInProgress_ = false;
    this.lookupAddressCandidates_ = null;

    this.init_();
    //LocationManager.instance_ = this;
    return this;
  }
  /*
  static getInstance(options = {}) {
    if (LocationManager.instance_) {
      return LocationManager.instance_;
    }
    return new LocationManager(options);
  }
  */

  init_() {
    this.render();
    this.setupListeners_();
  }

  render() {
    let $content = $(`
    <div class="slds-grid" >
      <div class="slds-col">
        <div id="location-form-element" class="slds-form-element location-form">
          <div class="slds-form-element__control">
            <div class="slds-combobox_container">
              <div id="${this.options_.addressSearchComboboxId}" class="slds-combobox slds-dropdown-trigger slds-dropdown-trigger_click" aria-expanded="false" aria-haspopup="listbox" role="combobox">
                <div class="slds-combobox__form-element slds-input-has-icon slds-input-has-icon_left-right" role="none">
                  <svg class="slds-icon slds-input__icon slds-input__icon_left slds-icon-text-default" aria-hidden="true">
                    <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="../../styles/slds/assets/icons/utility-sprite/svg/symbols.svg#search" />
                  </svg>
                  <input class="slds-input slds-combobox__input addr-search-input" id="${this.options_.addressSearchInputId}" aria-autocomplete="list" aria-controls="${this.options_.addressAutoCompleId}" autocomplete="off" role="textbox" type="text" placeholder="Rechercher une adresse" value="" />
                  <button id="${this.options_.locationUserButtonId}" class="slds-button slds-button_icon slds-input__icon slds-input__icon_right locate_user_btn" title="Me localiser">
                    <svg class="slds-button__icon" aria-hidden="true">
                      <use xlink:href="/images/svg/symbols.svg#gps_fixed"></use>
                    </svg>
                    <span class="slds-assistive-text">More options</span>
                  </button>
                </div>
                <div id="${this.options_.addressAutoCompleId}" class="slds-dropdown slds-dropdown_length-with-icon-5 slds-dropdown_fluid" role="listbox">                                         
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="slds-col slds-grow-none slds-hide">
        <button id="${this.options_.locationUserButtonId}2" class="slds-button slds-button_icon slds-button_icon-border slds-button_icon-medium locate_user_btn" title="Me localiser">
          <svg class="slds-button__icon" aria-hidden="true">
            <use xlink:href="/images/svg/symbols.svg#gps_fixed"></use>
          </svg>
          <span class="slds-assistive-text">More options</span>
        </button>
      </div>
    </div>`);
    $(`#${this.options_.container}`).append($content);
    /*
    if (this.options_.checkLocationOnStart) {
      this.validateLocationOnStart();
    }
    */
    if (this.options_.simulationLocked) {
      this.enableSearch(false);
    }
    $(`#${this.options_.addressSearchInputId}`).focus();
  }

  enableSearch(value) {
    $(`#${this.options_.addressSearchInputId}`).attr('disabled', !value);
    $(`#${this.options_.locationUserButtonId}`).attr('disabled', !value);
  }

  setupListeners_() {
    $(`#${this.options_.addressSearchInputId}`).on('input', (e) => {
      this.onSearchAddressInputChanged($(e.currentTarget).val());
    });
    if (is_geolocation_api_available()) {
      $(`#${this.options_.locationUserButtonId}`).on('click', (e) => {
        $(e.currentTarget).blur();
        this.doFindUserLocation();
      });
    } else {
      $(`#${this.options_.locationUserButtonId}`).parent().remove();
    }

    EventBus.addEventListener(LOCATIONUPDATECENTER, (e) => {
      console.log('in location');
      this.current_location_ = { coordinates: { latitude: e.target.lngLat.lat, longitude: e.target.lngLat.lng } }
      this.doReverseGeocode(e.target.lngLat.lat, e.target.lngLat.lng);
    });
  }

  onSearchAddressInputChanged(val) {
    if (val !== this.lookupAddressInput_) {
      this.lookupAddressInput_ = val;
      if (this.lookupAddressInputTimeId_) {
        clearTimeout(this.lookupAddressInputTimeId_);
      }
      this.lookupAddressInputTimeId_ = setTimeout(() => {
        if (this.lookupAddressInput_ !== '' && this.lookupAddressInput_.length > 5) {
          if (!this.lookupAddresInProgress_) {
            this.doSearchAddress(this.lookupAddressInput_);
          }
        }
      }, 500);
    }
  }

  async doSearchAddress(searchText) {
    $(`#${this.options_.addressSearchComboboxId}`).removeClass('slds-is-open');
    //$(`#${this.options_.addressSearchInputId}`).attr('disabled', true);
    this.lookupAddresInProgress_ = true;
    try {
      const search_response = await do_search_address(searchText);
      this.displayAddressCandidates(search_response.ok ? search_response.data.features : []);
    } catch (err) {
      console.error('Failed to search address');
    }
    this.lookupAddresInProgress_ = false;
    //$(`#${this.options_.addressSearchInputId}`).attr('disabled', false);
  }

  displayAddressCandidates(features) {
    let ctnr = $(`#${this.options_.addressAutoCompleId}`).empty();
    $(`#${this.options_.addressSearchComboboxId}`).addClass('slds-is-open');
    if (features.length === 0) {
      ctnr.append($('<div class="slds-m-around_x-small">Aucune correspondance trouvée</div>'));
      this.lookupAddressCandidates_ = null;
      return;
    }
    this.lookupAddressCandidates_ = features;
    let addr_ul = $(`
    <ul class="slds-listbox slds-listbox_vertical" role="presentation">
    ${features
        .map((f) => {
          return `
      <li role="presentation" class="slds-listbox__item" data-itemid="${f.properties.id}">
        <div id="option2" class="slds-media slds-listbox__option slds-listbox__option_plain slds-media_small" role="option">
          <span class="slds-media__figure slds-listbox__option-icon">
            <span class="slds-icon_container slds-current-color">
              <svg class="slds-icon slds-icon_x-small" aria-hidden="true">
                <use xlink:href="/images/svg/symbols.svg#place"></use>
              </svg>
            </span>
          </span>
          <span class="slds-media__body">
            <span class="slds-listbox__option-text slds-listbox__option-text_entity">${f.properties.label}</span>            
          </span>
        </div>
      </li>`;
        })
        .join('')}
    </ul>
    `);
    addr_ul.find('li').on('click', (e) => {
      $(`#${this.options_.addressSearchComboboxId}`).removeClass('slds-is-open');
      const item_id = $(e.currentTarget).data('itemid');
      const addr = this.lookupAddressCandidates_.find((a) => a.properties.id === `${item_id}`);
      if (addr) {
        this.current_location_ = {
          coordinates: { latitude: addr.geometry.coordinates[1], longitude: addr.geometry.coordinates[0] },
          address: addr.properties.label,
        };
        if (typeof this.options_.addressSelectedCallback === 'function') {
          this.options_.addressSelectedCallback(this.current_location_);
        } else {
          EventBus.dispatch(LOCATIONCHANGED, this.current_location_);
        }
      }
    });
    ctnr.append(addr_ul);
  }

  doFindUserLocation() {
    locate_user(
      (result) => {
        this.current_location_ = {
          coordinates: result,
        };
        this.doReverseGeocode(result.latitude, result.longitude);
      },
      (error) => {
        // TODO: handle error
        console.error('Failed to find user location', error);
      }
    );
  }

  doReverseGeocode(lat, lng) {
    do_reverse_geocode(
      lat,
      lng,
      (result) => {
        this.current_location_.address = result.features[0];
        $(`#${this.options_.addressSearchInputId}`).val(this.current_location_.address.properties.label);
        if (typeof this.options_.addressSelectedCallback === 'function') {
          this.options_.addressSelectedCallback({ location: this.current_location_ });
        } else {
          EventBus.dispatch(LOCATIONCHANGED, {
            address: this.current_location_.address.properties.label,
            coordinates: this.current_location_.coordinates
          });
        }
      },
      (error) => {
        console.error('Failed to reverse geocode', error);
        $(`#${this.options_.addressSearchInputId}`).val('');
        if (typeof this.options_.addressSelectedCallback === 'function') {
          this.options_.addressSelectedCallback({ error });
        } else {
          EventBus.dispatch(LOCATIONCHANGED, { error });
        }
      }
    );
  }

  getLookupAddressMeta(feature) {
    const flayer = feature.properties.layer;
    let level = '';
    switch (flayer) {
      case 'address':
        level = 'Adresse';
        break;
      case 'street':
        level = 'Rue';
        break;
      default:
        level = flayer;
    }

    return `Niveau: ${level}`;
  }

  setSimulationLocked(value) {
    this.options_.simulationLocked = value;
  }

  validateLocationOnStart() {
    if (this.options_.simulationLocked) {
      return;
    }
    if (!this.options_.location.address && !this.options_.coordinates) {
      this.showLookupAddressModal();
      return;
    }
    const coords = this.options_.location.coordinates.split(',');
    let addr_label = decodeURI(this.options_.location.address).replaceAll('+', ' ');
    $(`#${this.options_.addressSearchInputId}`).val(addr_label);
    this.current_location_ = {
      address: addr_label,
      coordinates: {
        latitude: +coords[0],
        longitude: +coords[1],
      },
    };
    if (typeof this.options_.addressSelectedCallback === 'function') {
      this.options_.addressSelectedCallback(this.current_location_);
    } else {
      EventBus.dispatch(LOCATIONCHANGED, this.current_location_);
    }
  }

  setLocation(location) {
    this.current_location_ = location;
    $(`#${this.options_.addressSearchInputId}`).val(this.current_location_.address);
  }

  showLookupAddressModal() {
    let $modal = $(`
    <section id="modal-locator" role="dialog" tabindex="-1" aria-labelledby="modal-locator-heading" aria-modal="true" aria-describedby="modal-locator-content" class="slds-modal slds-fade-in-open">
      <div class="slds-modal__container">
        <header class="slds-modal__header slds-p-around_small">
          <h2 id="modal-locator-heading" class="slds-modal__title slds-hyphenate">Localisation de l'étude</h2>
          <p class="slds-m-top_x-small">Veuillez définir la localisation de l'étude</p>
        </header>
        <div class="slds-modal__content slds-p-around_medium" id="modal-locator-content" style="min-height:300px;">
          <div id="modal-search-box-container" class="slds-align_absolute-center search-box-container slds-grid slds-p-around_medium">
            <div id="modal-location-container" class="slds-p-around_medium" style="width: 100%;border: 1px solid #dddbda;border-radius: 40px;">
            </div>
          </div>
        </div>
      </div>
    </section>
    <div class="slds-backdrop slds-backdrop_open"></div>`);

    $('#appContainer').append($modal);
    const modal_locator_callback = (result) => {
      $('#modal-locator').remove();
      $('.slds-backdrop').remove();
      this.current_location_ = result.location;
      delete this.modalLocator_;
      $(`#${this.options_.addressSearchInputId}`).val(this.current_location_.address.properties.label);
      if (typeof this.options_.addressSelectedCallback === 'function') {
        this.options_.addressSelectedCallback({ location: this.current_location_ });
      } else {
        EventBus.dispatch(LOCATIONCHANGED, { location: this.current_location_ });
      }
    };
    this.modalLocator_ = new LocationManager({
      container: 'modal-location-container',
      addressSelectedCallback: modal_locator_callback.bind(this),
      addressSearchComboboxId: 'modal-addr-search-combobox',
      addressSearchInputId: 'modal-addr-search-input',
      addressAutoCompleId: 'modal-addr-auto-complete-res',
      locationUserButtonId: 'modal-locate_user_btn',
    });
  }

  removeLookupAddressModal() {
    $('#modal-locator').remove();
    $('.slds-backdrop').remove();
  }

  cleanAll() {
    this.current_location_ = null;
    $(`#${this.options_.addressSearchInputId}`).val('').focus();
  }
}
