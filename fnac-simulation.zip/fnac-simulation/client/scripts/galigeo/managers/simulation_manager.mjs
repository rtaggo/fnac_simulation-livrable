import {
  PROJECTLOADED,
  LOCATIONUPDATECENTER,
  LOCATIONCHANGED,
  ISOCHRONECOMPUTED,
  ISOCHRONEVALIDATED,
  MAPISLOADED,
  AREASTATSCOMPUTED,
  STATSDETAILSVISIBILITY,
  COMPETITORSCOMPUTED,
  SIMULATIONLAUCHED,
  SIMULATIONDONE,
  REFRESHCOMPETITORS,
  FLYTOCOORDINATES,
  TABTOSHOWCHANGE,
  ADDCOMPETITOR,
} from '../constants/events.mjs';
import EventBus from '../helpers/eventbus.mjs';
import { get_all_url_parameters } from '../helpers/urls.mjs';
import { modal_confirm, modal_input } from '../helpers/modal.mjs';
import Simulation from '../model/simulation.mjs';
import ZonesChalandises from '../model/zones_chalandises.mjs';
import Competitors from '../model/zones_chalandises.mjs';
import { get_demography, get_competitors } from '../services/dataservice.mjs';
import { get_simulation, save_simulation, run_simulation } from '../services/simulations.mjs';
import { alert } from '../helpers/messages.mjs';
import { do_reverse_geocode } from '../services/geoservice.mjs';

export default class SimulationManager {
  constructor(options = {}) {
    /*SimulationManager.PANEL_ZONES = 'zones';
        SimulationManager.PANEL_DEMO = 'demo';
        SimulationManager.PANEL_CONCURRENTS = 'concurrents';
        SimulationManager.PANEL_SIMULATION = 'simulation';*/

    this.options_ = options;
    SimulationManager.instance_ = this;
    this.mapManager = options.mapManager;

    //this.currentPanel = SimulationManager.PANEL_ZONES;

    this.setupListeners_();
  }

  static getInstance(options = {}) {
    if (SimulationManager.instance_) {
      return SimulationManager.instance_;
    }
    return new SimulationManager(options);
  }

  setupListeners_() {
    EventBus.addEventListener(MAPISLOADED, (e) => {
      this.map_ = e.target.map;
    });

    EventBus.addEventListener(PROJECTLOADED, (e) => {
      this.project = e.target;
    });

    EventBus.addEventListener(ISOCHRONECOMPUTED, (e) => {
      this.simulation.setZc(e.target);
      this.addIsochroneSourceAndLayer(this.simulation.getZc());
      this.addStoreMarker(this.simulation.getLocation());
    });

    EventBus.addEventListener(LOCATIONCHANGED, (e) => {
      this.simulation.setLocation(e.target);
      this.addStoreMarker(this.simulation.getLocation());
    });

    EventBus.addEventListener(SIMULATIONLAUCHED, (e) => {
      this.simulation.setStoreProperties(e.target);

      // start by saving the project
      this.saveProject({ run_simulation: true });

      // run the simulation
      /*
      need to wait for response of save to get the id. 
      code move to saveProject method      
      */
      /* 
      const simulationId = this.simulation.id;
      run_simulation(this.simulation, () => {
        get_simulation(simulationId).then((project) => {
          project.id = simulationId;
          EventBus.dispatch(SIMULATIONDONE, project);
        });
      });
      */
    });

    EventBus.addEventListener(ISOCHRONEVALIDATED, (e) => {
      modal_confirm(
        "Attention, la modification de la zone d'étude réinitialise la liste des concurrents liés à cette étude. Etes-vous sûr de vouloir continuer ?",
        () => {
          this.simulation.setZc(e.target);
          this.closeIsoPanel();
          this.extractStatistics();
          $('#statistics-container').addClass('slds-show');
          $('#statistics-container').removeClass('slds-hide');
        },
        this.simulation.id !== undefined
      );
    });

    EventBus.addEventListener(STATSDETAILSVISIBILITY, (e) => {
      const { is_visible } = e.target;
      if (is_visible) {
        $('#main-card-app').addClass('slds-hide');
      } else {
        $('#main-card-app').removeClass('slds-hide');
      }
    });
    EventBus.addEventListener(FLYTOCOORDINATES, (e) => {
      this.mapManager.flyTo(e.target, 17);
    });
    EventBus.addEventListener(REFRESHCOMPETITORS, (e) => {
      this.displayCompetitorsOnMap(this.simulation.competitors);
    });
    EventBus.addEventListener(TABTOSHOWCHANGE, (e) => {
      if (e.target === 'competitors-container') {
        this.mapManager.startListenClickOnMap((em) => {
          this.mapManager.stopListenClickOnMapMomentary(3000);
          do_reverse_geocode(
            em.lngLat.lat,
            em.lngLat.lng,
            (result) => {
              console.log(result);
              EventBus.dispatch(ADDCOMPETITOR, {
                lngLat: this.simulation.location.coordinates,
                geocodeResult: result,
                callback: (competitorFeature) => {
                  console.log(competitorFeature);
                  this.simulation.competitors.features.push(competitorFeature);
                  EventBus.dispatch(COMPETITORSCOMPUTED, this.simulation.competitors);
                  this.displayCompetitorsOnMap(this.simulation.competitors);
                },
              });
            },
            (error) => {
              console.log(error);
            }
          );
        });
      } else {
        this.mapManager.stopListenClickOnMap();
      }
    });

    $('#main-card-app .slds-tabs_default__item').click((e) => {
      e.preventDefault();
      let c_target = $(e.currentTarget);
      let ariaCtrl = c_target.find('a').attr('aria-controls');
      let contentToShow = $('#' + ariaCtrl);

      c_target.addClass('slds-is-active').blur();
      c_target.find('a').attr('aria-selected', true).attr('tabindex', 0);
      contentToShow.removeClass('slds-hide').addClass('slds-show');
      c_target.siblings().removeClass('slds-is-active');
      c_target.siblings().find('a').attr('aria-selected', false).attr('tabindex', -1);
      contentToShow.siblings('.slds-tabs_default__content').removeClass('slds-show').addClass('slds-hide');
      EventBus.dispatch(TABTOSHOWCHANGE, ariaCtrl);
    });

    $('#simulation-label').on('click', (e) => {
      e.stopPropagation();
      modal_input('Nom du projet', this.simulation.name, (newName) => {
        this.simulation.setName(newName);
        $('#simulation-label').html(this.simulation.getName());
      });
    });
  }

  render() {
    console.log('Render simulation manager');

    this.setupNavigation();
  }

  extractStatistics() {
    get_demography(this.simulation.getZc()).then((demography) => {
      this.simulation.setStatistics(demography);
      EventBus.dispatch(AREASTATSCOMPUTED, demography);
    });
    get_competitors(this.simulation.getZc()).then((competitors) => {
      this.simulation.setCompetitors(competitors);
      this.displayCompetitorsOnMap(competitors);
      EventBus.dispatch(COMPETITORSCOMPUTED, competitors);
    });
  }

  setupNavigation() {
    $('#back_to_start').on('click', () => {
      if (!$('#zones-tab').hasClass('slds-hide')) {
        this.closeIsoPanel();
      } else {
        window.location.href = './';
      }
    });
    $('#current-simulation-infos').on('click', () => {
      this.showIsoPanel();
    });
  }

  showIsoPanel() {
    $('#zones-tab').removeClass('slds-hide');
    $('#analysis_tab').addClass('slds-hide');
    this.mapManager.startListenClickOnMap((e) => {
      modal_confirm(
        'Voulez-vous définir ce point comme centre de la zone ?',
        () => {
          EventBus.dispatch(LOCATIONUPDATECENTER, e);
        },
        this.simulation.location !== undefined
      );
    });
  }

  closeIsoPanel() {
    if (!this.simulation.getName()) {
      var address = this.simulation.getLocation().address;
      this.simulation.setName(address + ' ' + new Date().toLocaleDateString());
    }
    $('#simulation-label').html(this.simulation.getName());
    $('#zones-info-badge').html(this.simulation.getZc().getTiledInformation());
    $('#zones-tab').addClass('slds-hide');
    $('#analysis_tab').removeClass('slds-hide');

    this.mapManager.stopListenClickOnMap();
  }

  loadSimulation() {
    var simulationId = get_all_url_parameters()['id'];
    if (simulationId) {
      $('#zones-tab').addClass('slds-hide');
      get_simulation(simulationId).then((project) => {
        if (!project.id) {
          alert('appContainer', 'Impossible de charger le projet');
          return;
        }

        this.simulation = project;
        EventBus.dispatch(PROJECTLOADED, this.simulation);

        // directly open the stat tab
        $('#main-card-app').removeClass('slds-hide');
        $('#analysis_tab').removeClass('slds-hide');
        $('#statistics-container').removeClass('slds-hide');
        $('#simulation-label').html(this.simulation.getName());
        this.addIsochroneSourceAndLayer(this.simulation.getZc());
        this.displayCompetitorsOnMap(this.simulation.competitors);
        this.addStoreMarker(this.simulation.getLocation());
        $('#zones-info-badge').html(this.simulation.getZc().getTiledInformation());
      });
    } else {
      // no ID specified, build an empty project
      this.simulation = new Simulation();
      this.simulation.setZc(new ZonesChalandises());
      $('#main-card-app').removeClass('slds-hide');
      this.showIsoPanel();
      //this.simulation.setName('Simu ' + new Date().toLocaleDateString() + ' ' + new Date().toLocaleTimeString());
      EventBus.dispatch(PROJECTLOADED, this.simulation);
    }
  }

  saveProject(options = {}) {
    const saveSimu = new Simulation(JSON.parse(JSON.stringify(this.simulation)));

    saveSimu.competitors = this.simulation.competitors.features.map((c) => {
      if (c.properties.fnac_id < 0) {
        return { ...{ fnac_long: c.geometry.coordinates[0], fnac_lat: c.geometry.coordinates[1] }, ...c.properties };
      }
      return { fnac_id: c.properties.fnac_id, selected: c.properties.selected, dist_meter: c.properties.dist_meter };
    });
    /*
    this.simulation.competitors.features.forEach((feature) => {
      saveSimu.competitors.features.push({ fnac_id: feature.properties.fnac_id, selected: true });
    });
    */

    save_simulation(saveSimu).then((result) => {
      console.log('Project saved', result);
      this.simulation.id = result.data.id;
      if (options.run_simulation) {
        const simulationId = this.simulation.id;
        run_simulation(this.simulation, () => {
          get_simulation(simulationId).then((project) => {
            project.id = simulationId;
            EventBus.dispatch(SIMULATIONDONE, project);
          });
        });
      }
    });
  }

  setZones(zones = {}) {
    debugger;
    this.zoneMgr.setZc(zones);
    this.map_.addLayer({
      id: 'drivetime_layer',
      type: 'fill-extrusion',
      source: 'drivetime',
      paint: {
        'fill-extrusion-color': ['get', 'color'],
        'fill-extrusion-opacity': 0.7,
        'fill-extrusion-base': 0,
        'fill-extrusion-height': ['*', 20, ['-', 3, ['get', 'bucket']]],
      },
    });
  }

  setManagersData(zones = {}) {
    this.zoneMgr.setZC(this.simulation.getZonesChalandises());
    const location_data = this.simulation.getLocation().toJSON();
    if (location_data.address && location_data.coordinates) {
      try {
        this.options_.getLocationManager().setLocation(location_data);
        this.options_.getMapManager().setCurrentLocation(location_data.coordinates, { flyTo: true });
      } catch (err) {
        console.error('Failed to location on LocationManager');
      }
      this.zoneMgr.setLocation(location_data.coordinates, zones);
      this.options_.getStatsManager().render();
    }
    //this.zoneMgr.render();
    this.zoneMgr.activate();
  }

  addStoreMarker(location) {
    this.mapManager.addPoint(location.coordinates, 'store', 'store', '/images/fnac_icon.png', location.address);
  }

  addIsochroneSourceAndLayer(zones) {
    if (typeof this.map_.getSource('drivetime') === 'undefined') {
      this.map_.addSource('drivetime', { type: 'geojson', data: zones.toGeoJSON() });
      this.addIsochroneToMap();
    } else {
      this.map_.getSource('drivetime').setData(zones.toGeoJSON());
    }
    let bbox = turf.bbox(zones.toGeoJSON());
    this.map_.fitBounds(bbox, { padding: 20 });
  }

  displayCompetitorsOnMap(competitors) {
    // set the description on each competitor
    competitors.features.forEach((feature) => {
      feature.properties._label = feature.properties.fnac_libens;
    });
    const options = {
      filter: ['==', 'selected', true],
      addTooltip: true,
    };
    this.mapManager.addPointLayer(competitors, 'competitors', 'logo', '/images/target-marker.png', options);
  }

  addIsochroneToMap() {
    /*
        this.map_.addLayer(
          {
            id: 'drivetime_layer',
            type: 'fill',
            source: 'drivetime',
            paint: {
              'fill-color': ['get', 'color'],
              'fill-opacity': 0.7,
              'fill-outline-color': '#ABABAB',
            },
          },
          this.firstSymbolId
        );
        */
    this.map_.addLayer({
      id: 'drivetime_layer',
      type: 'fill-extrusion',
      source: 'drivetime',
      paint: {
        'fill-extrusion-color': ['get', 'color'],
        'fill-extrusion-opacity': 0.7,
        'fill-extrusion-base': 0,
        'fill-extrusion-height': ['*', 20, ['-', 3, ['get', 'bucket']]],
      },
    });
  }
}
