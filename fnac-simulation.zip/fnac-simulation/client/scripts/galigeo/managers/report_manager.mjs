import EventBus from '../helpers/eventbus.mjs';
import { SIMULATIONLAUCHED, SIMULATIONDONE, PROJECTLOADED } from '../constants/events.mjs';

import { combo_box } from '../helpers/combobox.mjs';
import { numberFormat } from '../helpers/numbers.mjs';

export default class ReportManager {
  constructor(options = {}) {
    this.options_ = {
      ...{
        container: 'simulation-container',
      },
      ...options,
    };
    ReportManager.instance_ = this;
    this._currentProgress = 0;
    this._intervalId;
  }

  static getInstance(options = {}) {
    if (ReportManager.instance_) {
      return ReportManager.instance_;
    }
    return new ReportManager(options);
  }

  render() {
    const $content = `
        <div class="slds-box">
          <div class="slds-form">
            <div class="slds-form-element slds-form-element_horizontal">
              <label class="slds-form-element__label" for="surface-input">Surface</label>
                <div class="slds-form-element__control">
                  <input type="text" id="surface-input" placeholder="Surface" class="slds-input" />
                </div>
            </div>
            <div class="slds-form-element slds-form-element_horizontal">
              <label class="slds-form-element__label" for="horizontal-input-id-01">Type de magasin</label>
                <div id="store-type-combobox" class="slds-form-element__control">                  
                </div>
            </div>
          </div>
        </div>
        <div class="slds-p-top_medium slds-align_absolute-center">
          <button id="save-simulation-btn" class="slds-button slds-button_neutral" style="width: 100%">
            <svg class="slds-button__icon slds-button__icon_left" aria-hidden="true">
              <use xlink:href="/styles/slds/assets/icons/utility-sprite/svg/symbols.svg#light_bulb"></use>
            </svg>Lancer la simulation
          </button>
        </div>
        <div id="simulation-progress" class="slds-p-top_medium slds-align_absolute-center slds-hide">
          <div class="slds-progress-bar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="25" aria-label="{{Placeholder for description of progress bar}}" role="progressbar">
            <span class="slds-progress-bar__value" style="width:0%">
            <span class="slds-assistive-text">Progress: 25%</span>
          </span>
          </div>
        </div>
        <div id="report-result-container" class="slds-align_absolute-center slds-p-top_medium slds-hide">
          <div class="slds-grid slds-gutters slds-wrap">
            <div class="stat_tile slds-col slds-size_1-of-1 slds-p-vertical_small" style="">
              <div class="slds-box slds-box_small" style="text-align: center;background-color: #cfd1ef">
                <div id="estimation_ca" style="font-size: 24px;line-height: 24px;color: grey;">60 %</div>
                <div>Part de marché</div>
              </div>
            </div>
            <div class="stat_tile slds-col slds-size_1-of-1 slds-p-vertical_small" style="">
              <div class="slds-box slds-box_small" style="text-align: center;background-color: #c7bf85">
                <div id="estimation_perte_ca" style="font-size: 24px;line-height: 24px;color: grey;">6 000 000</div>
                  <div>Chiffre d'affaire</div>
                </div>
              </div>
            </div>
          </div>
        </div>
        `;

    $('#' + this.options_.container).html($content);
    combo_box('store-type-combobox', ['Centre commercial', 'Zone artisanale', 'Centre ville'], 'Centre ville');

    $('#save-simulation-btn').on('click', (e) => {
      const store_properties = {
        surface: $('#surface-input').val(),
        type: $('#store-type-combobox-value').html(),
      };
      EventBus.dispatch(SIMULATIONLAUCHED, store_properties);
      $('#simulation-progress').removeClass('slds-hide');

      const incrementProgress = () => {
        if (this._currentProgress > 95) this._currentProgress += 0;
        else if (this._currentProgress > 90) this._currentProgress += 1;
        else if (this._currentProgress > 80) this._currentProgress += 2;
        else this._currentProgress += 10;
        $('#simulation-progress')
          .find('.slds-progress-bar__value')
          .css('width', this._currentProgress + '%');
      };

      this._currentProgress = 0;
      this._intervalId = setInterval(incrementProgress, 1500);
    });

    EventBus.addEventListener(SIMULATIONDONE, (e) => {
      $('#report-result-container').removeClass('slds-hide');
      $('#simulation-progress').addClass('slds-hide');
      clearInterval(this._intervalId);
      const estimations = e.target.estimations;
      $('#estimation_ca').html(numberFormat(estimations.estimation_ca));
      $('#estimation_perte_ca').html(numberFormat(estimations.estimation_perte_ca));
    });
  }
}
