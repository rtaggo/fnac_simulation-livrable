import EventBus from '../helpers/eventbus.mjs';
import { ADDCOMPETITOR, COMPETITORSCOMPUTED, PROJECTLOADED, REFRESHCOMPETITORS, FLYTOCOORDINATES } from '../constants/events.mjs';
import { toast } from '../helpers/messages.mjs';
export default class CompetitorManager {
  constructor(options = {}) {
    this.options_ = {
      ...{
        container: 'competitors-container',
      },
      ...options,
    };

    this.setupListeners();
  }

  static getInstance(options = {}) {
    if (CompetitorManager.instance_) {
      return CompetitorManager.instance_;
    }
    return new CompetitorManager(options);
  }

  setupListeners() {
    EventBus.addEventListener(PROJECTLOADED, (e) => {
      if (e.target.competitors) {
        this.displayCompetitors(e.target.competitors);
        this.competitors = e.target.competitors;
      }
    });

    EventBus.addEventListener(COMPETITORSCOMPUTED, (e) => {
      this.displayCompetitors(e.target);
      this.competitors = e.target;
    });
    EventBus.addEventListener(ADDCOMPETITOR, (e) => {
      this.openModalAdd(e.target.lngLat, e.target.geocodeResult, e.target.callback);
    });
  }

  /*render() {
      const $content = $(`
      <div class="slds-text-title_caps">List des concurrents</div>
        <div id="competitors-resume-content" class="slds-grid slds-grid_vertical stats-resume-content"><div class="slds-col slds-size_1-of-1 slds-p-around_xx-small">            
        </div>
      </div>
      `);
      $('#' + this.options_.container).empty().append($content);
  }*/

  render() {
    const $content = $(`
    <div class="slds-grid slds-wrap">
      <div class="slds-text-title_caps slds-col slds-size_1-of-2">Liste des concurrents</div>
        <div class="help-add-competitors slds-col slds-size_1-of-2">
        </div>
    </div>
    <div id="competitors-resume-content" class="slds-scrollable_y" style="height:calc(100vh - 10rem)">            
    </div>
    `);
    const $btnAdd =
      $(`<button style="margin-top: -10px; margin-right: 13px;" class="slds-float_right slds-button slds-button_icon slds-button slds-button_icon" aria-describedby="help" aria-disabled="true" title="Cliquez sur la carte pour ajouter un concurrent">
      <svg class="slds-button__icon" aria-hidden="true">
        <use xlink:href="/styles/slds/assets/icons/utility-sprite/svg/symbols.svg#add"></use>
      </svg>
      <span class="slds-assistive-text">Cliquez sur la carte pour ajouter un concurrent</span>
    </button>
    `);
    $btnAdd.on('mouseenter', () => {
      $content.find('.help-add-competitors')
        .append(`<div class="slds-popover slds-popover_tooltip slds-nubbin_bottom-right" role="tooltip" id="help" style="position:absolute;top:-55px;left:208px">
      <div class="slds-popover__body">Cliquez sur la carte pour ajouter un concurrent</div>
    </div>`);
    });
    $btnAdd.on('mouseout', () => {
      $content.find('.slds-popover_tooltip').remove();
    });
    $content.find('.help-add-competitors').append($btnAdd);
    $('#' + this.options_.container)
      .empty()
      .append($content);
  }

  displayCompetitors(competitors) {
    console.log('Display competitores', competitors);
    competitors.features.sort((c1, c2) => {
      const d1 = c1.properties.dist_meter;
      const d2 = c2.properties.dist_meter;
      if (d1 > d2) return 1;
      else return -1;
    });
    $('#competitors-resume-content').empty();
    competitors.features.forEach((feature) => {
      const competitorBox = this.getCompetitor(feature.properties);
      $('#competitors-resume-content').append(competitorBox);
    });
  }

  getCompetitor(properties) {
    const checkboxCompetitor = $(`<input type="checkbox" name="options" id="checkboxCompetitor-${properties.fnac_id}" value="${properties.fnac_id}" checked="" />`);
    const competitorBox = $(`
    <div class="slds-box slds-box_x-small">
      <div class="slds-grid slds-wrap">
        <div class="slds-form-element slds-col slds-size_1-of-2">
          <div class="slds-form-element__control">
            <div class="slds-checkbox">
            </div>
          </div>
        </div>
      </div>
    </div>`);
    const dist_meter = properties?.dist_meter ?? 0;
    const dist = dist_meter < 1000 ? dist_meter.toFixed(1) + ' m' : (dist_meter / 1000).toFixed(2) + ' km';

    const zoomToCompetitor = $(`<a href="#" id="${properties.fnac_id}" class="slds-col slds-size_1-of-2">${properties.fnac_category + ' ' + dist}</a>`);
    zoomToCompetitor.on('click', (e) => {
      // creation d'un closure sur l'élément zoomToCompetitor
      const id = $(e.currentTarget).attr('id');
      if (id) {
        const feature = this.competitors.features.find((f) => f.properties.fnac_id + '' === id + '');
        if (feature) {
          EventBus.dispatch(FLYTOCOORDINATES, { longitude: feature.geometry.coordinates[0], latitude: feature.geometry.coordinates[1] });
        }
      }
    });
    /*
    Idem que précédemment
    */
    checkboxCompetitor.on('click', (e) => {
      const id = $(e.currentTarget).val();
      if (id) {
        const feature = this.competitors.features.find((f) => f.properties.fnac_id + '' === id + '');
        if (feature) {
          feature.properties.selected = $(e.currentTarget).is(':checked');
          EventBus.dispatch(REFRESHCOMPETITORS, feature);
        }
      }
    });
    competitorBox.find('.slds-grid').append(zoomToCompetitor);
    competitorBox.find('.slds-checkbox').append(checkboxCompetitor);
    competitorBox.find('.slds-checkbox').append(`<label class="slds-checkbox__label" for="checkboxCompetitor-${properties.fnac_id}">
    <span class="slds-checkbox_faux"></span>
    <span class="slds-form-element__label">${properties.fnac_libens}</span>
  </label>`);
    return competitorBox;
  }

  /*getCompetitorHtml(properties) {
      return `
      <div class="slds-col slds-size_1-of-1 slds-p-around_xx-small">
          <article class="slds-card slds-card_boundary" style="cursor:pointer;height: 2.0rem;" data-fieldid="population">
            <div class="slds-card__body slds-card__body_inner slds-m-vertical_xxx-small" style="height:100%;">
              <div class="slds-grid slds-grid_vertical-align-center" style="height:100%;">
                <div class="slds-col slds-grow-none">
                  <span class="slds-icon_container">
                    <svg class="slds-icon slds-icon_medium slds-icon-text-default" aria-hidden="true">
                      <use xlink:href="/styles/slds/assets/icons/standard-sprite/svg/symbols.svg#swarm_request"></use>
                    </svg>
                  </span>
                </div>
                <div class="slds-col slds-m-left_small">
                  <div class="slds-text-heading_small slds-p-bottom_x-small">${properties.fnac_libens}</div>
                </div>
              </div>
          </div></article>
        </div>
      `;
  }*/

  getGGOId_old() {
    let maxGGO = 0;
    this.competitors.features.forEach((f) => {
      if ((f.properties.fnac_id + '').startsWith('ggo_')) {
        if (Number(f.properties.fnac_id.split('-')[1]) > maxGGO) {
          maxGGO = Number(f.properties.fnac_id.split('-')[1]);
        }
      }
    });
    return maxGGO + 1;
  }

  getGGOId() {
    return Math.min(...this.competitors.features.filter((f) => f.properties.fnac_id < 0).map((f) => f.properties.fnac_id), 0) - 1;
  }

  openModalAdd(latLng, geocodeResult, callback) {
    // add adress in the modal
    const adress = geocodeResult && geocodeResult.features && geocodeResult.features[0] ? geocodeResult.features[0].properties.label : '';
    const $content = $(`
    <section role="dialog" tabindex="-1" aria-labelledby="modal-heading-01" aria-modal="true" aria-describedby="modal-content-id-1" class="slds-modal slds-fade-in-open">
      <div class="slds-modal__container">
        <header class="slds-modal__header">
            Ajout d'un concurrent
        </header>
        <div class="slds-modal__content slds-p-around_medium" id="modal-content-id-1">
          <div class="slds-form">
          <div class="slds-form-element slds-form-element_horizontal">
              <label class="slds-form-element__label" for="name_shop">Adresse</label>
              <div class="slds-form-element__control">
              <div class="slds-form-element__static">${adress}</div>
              </div>
            </div>
            <div class="slds-form-element slds-form-element_horizontal">
              <label class="slds-form-element__label" for="name_shop">Libellé d'enseigne</label>
              <div class="slds-form-element__control">
                <input type="text" id="name_shop" placeholder="FNAC ..." class="slds-input" />
              </div>
            </div>
            <div class="slds-form-element slds-form-element_horizontal">
              <label class="slds-form-element__label" for="surface_competitor">Surface en m²</label>
              <div class="slds-form-element__control">
                <input type="number" id="surface_competitor" placeholder="400" class="slds-input" />
              </div>
            </div>
            <div class="slds-form-element slds-form-element_horizontal">
              <label class="slds-form-element__label" for="select-competitor-categ">Catégorie</label>
              <div class="slds-form-element__control">
              <div class="slds-select_container">
              <select class="slds-select" id="select-competitor-categ" required="">
                <option value="">Choisir une catégorie</option>
                <option value="Librairie">Librairie</option>
                <option value="Electrodomestique">Electrodomestique</option>
                <option value="Culture Loisirs">Culture Loisirs</option>
                <option value="Jouets">Jouets</option>
                <option value="Hypermarché">Hypermarché</option>
              </select>
            </div>
              </div>
            </div>
            
          </div>
        </div>
        <footer class="slds-modal__footer">
          <button id="model_cancel" class="slds-button slds-button_neutral">Annuler</button>
          <button id="modal_confirm_add_competitor" class="slds-button slds-button_brand">Ajouter</button>
        </footer>
      </div>
    </section>
    <div class="slds-backdrop slds-backdrop_open"></div>
    `);

    $('body').append($content);

    $('#model_cancel').on('click', () => {
      $content.remove();
    });
    $('#modal_confirm_add_competitor').on('click', () => {
      if ($('#name_shop').val().length > 0 && $('#surface_competitor').val().length > 0 && $('#select-competitor-categ').val().length > 0) {
        /*
        const props =
          geocodeResult && geocodeResult.features && geocodeResult.features[0] && geocodeResult.features[0].properties ? geocodeResult.features[0].properties : undefined;
          */
        const g_feature = geocodeResult?.features?.[0];
        const props = g_feature.properties;
        const feature = {
          type: 'Feature',
          geometry: g_feature.geometry,
          properties: {
            dist_meter: turf.distance(turf.point([latLng.longitude, latLng.latitude]), turf.point(g_feature.geometry.coordinates)) * 1000,
            fnac_adr: props?.name ?? null,
            fnac_caht_conc: null,
            fnac_category: $('#select-competitor-categ').val(),
            fnac_code_geo: null,
            fnac_contrat: null,
            fnac_cp: props?.postalcode ?? null,
            fnac_datecrea: null,
            fnac_id: this.getGGOId(),
            fnac_idens: null,
            fnac_lib_mag: $('#name_shop').val(),
            fnac_libens: $('#name_shop').val(),
            fnac_niveau: 'IRIS',
            fnac_niveauconc: 2,
            fnac_pays: 'FRA',
            fnac_periode_ca: null,
            fnac_surfventec: +$('#surface_competitor').val(),
            fnac_topconc: null,
            fnac_ville: props?.locality ?? null,
            fnac_visible: 't',
            selected: true,
          },
        };
        callback(feature);
        $content.remove();
      } else {
        toast('Tous les champs sont obligatoires', 'error', 4000);
      }
    });
  }
}
