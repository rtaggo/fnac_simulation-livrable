export const MAPISLOADED = 'mapisloaded';
export const PROJECTLOADED = 'projectloaded';
export const LOCATIONUPDATECENTER = 'locationupdatecenter';
export const LOCATIONCHANGED = 'locationchanged';
export const AUTHENTICATEDUSER = 'authenticateduser';
export const USERLOGGEDIN = 'userloggedin';
export const ISOCHRONECOMPUTED = 'isochronecomputed';
export const ISOCHRONEVALIDATED = 'isochronevalidated';
export const AREASTATSCOMPUTED = 'areastatscomputed';
export const STATSDETAILSVISIBILITY = 'statsdetailsvisibility';
export const COMPETITORSCOMPUTED = 'competitorscomputed';
export const COMPETITORDELETED = 'competitordeleted';
export const MAPISMOVEND = 'mapismovend';
export const SIMULATIONLAUCHED = 'simulationlaunched';
export const SIMULATIONDONE = 'simulationdone';
export const REFRESHCOMPETITORS = 'refreshcompetitors';
export const FLYTOCOORDINATES = 'flytocoordinates';
export const TABTOSHOWCHANGE = 'tabtoshowchange';
export const ADDCOMPETITOR = 'addcompetitor';


