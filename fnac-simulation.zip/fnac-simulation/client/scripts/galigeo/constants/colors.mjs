/*
export const color_buckets = ['#0FA3B1', '#8CB557', '#C33C54'];
*/
const RED = '#d53e4f';
const GREEN = '#abdda4';
const BLUE = '#3288bd';

export const color_buckets = ['#2ca25f', '#99d8c9', '#e5f5f9'];

export const spectral_color_palette = ['#9e0142', '#d53e4f', '#f46d43', '#fdae61', '#fee08b', '#ffffbf', '#e6f598', '#abdda4', '#66c2a5', '#3288bd', '#5e4fa2'];

export const qualitative_set3 = ['#8dd3c7', '#ffffb3', '#bebada', '#fb8072', '#80b1d3', '#fdb462', '#b3de69', '#fccde5', '#d9d9d9', '#bc80bd', '#ccebc5'];
