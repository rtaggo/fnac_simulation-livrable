'use strict';

const express = require('express');
const router = express.Router();

router.get('/', (req, res) => {
  res.header('Content-Type', 'application/json');
  const { MAPBOX_API_KEY } = process.env;

  res.json({ mapbox_api_key: MAPBOX_API_KEY });
});

/**
 * Errors on "/config/*" routes.
 */
router.use((err, req, res, next) => {
  // Format error and forward to generic error handler for logging and
  // responding to the request
  err.response = err.message;
  next(err);
});

module.exports = router;
