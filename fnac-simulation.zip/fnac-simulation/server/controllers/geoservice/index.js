'use strict';

const express = require('express');
const router = express.Router();

router.get('/', (req, res) => {
  res.header('Content-Type', 'application/json');
  res.json({ message: '[GET] /rest/geoservice', api: 'alive!!!' });
});

router.get('/geocode/search', (req, res) => {
  res.header('Content-Type', 'application/json');
  //const { geocode_search } = require('../../services/geoservice/here');
  const { GEOCODER = 'galigeo' } = process.env;
  const { geocode_search } = require(`../../services/geoservice/${GEOCODER}`);
  const { q } = req.query;
  geocode_search(q)
    .then((result) => {
      res.json(result);
    })
    .catch((err) => {
      console.error('Failed to geocode');
      console.error(err);
    });
});

router.get('/geocode/reverse', (req, res) => {
  res.header('Content-Type', 'application/json');
  const { reverse_geocode } = require('../../services/geoservice');
  const lat = req.query.lat;
  const lng = req.query.lng;
  reverse_geocode({ lat, lng })
    .then((result) => {
      res.json(result);
    })
    .catch((err) => {
      console.error('Failed to reverse geocode');
      console.error(err);
    });
});

router.get('/direction/isochrone', (req, res) => {
  res.header('Content-Type', 'application/json');
  const { compute_isochrone } = require('../../services/geoservice');
  const { lat, lng, time_limits, profile } = req.query;
  compute_isochrone(lat, lng, time_limits, profile).then((result) => {
    res.json(result);
  });
});

/**
 * Errors on "/geoservice/*" routes.
 */
router.use((err, req, res, next) => {
  // Format error and forward to generic error handler for logging and
  // responding to the request
  err.response = err.message;
  next(err);
});

module.exports = router;
