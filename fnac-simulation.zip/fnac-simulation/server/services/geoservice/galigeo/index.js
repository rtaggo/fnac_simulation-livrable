const axios = require('axios');

const rest_api_url = process.env.GGO_REST_API_URL;

exports.geocode_search = async (search_term) => {
  const geocode_url = `${rest_api_url}/api/geoservice/geocode/search?q=${encodeURI(search_term)}`;
  const geocode_url_res = await axios(geocode_url);
  return geocode_url_res.data;
};

exports.reverse_geocode = async ({ lat, lng }) => {
  const reverse_url = `${rest_api_url}/api/geoservice/geocode/reverse?lat=${lat}&lng=${lng}&size=1`;
  const reverse_res = await axios(reverse_url);
  return reverse_res.data;
};

exports.compute_isochrone = async (lat, lng, time_limits, profile) => {
  const iso_url = `${rest_api_url}/api/geoservice/direction/isochrone?center=${lat},${lng}&time_limits=${time_limits}&profile=${profile}`;
  const reverse_iso = await axios(iso_url);
  return reverse_iso.data;
};
