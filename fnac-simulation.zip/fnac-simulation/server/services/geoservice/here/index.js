'use strict';
const axios = require('axios');

const HERE_CONFIG = {
  API_KEY: process.env.HERE_API_KEY,
  GEOCODE_URL: 'https://geocode.search.hereapi.com/v1/geocode',
};

exports.geocode_search = async (search_term) => {
  const params = [`apiKey=${HERE_CONFIG.API_KEY}`, 'limit=10', 'lang=fr-FR', 'in=countryCode%3AFRA', `q=${encodeURI(search_term)}`];
  const geocode_url = `${HERE_CONFIG.GEOCODE_URL}?${params.join('&')}`;
  let geojson = {
    type: 'FeatureCollection',
    features: [],
  };
  try {
    const response = await axios(geocode_url);
    if (response.status !== 200) {
      return geojson;
    }
    let t_data = response.data;
    geojson.features = t_data.items.map((item) => {
      let feature = {
        type: 'Feature',
        geometry: {
          type: 'Point',
          coordinates: [item.position.lng, item.position.lat],
        },
        properties: {
          label: item.address.label,
          name: item.address.label,
          housenumber: item.address.houseNumber,
          street: item.address.street,
          postalcode: item.address.postalCode,
          locality: item.address.city,
          country: item.address.countryName,
          type: item.resultType,
          id: item.id,
        },
      };
      return feature;
    });
    return geojson;
  } catch (err) {
    console.error('Error while geocoding');
    console.error(err);
  }
  return geojson;
};
