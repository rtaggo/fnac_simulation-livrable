const { v5: uuidv5 } = require('uuid');
const postgres = require('../../db/postgres');
const MY_NAMESPACE = '602cdbe5-7ecd-43e4-be56-27ad60d1f1fc';

const get_new_job_id = () => {
  return uuidv5(`${Date.now()}`, MY_NAMESPACE);
};

exports.get_jobs = (req, res) => {
  try {
    const { SCHEMA_TABLE } = process.env;
    const jobs_query = `SELECT id, id_simulation, status FROM ${SCHEMA_TABLE}.ggo_simulation_job`;
    postgres
      .query(jobs_query)
      .then((result) => {
        res.send(result.rows);
      })
      .catch((err_query) => {
        return res.status(500).json({
          error: true,
          message: 'Failed to get jobs',
          details: [err_query],
        });
      });
  } catch (err) {
    //
    console.error(err);
    return res.status(500).json({
      error: true,
      message: 'Failed to get jobs',
      details: [err],
    });
  }
};

exports.get_job_details = (req, res) => {
  try {
    const { SCHEMA_TABLE } = process.env;
    const { job_id } = req.params;
    const query = `SELECT id, id_simulation, status FROM ${SCHEMA_TABLE}.ggo_simulation_job
    WHERE id = '${job_id}'`;
    postgres.query(query).then((res_query) => {
      if (res_query.rows.length === 0) {
        return res.status(500).json({
          error: true,
          message: `Unkown job ${job_id}`,
        });
      }
      res.send(res_query.rows[0]);
    });
  } catch (err) {
    console.error(err);
    return res.status(500).json({
      error: true,
      message: 'Failed to get job details',
      details: [err],
    });
  }
};

exports.submit_job = async (req, res) => {
  try {
    const { SCHEMA_TABLE } = process.env;
    const { simulation } = req.query;
    if (!simulation) {
      return res.status(500).json({
        error: true,
        message: 'simulation query parameter is mandatory',
      });
    }
    const delete_job_query = `DELETE FROM sc_fnacdarty.ggo_simulation_job WHERE id_simulation='${simulation}'`;
    const res_delete_job = await postgres.query(delete_job_query);
    console.log(`Previous jobs deleted: ${res_delete_job.rowCount}`);
    const job_id = get_new_job_id();
    const insert_query = `INSERT INTO ${SCHEMA_TABLE}.ggo_simulation_job(id, id_simulation)
      VALUES ('${job_id}', '${simulation}')`;
    postgres.query(insert_query).then((res_insert) => {
      console.log(`Inserted : ${res_insert.rowCount}`);
      console.log('Let call the R Script');
      const { call_run_simulation } = require(`./${process.env.SIMULATION_RUN}`);
      call_run_simulation(simulation, job_id);
      res.send({
        job_id,
      });
    });
  } catch (err) {
    console.error(err);
    return res.status(500).json({
      error: true,
      message: 'Failed to submit job',
      details: [err],
    });
  }
};
