let simulations = [
  {
    id: 0,
    user_id: 0,
    name: 'Simulation 1',
    created_by: 'rteina',
    created_date: Date.now(),
    location: {
      coordinates: {
        longitude: 2.34283447265625,
        latitude: 48.84664340683584,
      },
    },
  },
  {
    id: 1,
    user_id: 0,
    name: 'Simulation 2',
    created_by: 'rteina',
    created_date: Date.now(),
    location: {
      coordinates: {
        longitude: 0.54931640625,
        latitude: 48.72720881940671,
      },
    },
  },
  {
    id: 2,
    user_id: 0,
    name: 'Simulation 3',
    created_by: 'rteina',
    created_date: Date.now(),
    location: {
      coordinates: {
        longitude: 4.833984374999999,
        latitude: 45.729191061299915,
      },
    },
  },
  {
    id: 3,
    user_id: 1,
    name: 'Simulation 4',
    created_by: 'gjatteau',
    created_date: Date.now(),
    location: {
      coordinates: {
        longitude: 0.54931640625,
        latitude: 48.72720881940671,
      },
    },
  },
  {
    id: 4,
    name: 'GGO - 1 concurrence',
    created_by: 'rteina',
    created_date: Date.now(),
    location: {
      address: "87 Avenue d'Italie, 75013 Paris, France",
      coordinates: {
        latitude: 48.82404,
        longitude: 2.35843,
      },
    },
    statistics: {
      nb: 41,
      population: 109154.91502187,
      logement: 62560.3127580245,
      menage: 54678.0468212596,
      potentiel: 94338327,
      men_cs1: 5.30030221371987,
      men_cs2: 1646.27735300366,
      men_cs3: 15273.9926969738,
      men_cs4: 9047.41573114929,
      men_cs5: 8237.81438169462,
      men_cs6: 3163.9451349576,
      men_cs7: 12593.5258521068,
      men_cs8: 4709.77536916013,
      csp_p: 25967.6857811268,
      csp_m: 11401.7595166522,
      revenu_moyen: 38239.0152374107,
      p_poph: 52080.8742221174,
      p_popf: 59474.8120607014,
      p_h0014: 8167.57328012512,
      p_h1529: 12537.7361714717,
      p_h3044: 10822.572108615,
      p_h4559: 9896.71625737463,
      p_h6074: 7476.7503200663,
      p_h75p: 3179.52608446469,
      p_f0014: 7858.73252861474,
      p_f1529: 13892.3468327064,
      p_f3044: 11248.5743186255,
      p_f4559: 11460.6660554118,
      p_f6074: 9552.57451253825,
      p_f75p: 5461.9178128047,
      p_rp: 54681.9541840854,
      p_rsecocc: 3515.15104447175,
      p_logvac: 4363.2075294673,
      p_rp_prop: 14964.1251533447,
      p_rp_loc: 37265.3184817149,
      p_rp_grat: 2452.51054902577,
      p_maison: 904.440162825079,
      p_appart: 60628.2822741486,
    },
    zc: {
      profile: 'foot-walking',
      zone_global: {
        coordinates: [
          [
            [2.342269, 48.826791],
            [2.343243, 48.820971],
            [2.344488, 48.818667],
            [2.344498, 48.818652],
            [2.344499, 48.81865],
            [2.344506, 48.818639],
            [2.345954, 48.817903],
            [2.351131, 48.815622],
            [2.353491, 48.814775],
            [2.357555, 48.812349],
            [2.361445, 48.8117],
            [2.361576, 48.811716],
            [2.362213, 48.811792],
            [2.363477, 48.813142],
            [2.367727, 48.815602],
            [2.368011, 48.8157],
            [2.371696, 48.819745],
            [2.372107, 48.820732],
            [2.373477, 48.824297],
            [2.372187, 48.828176],
            [2.370986, 48.830078],
            [2.37098, 48.830085],
            [2.370914, 48.830132],
            [2.366519, 48.832266],
            [2.364407, 48.833222],
            [2.360807, 48.834562],
            [2.358212, 48.836318],
            [2.358192, 48.836322],
            [2.358184, 48.836324],
            [2.35812, 48.836338],
            [2.355906, 48.83618],
            [2.353168, 48.835623],
            [2.352579, 48.835407],
            [2.352244, 48.835225],
            [2.350582, 48.833638],
            [2.346108, 48.830744],
            [2.34305, 48.827712],
            [2.342813, 48.827438],
            [2.34256, 48.827144],
            [2.342269, 48.826791],
          ],
        ],
        type: 'Polygon',
      },
      zones: [
        {
          id: 0,
          label: 'Zone primaire',
          range: 5,
          color: '#2ca25f',
          active: true,
          geometry: {
            coordinates: [
              [
                [2.285295, 48.866356],
                [2.286368, 48.864907],
                [2.287546, 48.863759],
                [2.287839, 48.863549],
                [2.29024, 48.863841],
                [2.293776, 48.8644],
                [2.29381, 48.864433],
                [2.294209, 48.864835],
                [2.294224, 48.864863],
                [2.294979, 48.86734],
                [2.295077, 48.867686],
                [2.294733, 48.868892],
                [2.294589, 48.869222],
                [2.294167, 48.869948],
                [2.292631, 48.870511],
                [2.290993, 48.870512],
                [2.290163, 48.870359],
                [2.286174, 48.869349],
                [2.285981, 48.869045],
                [2.285295, 48.866356],
              ],
            ],
            type: 'Polygon',
          },
        },
        {
          id: 1,
          label: 'Zone secondaire',
          range: 10,
          color: '#99d8c9',
          active: true,
          geometry: {
            type: 'Polygon',
            coordinates: [
              [
                [2.280195, 48.867686],
                [2.2803, 48.868383],
                [2.281046, 48.870595],
                [2.281135, 48.870779],
                [2.284408, 48.872586],
                [2.284756, 48.87268],
                [2.287588, 48.873096],
                [2.292696, 48.873756],
                [2.292802, 48.873769],
                [2.292863, 48.873775],
                [2.294325, 48.873766],
                [2.295466, 48.87346],
                [2.296599, 48.872889],
                [2.298418, 48.87181],
                [2.299031, 48.871158],
                [2.299337, 48.869974],
                [2.299905, 48.867587],
                [2.299862, 48.86516],
                [2.299752, 48.864971],
                [2.299728, 48.864932],
                [2.299626, 48.8648],
                [2.299416, 48.864619],
                [2.297042, 48.862708],
                [2.296761, 48.862483],
                [2.291469, 48.860564],
                [2.286849, 48.860248],
                [2.286094, 48.860292],
                [2.284393, 48.861143],
                [2.280999, 48.864397],
                [2.280869, 48.864733],
                [2.280195, 48.867686],
              ],
              [
                [2.285295, 48.866356],
                [2.286368, 48.864907],
                [2.287546, 48.863759],
                [2.287839, 48.863549],
                [2.29024, 48.863841],
                [2.293776, 48.8644],
                [2.29381, 48.864433],
                [2.294209, 48.864835],
                [2.294224, 48.864863],
                [2.294979, 48.86734],
                [2.295077, 48.867686],
                [2.294733, 48.868892],
                [2.294589, 48.869222],
                [2.294167, 48.869948],
                [2.292631, 48.870511],
                [2.290993, 48.870512],
                [2.290163, 48.870359],
                [2.286174, 48.869349],
                [2.285981, 48.869045],
                [2.285295, 48.866356],
              ],
            ],
          },
        },
        {
          id: 2,
          label: 'Zone tertiaire',
          range: 15,
          color: '#e5f5f9',
          active: true,
          geometry: {
            type: 'Polygon',
            coordinates: [
              [
                [2.275176, 48.868068],
                [2.275656, 48.871139],
                [2.275744, 48.871488],
                [2.275886, 48.871901],
                [2.276344, 48.87221],
                [2.28059, 48.874704],
                [2.283261, 48.876189],
                [2.283463, 48.876282],
                [2.283812, 48.87637],
                [2.286859, 48.876079],
                [2.292579, 48.877095],
                [2.294469, 48.87722],
                [2.294638, 48.877196],
                [2.296936, 48.876704],
                [2.299537, 48.875848],
                [2.299699, 48.875793],
                [2.301871, 48.874668],
                [2.302873, 48.873277],
                [2.30307, 48.872975],
                [2.304147, 48.869731],
                [2.30605, 48.864419],
                [2.306058, 48.864059],
                [2.302298, 48.862238],
                [2.300708, 48.860719],
                [2.298778, 48.860024],
                [2.296533, 48.85965],
                [2.292555, 48.857775],
                [2.292155, 48.857732],
                [2.288087, 48.857466],
                [2.285858, 48.856985],
                [2.283318, 48.857106],
                [2.279138, 48.859575],
                [2.276629, 48.862723],
                [2.275843, 48.864039],
                [2.275795, 48.864138],
                [2.275376, 48.865643],
                [2.275176, 48.868068],
              ],
              [
                [2.280195, 48.867686],
                [2.280869, 48.864733],
                [2.280999, 48.864397],
                [2.284393, 48.861143],
                [2.286094, 48.860292],
                [2.286849, 48.860248],
                [2.291469, 48.860564],
                [2.296761, 48.862483],
                [2.297042, 48.862708],
                [2.299416, 48.864619],
                [2.299626, 48.8648],
                [2.299728, 48.864932],
                [2.299752, 48.864971],
                [2.299862, 48.86516],
                [2.299905, 48.867587],
                [2.299337, 48.869974],
                [2.299031, 48.871158],
                [2.298418, 48.87181],
                [2.296599, 48.872889],
                [2.295466, 48.87346],
                [2.294325, 48.873766],
                [2.292863, 48.873775],
                [2.292802, 48.873769],
                [2.292696, 48.873756],
                [2.287588, 48.873096],
                [2.284756, 48.87268],
                [2.284408, 48.872586],
                [2.281135, 48.870779],
                [2.281046, 48.870595],
                [2.2803, 48.868383],
                [2.280195, 48.867686],
              ],
            ],
          },
        },
      ],
    },
    description: 'Test Full',
  },
];

const get_next_simulation_id = () => {
  return 1 + Math.max(...simulations.map((s) => s.id));
};

exports.get_user_simulations = async (req, res) => {
  console.log('[SIMULATION SERVICES] >> get_user_simulations');
  const user_simulations = simulations; //.filter((s) => s.user_id === req.decodedUser.id);
  res.send(
    user_simulations.map((s) => {
      return {
        id: s.id,
        name: s.name,
        created_by: s.created_by,
        created_date: s.created_date,
        last_modified_by: s.last_modified_bY,
        last_modified_date: s.last_modified_date,
        location: s.location,
      };
    })
  );
};

exports.get_simulation_details = async (req, res) => {
  try {
    const { simulation_id } = req.params;
    const simulation = simulations.find((s) => s.id === +simulation_id);
    if (!simulation) {
      console.error('simulaion-not-found');
      return res.status(500).json({
        error: true,
        message: 'Failed to get Simulation details',
        details: [`Unable to find simualtion with id=${simulation_id}`],
      });
    }
    res.send(simulation);
  } catch (error) {
    console.error('get-simulation-error', error);
    return res.status(500).json({
      error: true,
      message: 'Failed to get Simulation details',
      details: error,
    });
  }
};

exports.save_simulation = async (req, res) => {
  try {
    const simu_id = get_next_simulation_id();
    simulations.push({
      ...{
        id: simu_id,
        user_id: req.decodedUser.id,
        created_by: req.decodedUser.login,
        created_date: Date.now(),
        last_modified_by: req.decodedUser.login,
        last_modified_date: Date.now(),
      },
      ...req.body,
    });
    res.status(200).json({
      success: true,
      message: 'Simulation save Success',
      data: { id: simu_id },
    });
  } catch (error) {
    console.error('save-simulation-error', error);
    return res.status(500).json({
      error: true,
      message: 'Cannot Save Simulation',
      details: error,
    });
  }
};

exports.delete_similation = async (req, res) => {
  try {
    const { simulation_id } = req.params;
    simulations = simulations.filter((s) => s.id !== +simulation_id);
    res.status(200).json({
      success: true,
      message: 'Simulation deleted',
    });
  } catch (error) {
    console.error('delete-simulation-error', error);
    return res.status(500).json({
      error: true,
      message: 'Failed to delete simulation',
      details: error,
    });
  }
};

exports.patch_simulation = async (req, res) => {
  try {
    let { simulation_id } = req.params;
    let { name } = req.body;
    let simulation = simulations.find((s) => s.id === +simulation_id);
    if (!simulation) {
      return res.status(500).json({
        error: true,
        message: 'Cannot patch Simulation',
        details: [`Unable to find simulation with id=${simulation_id}`],
      });
    }
    simulation.name = name;
    simulation.last_modified_date = Date.now();
    simulation.last_modified_by = req.decodedUser.login;

    res.status(200).json({
      success: true,
      message: 'Simulation update Success',
    });
  } catch (error) {
    console.error('save-simulation-error', error);
    return res.status(500).json({
      error: true,
      message: 'Cannot Save Simulation',
      details: error,
    });
  }
};
