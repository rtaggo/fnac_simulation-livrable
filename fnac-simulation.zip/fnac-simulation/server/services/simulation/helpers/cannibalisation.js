exports.clear_cannibalisation = (simulation_id) => {
  const postgres = require('../../../db/postgres');
  try {
    const { SCHEMA_TABLE } = process.env;
    const delete_query = `DELETE FROM ${SCHEMA_TABLE}.ggo_simulation_cannibalisation WHERE id_simulation = '${simulation_id}'`;
    postgres
      .query(delete_query)
      .then((res_delete) => {
        console.log(`CANNIBALISATION: ${res_delete.rowCount} rows removed`);
        return;
      })
      .catch((err_delete) => {
        console.error('Delete cannibalisation rows failed', err_delete);
        return;
      });
  } catch (err) {
    console.error('Global error while clearing cannibalisation', err);
  }
};
