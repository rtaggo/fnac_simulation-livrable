const { generateJwt } = require('../../../helpers/jwt');

const users = [{ id: 0, login: 'rteina', password: 'galigeo' }, { id: 1, login: 'gjatteau', password: 'galigeo' }];

exports.signup = async (req, res) => {
  try {
    return res.status(200).json({
      success: true,
      message: 'Registration Success',
      todo: 'Faire enregistrement utilisateur',
    });
  } catch (error) {
    console.error('signup-error', error);
    return res.status(500).json({
      error: true,
      message: 'Cannot Register',
    });
  }
};

exports.login = async (req, res) => {
  try {
    const { login, password } = req.body;

    if (!login || !password) {
      return res.status(400).json({
        error: true,
        message: 'Authentication failed',
      });
    }
    const user = users.find((u) => u.login === login);
    if (!user || user.password !== password) {
      return res.status(400).json({
        error: true,
        message: 'Authentication failed',
      });
    }
    //Generate Access token
    const { error, token } = await generateJwt(user.login, user.id);
    if (error) {
      return res.status(500).json({
        error: true,
        message: "Couldn't create access token. Please try again later",
      });
    }
    const expires_cookie = new Date(Date.now() + 31536000);
    const max_age_cookie = 30 * 24 * 60 * 60 * 1000; // 30 days;
    res.cookie(process.env.JWT_TOKENNAME, token, {
      httpOnly: true,
      secure: process.env.NODE_ENV === 'production' ? true : false,
      expires: expires_cookie,
      maxAge: max_age_cookie,
    });
    //Success
    return res.send({
      success: true,
      message: 'User logged in successfully',
      accessToken: token,
    });
  } catch (err) {
    console.error('Login error', err);
    return res.status(500).json({
      error: true,
      message: "Couldn't login. Please try again later.",
      message_fr: 'Impossible de vous connecter. Veuillez réessayer plus tard.',
    });
  }
};

exports.logout = async (req, res) => {
  try {
    res.clearCookie(process.env.JWT_TOKENNAME);
    return res.send({ success: true, message: 'User Logged out' });
  } catch (error) {
    console.error('user-logout-error', error);
    return res.stat(500).json({
      error: true,
      message: error.message,
    });
  }
};

exports.current = async (req, res) => {
  try {
    const user = users.find((u) => u.id === req.decodedUser.id);
    if (!user) {
      return res.stat(500).json({
        error: true,
        message: 'Unable to find user',
      });
    }
    return res.send(user);
  } catch (error) {
    console.error('user-current-error', error);
    return res.stat(500).json({
      error: true,
      message: error.message,
    });
  }
};


exports.get_login_url = (req) => {
  let query_params = '';
  const query_entries = Object.entries(req.query);
  if (query_entries.length > 0) {
    query_params = `?${query_entries.map((e) => `${e[0]}=${e[1]}`).join('&')}`;
  }
  return `/login?redirect_to=${req.path}${query_params}`;
}