CREATE TABLE IF NOT EXISTS sc_fnacdarty.ggo_simulation_cannibalisation
(
  id_simulation character varying COLLATE pg_catalog."default" NOT NULL,
  id_pdv character varying COLLATE pg_catalog."default" NOT NULL,
  code_iris character varying COLLATE pg_catalog."default" NOT NULL,
  estimation_ca_perdu numeric,
  CONSTRAINT ggo_simulation_cannibalisation_pkey PRIMARY KEY (id_simulation, id_pdv),
  CONSTRAINT fk_simulation_id FOREIGN KEY (id_simulation) REFERENCES sc_fnacdarty.ggo_simulation (id) ON DELETE CASCADE
)
