CREATE TABLE IF NOT EXISTS sc_fnacdarty.ggo_simulation_zones
(
  id_simulation character varying COLLATE pg_catalog."default" NOT NULL,
  id_zone integer NOT NULL,
  code_iris character varying COLLATE pg_catalog."default" NOT NULL,
  estimation_ca numeric,
  CONSTRAINT fk_simulation_id FOREIGN KEY (id_simulation)
    REFERENCES sc_fnacdarty.ggo_simulation (id) ON DELETE CASCADE
)