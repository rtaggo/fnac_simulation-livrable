CREATE TABLE IF NOT EXISTS sc_fnacdarty.ggo_simulation
(
  id character varying COLLATE pg_catalog."default" NOT NULL,
  name character varying COLLATE pg_catalog."default",
  description character varying COLLATE pg_catalog."default",
  location jsonb,
  statistics jsonb,
  zc jsonb,
  created_by character varying COLLATE pg_catalog."default",
  created_date timestamp with time zone default current_timestamp,
  last_modified_by character varying COLLATE pg_catalog."default",
  last_modified_date timestamp with time zone default current_timestamp,
  CONSTRAINT ggo_simulation_pkey PRIMARY KEY (id)
)
