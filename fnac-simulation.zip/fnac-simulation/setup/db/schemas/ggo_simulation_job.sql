CREATE TABLE IF NOT EXISTS sc_fnacdarty.ggo_simulation_job
(
  id character varying COLLATE pg_catalog."default" NOT NULL,
  id_simulation character varying COLLATE pg_catalog."default" NOT NULL,
  status character varying COLLATE pg_catalog."default" DEFAULT 'Pending'::character varying,
  CONSTRAINT ggo_simulation_job_pkey PRIMARY KEY (id),
  CONSTRAINT fk_simulation_id FOREIGN KEY (id_simulation) REFERENCES sc_fnacdarty.ggo_simulation (id) ON DELETE CASCADE
)
